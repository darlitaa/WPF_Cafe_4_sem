﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles; 
using WpfApp1.Services;
using WpfApp1.Views;
using System.Globalization;
using System.Threading;
using WpfApp1.Data;
using System.Diagnostics;
using System.Data.Entity.Migrations;
using System.Data.Entity;

namespace WpfApp1
{

    public partial class App : Application
    {
        private static JsonDataService _jsonDataService;
        public static UserService UserService { get; private set; }
        public static Data.UserCrudService UserCrudService { get; private set; }
        public static Data.ProductCrudService ProductCrudService { get; private set; }
        public static Data.OrderCrudService OrderCrudService { get; private set; }
        public static Data.CartItemCrudService CartItemCrudService { get; private set; }
        public static LocalizationService LocalizationService { get; private set; }
        public static OrderService OrderService { get; private set; }
        public static ImageService ImageService { get; private set; }
        public static JsonDataService JsonDataService => _jsonDataService;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            DispatcherUnhandledException += App_DispatcherUnhandledException;

            // Устанавливаем путь для базы данных
            SetupDatabase();
            
            // Инициализируем ThemeManager
            ThemeManager.Initialize();
            
            // Устанавливаем культуру для приложения
            SetupCulture();

            // Инициализируем сервисы
            var services = InitializeServices();

            // Инициализируем OrderService
            if (OrderService != null)
            {
                Debug.WriteLine("Инициализация OrderService в App.OnStartup");
                OrderService.Initialize();
            }
            else
            {
                Debug.WriteLine("OrderService не был инициализирован в App.OnStartup");
            }

            // Создаем и отображаем главное окно
            ShowMainWindow(services);
        }

        private void App_DispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            Debug.WriteLine($"Необработанное исключение: {e.Exception.Message}");
            Debug.WriteLine($"Стек вызовов: {e.Exception.StackTrace}");
            e.Handled = true;
        }

        private void SetupDatabase()
        {
            // Указываем путь к папке данных
            AppDomain.CurrentDomain.SetData("DataDirectory", Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data"));
            
            try
            {
                Debug.WriteLine("Инициализация базы данных...");
                
                using (var dbContext = new CafeDbContext())
                {
                    // Проверяем, существует ли база данных, если нет - создаем и применяем миграции
                    bool exists = dbContext.Database.Exists();
                    Debug.WriteLine($"База данных {(exists ? "существует" : "не существует")}");
                    
                    // Применяем миграции к базе данных
                    Database.SetInitializer(new MigrateDatabaseToLatestVersion<CafeDbContext, Migrations.Configuration>());
                    
                    // Явно запускаем миграцию для удаления столбцов
                    var migrator = new DbMigrator(new Migrations.Configuration());
                    migrator.Update();
                    
                    // Триггер инициализации
                    dbContext.Database.Initialize(force: true);
                    
                    // Выводим информацию о таблицах
                    Debug.WriteLine($"Количество пользователей: {dbContext.Users.Count()}");
                    Debug.WriteLine($"Количество продуктов: {dbContext.Products.Count()}");
                    Debug.WriteLine($"Количество заказов: {dbContext.Orders.Count()}");
                    
                    Debug.WriteLine("База данных успешно инициализирована");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при настройке базы данных: {ex.Message}");
                Debug.WriteLine(ex.StackTrace);
                MessageBox.Show($"Ошибка при подключении к базе данных: {ex.Message}", "Ошибка базы данных", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SetupCulture()
        {
            // Устанавливаем русскую культуру для приложения
            Thread.CurrentThread.CurrentCulture = new CultureInfo("ru-RU");
            Thread.CurrentThread.CurrentUICulture = new CultureInfo("ru-RU");
        }

        private (UserService userService, ProductService productService, OrderService orderService) InitializeServices()
        {
            // Инициализируем сервисы
            _jsonDataService = new JsonDataService();
            var userService = new UserService();
            var productService = new ProductService(null);
            var orderService = new OrderService(productService);
            
            // Инициализируем CRUD сервисы для работы с базой данных
            UserCrudService = new Data.UserCrudService();
            ProductCrudService = new Data.ProductCrudService();
            OrderCrudService = new Data.OrderCrudService();
            CartItemCrudService = new Data.CartItemCrudService();
            
            // Настраиваем обработчики событий для синхронизации обновлений
            UserCrudService.UsersChanged += (s, e) => userService.RefreshUsers();
            ProductCrudService.ProductsChanged += (s, e) => 
            {
                try
                {
                    // Вызываем публичный метод вместо прямого обращения к событию
                    productService.RaiseProductsUpdated();
                    Debug.WriteLine("App: Обновление товаров после события ProductsChanged");
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Ошибка при обработке события ProductsChanged: {ex.Message}");
                }
            };
            OrderCrudService.OrdersChanged += (s, e) => orderService.RefreshOrders();
            
            // Инициализируем сервис локализации
            LocalizationService = new LocalizationService();
            
            // Инициализируем сервис изображений
            ImageService = new ImageService();

            // Запускаем инициализацию синхронно
            userService.Initialize();
            productService.Initialize();
            
            // Сохраняем ссылку на OrderService в статическое свойство
            OrderService = orderService;

            return (userService, productService, orderService);
        }

        private void ShowMainWindow((UserService userService, ProductService productService, OrderService orderService) services)
        {
            // Сохраняем сервисы в статические свойства для доступа из других частей приложения
            UserService = services.userService;
            OrderService = services.orderService;
            
            // Создаем окно логина и делаем его главным окном приложения
            var loginView = new LoginView(services.userService);
            Application.Current.MainWindow = loginView;
            loginView.Show();
        }
    }
}

