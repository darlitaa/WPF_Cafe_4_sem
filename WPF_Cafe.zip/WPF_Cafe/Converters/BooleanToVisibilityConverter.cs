using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace WpfApp1.Converters
{
    public class BooleanToVisibilityConverter : IValueConverter
    {
        public bool IsInverted { get; set; }
        
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool visibility = false;
            
            if (value is bool boolValue)
            {
                visibility = boolValue;
            }
            else if (value != null)
            {
                visibility = true;
            }

            if (IsInverted)
            {
                visibility = !visibility;
            }
            
            return visibility ? Visibility.Visible : Visibility.Collapsed;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool result = value is Visibility visibility && visibility == Visibility.Visible;

            if (IsInverted)
            {
                result = !result;
            }
            
            return result;
        }
    }
} 