using System;
using System.Globalization;
using System.IO;
using System.Windows.Data;
using System.Windows.Media.Imaging;

namespace WpfApp1.Converters
{
	public class ImageConverter : IValueConverter
	{
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			try
			{
				if (value == null || string.IsNullOrEmpty(value.ToString()))
					return new BitmapImage(new Uri("/Resources/Images/photo.jpg", UriKind.Relative));

				string imagePath = value.ToString();

				// Проверяем, начинается ли путь с Resources
				if (imagePath.StartsWith("/Resources", StringComparison.OrdinalIgnoreCase))
				{
					// Если путь начинается с Resources, используем его как относительный
					return new BitmapImage(new Uri(imagePath, UriKind.Relative));
				}
				else
				{
					// Иначе используем абсолютный путь
					if (File.Exists(imagePath))
					{
						BitmapImage image = new BitmapImage();
						image.BeginInit();
						image.UriSource = new Uri(imagePath, UriKind.Absolute);
						image.CacheOption = BitmapCacheOption.OnLoad;
						image.CreateOptions = BitmapCreateOptions.IgnoreImageCache;
						image.EndInit();
						return image;
					}
					else
					{
						// Если файл не найден, возвращаем изображение по умолчанию
						return new BitmapImage(new Uri("/Resources/Images/photo.jpg", UriKind.Relative));
					}
				}
			}
			catch (Exception)
			{
				return new BitmapImage(new Uri("/Resources/Images/photo.jpg", UriKind.Relative));
			}
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			throw new NotImplementedException();
		}
	}
}