using System;
using System.Globalization;
using System.Windows.Data;

namespace WpfApp1.Converters
{
    public class RatingConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null || parameter == null)
                return false;

            int rating;
            int parameterValue;

            if (int.TryParse(value.ToString(), out rating) && int.TryParse(parameter.ToString(), out parameterValue))
            {
                return rating == parameterValue;
            }

            return false;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null || parameter == null)
                return 0;

            bool isChecked = (bool)value;
            if (isChecked)
            {
                int parameterValue;
                if (int.TryParse(parameter.ToString(), out parameterValue))
                {
                    return parameterValue;
                }
            }

            return 0;
        }
    }
} 