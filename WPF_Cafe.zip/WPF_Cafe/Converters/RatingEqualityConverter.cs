using System;
using System.Globalization;
using System.Windows.Data;

namespace WpfApp1.Converters
{
    public class RatingEqualityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is int rating && parameter is string paramRating && int.TryParse(paramRating, out int compareRating))
            {
                return rating == compareRating;
            }
            
            return false;
        }
        
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool isChecked && isChecked && parameter is string paramRating && int.TryParse(paramRating, out int rating))
            {
                return rating;
            }
            
            return 0; // Возвращаем нейтральное значение, если конвертация невозможна
        }
    }
} 