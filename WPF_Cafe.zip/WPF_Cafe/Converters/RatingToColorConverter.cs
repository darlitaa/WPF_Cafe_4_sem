using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace WpfApp1.Converters
{
    public class RatingToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is double rating && parameter is string paramRating)
            {
                if (int.TryParse(paramRating, out int compareRating))
                {
                    // Если рейтинг больше или равен сравниваемому значению - закрашиваем звезду
                    if (rating >= compareRating)
                    {
                        return new SolidColorBrush(Color.FromRgb(255, 193, 7)); // Золотая звезда
                    }
                }
            }
            
            return new SolidColorBrush(Color.FromRgb(224, 224, 224)); // Серая звезда
        }
        
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
} 