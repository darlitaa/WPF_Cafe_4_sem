using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace WpfApp1.Converters
{
    public class RatingToStarsConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null)
                return "☆☆☆☆☆";

            double rating;
            
            if (value is int intRating)
            {
                rating = (double)intRating;
            }
            else if (value is double doubleRating)
            {
                rating = doubleRating;
            }
            else if (double.TryParse(value.ToString(), out double parsedRating))
            {
                rating = parsedRating;
            }
            else
            {
                return "☆☆☆☆☆";
            }

                double roundedRating = Math.Round(rating * 2) / 2;

                string stars = "";
                for (int i = 1; i <= 5; i++)
                {
                    if (i <= roundedRating)
                    {
                        stars += "★";
                    }
                    else if (i - 0.5 == roundedRating)
                    {
                        stars += "✬";
                    }
                    else
                    {
                        stars += "☆";
                    }
                }
                
                return stars;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
} 