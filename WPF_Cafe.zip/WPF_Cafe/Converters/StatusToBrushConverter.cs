using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace WpfApp1.Converters
{
    public class StatusToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string status)
            {
                switch (status)
                {
                    case "Created":
                        return new SolidColorBrush(Color.FromRgb(108, 117, 125)); // Серый
                    case "Processing":
                        return new SolidColorBrush(Color.FromRgb(255, 193, 7));   // Желтый
                    case "Completed":
                        return new SolidColorBrush(Color.FromRgb(40, 167, 69));   // Зеленый
                    case "Canceled":
                        return new SolidColorBrush(Color.FromRgb(220, 53, 69));   // Красный
                    default:
                        return new SolidColorBrush(Color.FromRgb(108, 117, 125)); // Серый по умолчанию
                }
            }
            
            return new SolidColorBrush(Colors.Gray);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
} 