using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Collections.Generic;
using System.Linq;

namespace WpfApp1.Converters
{
    public class StatusToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string status && parameter is string expectedStatus)
            {
                if (expectedStatus == "NotCompleted")
                {
                    return status != "Completed" && status != "Canceled" 
                        ? Visibility.Visible 
                        : Visibility.Collapsed;
                }
                
                return status == expectedStatus ? Visibility.Visible : Visibility.Collapsed;
            }
            
            return Visibility.Collapsed;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

   
    
    public class InverseBooleanToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool boolValue)
            {
                return boolValue ? Visibility.Collapsed : Visibility.Visible;
            }
            
            return Visibility.Visible;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class OrderIdToReadableConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null)
                return string.Empty;
                
            string orderId = value.ToString();

            bool isRussian = culture.Name.StartsWith("ru");

            string orderNumber;
            
            if (orderId.Contains("-"))
            {
                var parts = orderId.Split('-');
                string lastPart = parts[parts.Length - 1];
                orderNumber = lastPart.Length > 4 ? lastPart.Substring(0, 4) : lastPart;
            }
            else
            {
                orderNumber = orderId.Length > 4 ? orderId.Substring(0, 4) : orderId;
            }

            if (parameter != null && parameter.ToString() == "short")
            {
                return $"#{orderNumber}";
            }
            else
            {
                string orderText = "Order";
                try 
                {
                    var resourceManager = Application.Current.Resources;
                    if (resourceManager.Contains("OrderInfo"))
                    {
                        string fullText = resourceManager["OrderInfo"].ToString();
                        orderText = fullText.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[0];
                    }
                }
                catch
                {
                    orderText = isRussian ? "Заказ" : "Order";
                }
                
                return $"{orderText} #{orderNumber}";
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class OrderStatusConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string status)
            {
                string resourceKey = null;

                // Определяем ключ ресурса на основе значения статуса из БД
                switch (status)
                {
                    case "В обработке":
                    case "Новый":
                        resourceKey = "Pending";
                        break;
                    case "Готовится":
                        resourceKey = "Preparing";
                        break;
                    case "Готов к выдаче":
                        resourceKey = "Ready";
                        break;
                    case "Выполнен":
                        resourceKey = "Completed";
                        break;
                    case "Отменен":
                        resourceKey = "Canceled";
                        break;
                    case "Доставлен":
                        resourceKey = "Delivered";
                        break;
                    default:
                        return status; // Если статус не распознан, возвращаем как есть
                }

                // Пытаемся найти локализованный ресурс для текущей культуры
                try
                {
                    if (resourceKey != null && Application.Current.Resources.Contains(resourceKey))
                    {
                        return Application.Current.Resources[resourceKey].ToString();
                    }
                }
                catch
                {
                    // Если возникла ошибка при получении ресурса
                }

                // Если ресурс не найден, используем стандартные переводы
                bool isRussian = culture.Name.StartsWith("ru");
                
                if (isRussian)
                {
                    // Для русской локали используем стандартные русские переводы
                    switch (status)
                    {
                        case "В обработке":
                        case "Новый":
                            return "В обработке";
                        case "Готовится":
                            return "Готовится";
                        case "Готов к выдаче":
                            return "Готов к выдаче";
                        case "Выполнен":
                            return "Выполнен";
                        case "Отменен":
                            return "Отменен";
                        case "Доставлен":
                            return "Доставлен";
                        default:
                            return status;
                    }
                }
                else
                {
                    // Для других локалей используем английские переводы
                    switch (status)
                    {
                        case "Новый":
                        case "В обработке":
                            return "Pending";
                        case "Готовится":
                            return "Preparing";
                        case "Готов к выдаче":
                            return "Ready for Pickup";
                        case "Выполнен":
                            return "Completed";
                        case "Отменен":
                            return "Canceled";
                        case "Доставлен":
                            return "Delivered";
                        default:
                            return status;
                    }
                }
            }
            
            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string localizedStatus)
            {
                bool isRussian = culture.Name.StartsWith("ru");

                if (isRussian)
                    return localizedStatus;

                // При обратном преобразовании возвращаем русские названия статусов
                switch (localizedStatus)
                {
                    case "Pending":
                        return "В обработке";
                    case "Preparing":
                        return "Готовится";
                    case "Ready for Pickup":
                        return "Готов к выдаче";
                    case "Completed":
                        return "Выполнен";
                    case "Canceled":
                        return "Отменен";
                    case "Delivered":
                        return "Доставлен";
                    default:
                        return localizedStatus;
                }
            }
            
            return value;
        }
    }

    public class ProductCategoryConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string category)
            {
                try
                {
                    string resourceKey = null;

                    switch (category)
                    {
                        case "Кофе":
                            resourceKey = "Coffee";
                            break;
                        case "Десерты":
                            resourceKey = "Desserts";
                            break;
                        case "Закуски":
                            resourceKey = "Snacks";
                            break;
                        default:
                            resourceKey = null;
                            break;
                    }

                    if (resourceKey != null && Application.Current.Resources.Contains(resourceKey))
                    {
                        return Application.Current.Resources[resourceKey].ToString();
                    }
                }
                catch
                {
                    // Если возникла ошибка при получении ресурса
                }
                
                // Если ресурс не найден, используем стандартные переводы
                bool isRussian = culture.Name.StartsWith("ru");
                
                if (isRussian)
                {
                    // Для русской локали используем оригинальные значения
                    return category;
                }
                else
                {
                    // Для других локалей используем английские переводы
                    switch (category)
                    {
                        case "Кофе":
                            return "Coffee";
                        case "Десерты":
                            return "Desserts";
                        case "Закуски":
                            return "Snacks";
                        default:
                            return category;
                    }
                }
            }
            
            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class ManufacturerConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string manufacturer)
            {
                try
                {
                    string resourceKey = "Manufacturer_" + manufacturer.Replace(" ", "_");
                    
                    if (Application.Current.Resources.Contains(resourceKey))
                    {
                        return Application.Current.Resources[resourceKey].ToString();
                    }
                }
                catch
                {
                    // Если возникла ошибка при получении ресурса
                }
                
                // Если ресурса нет или произошла ошибка, используем стандартные переводы
                bool isRussian = culture.Name.StartsWith("ru");
                
                if (isRussian)
                {
                    // Для русской локали используем оригинальные значения
                    return manufacturer;
                }
                else
                {
                    // Для других локалей используем английские переводы
                    switch (manufacturer)
                    {
                        case "Наше кафе":
                            return "Our Cafe";
                        case "Наша пекарня":
                            return "Our Bakery";
                        default:
                            return manufacturer;
                    }
                }
            }
            
            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string localizedName)
            {
                bool isRussian = culture.Name.StartsWith("ru");

                if (isRussian)
                    return localizedName;

                // При обратном преобразовании возвращаем русские названия для известных переводов
                switch (localizedName)
                {
                    case "Our Cafe":
                        return "Наше кафе";
                    case "Our Bakery":
                        return "Наша пекарня";
                    default:
                        return localizedName;
                }
            }
            
            return value;
        }
    }

    public class UserBlockStatusConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool isBlocked)
            {
                bool isRussian = culture.Name.StartsWith("ru");

                try
                {
                    string resourceKey = isBlocked ? "Blocked" : "Active";
                    
                    if (Application.Current.Resources.Contains(resourceKey))
                    {
                        return Application.Current.Resources[resourceKey].ToString();
                    }
                }
                catch
                {
                    // Если возникла ошибка при получении ресурса, используем прямой перевод
                }
                
                if (isRussian)
                {
                    return isBlocked ? "Заблокирован" : "Активен";
                }
                else
                {
                    return isBlocked ? "Blocked" : "Active";
                }
            }
            
            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string status)
            {
                bool isRussian = culture.Name.StartsWith("ru");

                if (isRussian)
                {
                    return status == "Заблокирован";
                }
                else
                {
                    return status == "Blocked";
                }
            }
            
            return value;
        }
    }

    public class ItemsToFormattedListConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is System.Collections.IEnumerable items)
            {
                // Группируем товары по названию и считаем количество
                var groupedItems = items.Cast<dynamic>()
                    .GroupBy(item => item.ProductName)
                    .Select(group => $"{group.Key}(x{group.Count()})");

                // Соединяем все элементы через запятую
                return string.Join(", ", groupedItems);
            }
            
            return string.Empty;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
} 