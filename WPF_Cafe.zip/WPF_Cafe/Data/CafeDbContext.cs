using System.Data.Entity;
using System.Collections.Generic;
using WpfApp1.Models;
using System;
using System.Diagnostics;
using System.Linq;

namespace WpfApp1.Data
{
    public class CafeDbContext : DbContext
    {
        public CafeDbContext() : base("name=CafeDbConnection")
        {
            // Отключаем инициализатор по умолчанию
            Database.SetInitializer<CafeDbContext>(null);

        }

        public DbSet<User> Users { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<CartItem> CartItems { get; set; }
        public DbSet<Review> Reviews { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            // Настройка отношения между Order и CartItem
            modelBuilder.Entity<Order>()
                .HasMany(o => o.Items)
                .WithOptional()
                .HasForeignKey(i => i.OrderId);

            // Другие настройки отношений при необходимости

            base.OnModelCreating(modelBuilder);
        }
    }

    // Инициализатор базы данных
    public class CafeDbInitializer : CreateDatabaseIfNotExists<CafeDbContext>
    {
        protected override void Seed(CafeDbContext context)
        {
            Debug.WriteLine("Инициализация базы данных с тестовыми данными...");

            try
            {
                // Добавляем демо-пользователей
                var users = new List<User>
                {
                    new User
                    {
                        Username = "admin",
                        Password = "admin1",
                        FullName = "Администратор",
                        Email = "admin@cafe.by",
                        Address = "г. Минск, ул.Свердлова 13А",
                        Phone = "+375291234467",
                        IsAdmin = true
                    },
                    new User
                    {
                        Username = "client1",
                        Password = "client1",
                        FullName = "Иван Мирон",
                        Email = "ivan@example.com",
                        Address = "г. Минск, ул.Свердлова 13А",
                        Phone = "+375291234567",
                        IsAdmin = false
                    },
                    new User
                    {
                        Username = "client2",
                        Password = "client2",
                        FullName = "Литвинчук Дарья",
                        Email = "darlita@example.com",
                        Address = "г. Минск, ул.Белорусская 21",
                        Phone = "+375291567291",
                        IsAdmin = false
                    },
                    new User
                    {
                        Username = "client3",
                        Password = "client3",
                        FullName = "Дарья Кузнецова",
                        Email = "cus@example.com",
                        Address = "г. Минск, ул.Мирная 7А",
                        Phone = "+375299634537",
                        IsAdmin = false
                    },
                };

                foreach (var user in users)
                {
                    context.Users.Add(user);
                }

                context.SaveChanges();
                Debug.WriteLine($"Создано {users.Count} тестовых пользователей");

                // Добавляем демо-товары
                var products = new List<Product>
                {
                    new Product
                    {
                        ShortName = "Эспрессо",
                        FullName = "Эспрессо классический",
                        Description = "Крепкий классический кофе с насыщенным вкусом.",
                        Category = "Кофе",
                        ImagesJson = "[\"/Resources/Images/Espresso.jpg\"]",
                        Price = 2.5m,
                        Quantity = 100,
                        InStock = true,
                        Manufacturer = "Наше кафе",
                        TimesPurchased = 150
                    },
                    new Product
                    {
                        ShortName = "Латте",
                        FullName = "Кофе Латте с ванилью",
                        Description = "Нежный напиток из эспрессо и молока с ароматом ванили.",
                        Category = "Кофе",
                        ImagesJson = "[\"/Resources/Images/Latte.jpg\"]",
                        Price = 3.5m,
                        Quantity = 80,
                        InStock = true,
                        Manufacturer = "Наше кафе",
                        TimesPurchased = 120
                    },
                    new Product
                    {
                        ShortName = "Чизкейк",
                        FullName = "Чизкейк Нью-Йорк",
                        Description = "Классический американский десерт с нежной текстурой.",
                        Category = "Десерты",
                        ImagesJson = "[\"/Resources/Images/Cheesecake.jpg\"]",
                        Price = 7,
                        Quantity = 30,
                        InStock = true,
                        Manufacturer = "Наша пекарня",
                        TimesPurchased = 80
                    },
                    new Product
                    {
                        ShortName = "Круассан",
                        FullName = "Круассан классический с маслом",
                        Description = "Свежий хрустящий круассан, приготовленный по традиционному французскому рецепту.",
                        Category = "Закуски",
                        ImagesJson = "[\"/Resources/Images/Croissant.jpg\"]",
                        Price = 7,
                        Quantity = 40,
                        InStock = true,
                        Manufacturer = "Наша пекарня",
                        TimesPurchased = 95
                    },
                    new Product
                    {
                        ShortName = "Капучино",
                        FullName = "Капучино с корицей",
                        Description = "Классический капучино с пышной молочной пеной и присыпкой корицы.",
                        Category = "Кофе",
                        ImagesJson = "[\"/Resources/Images/Cappuccino.jpg\"]",
                        Price = 3.5m,
                        Quantity = 75,
                        InStock = true,
                        Manufacturer = "Наше кафе",
                        TimesPurchased = 110
                    },
                    new Product
                    {
                        ShortName = "Тирамису",
                        FullName = "Десерт Тирамису",
                        Description = "Итальянский десерт на основе сыра маскарпоне, кофе и бисквита савоярди.",
                        Category = "Десерты",
                        ImagesJson = "[\"/Resources/Images/Tiramisu.jpg\"]",
                        Price = 7,
                        Quantity = 25,
                        InStock = true,
                        Manufacturer = "Наша пекарня",
                        TimesPurchased = 70
                    }
                };

                foreach (var product in products)
                {
                    context.Products.Add(product);
                }

                context.SaveChanges();
                Debug.WriteLine($"Создано {products.Count} тестовых товаров");

                // Создаем пример заказа
                var clientUser = context.Users.FirstOrDefault(u => u.Username == "client");
                if (clientUser != null)
                {
                    var espresso = context.Products.FirstOrDefault(p => p.ShortName == "Эспрессо");
                    var cheesecake = context.Products.FirstOrDefault(p => p.ShortName == "Чизкейк");

                    if (espresso != null && cheesecake != null)
                    {
                        var order = new Order
                        {
                            UserId = clientUser.Id,
                            Status = "В обработке",
                            OrderDate = DateTime.Now.AddDays(-2),
                            DeliveryAddress = clientUser.Address,
                            ContactPhone = clientUser.Phone,

                            Items = new List<CartItem>
                            {
                                new CartItem
                                {
                                    ProductId = espresso.Id,
                                    Quantity = 2,
                                    Price = espresso.Price,
                                    ProductImage = espresso.ImagesJson
                                },
                                new CartItem
                                {
                                    ProductId = cheesecake.Id,
                                    Quantity = 1,
                                    Price = cheesecake.Price,
                                    ProductImage = cheesecake.ImagesJson
                                }
                            }
                        };

                        order.TotalAmount = order.Items.Sum(i => i.Price * i.Quantity);
                        context.Orders.Add(order);
                        context.SaveChanges();
                        Debug.WriteLine("Создан тестовый заказ");
                    }
                }

                Debug.WriteLine("Инициализация базы данных завершена успешно");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при инициализации базы данных: {ex.Message}");
                Debug.WriteLine(ex.StackTrace);
            }

            base.Seed(context);
        }
    }
}