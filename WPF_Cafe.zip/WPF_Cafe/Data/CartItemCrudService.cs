using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using WpfApp1.Data;
using WpfApp1.Models;

namespace WpfApp1.Data
{
    public class CartItemCrudService
    {
        private readonly CafeDbContext _dbContext;
        
        public event EventHandler CartItemsChanged;
        
        public CartItemCrudService()
        {
            _dbContext = new CafeDbContext();
        }
           
        // Синхронные версии методов для совместимости с существующим кодом
        
        public CartItem CreateCartItem(CartItem cartItem)
        {
            try
            {
                if (cartItem == null)
                    throw new ArgumentNullException(nameof(cartItem));
                    
                // Проверяем, существует ли товар с таким ID
                var product = _dbContext.Products.Find(cartItem.ProductId);
                if (product == null)
                    throw new InvalidOperationException($"Товар с ID {cartItem.ProductId} не найден");
                
                // Если заказ указан, проверяем его существование
                if (cartItem.OrderId.HasValue)
                {
                    var order = _dbContext.Orders.Find(cartItem.OrderId.Value);
                    if (order == null)
                        throw new InvalidOperationException($"Заказ с ID {cartItem.OrderId.Value} не найден");
                }
                
                // Если это элемент активной корзины (не в заказе), проверяем на дубликаты
                if (!cartItem.OrderId.HasValue)
                {
                    var existingItem = _dbContext.CartItems
                        .FirstOrDefault(ci => ci.ProductId == cartItem.ProductId && 
                                          ci.OrderId == null && 
                                          ci.UserId == cartItem.UserId);
                                          
                    if (existingItem != null)
                    {
                        // Увеличиваем количество, а не создаем новый элемент
                        existingItem.Quantity += cartItem.Quantity;
                        _dbContext.SaveChanges();
                        
                        Debug.WriteLine($"CartItemCrudService: Количество товара {cartItem.ProductId} в корзине увеличено");
                        CartItemsChanged?.Invoke(this, EventArgs.Empty);
                        
                        return existingItem;
                    }
                }
                
                _dbContext.CartItems.Add(cartItem);
                _dbContext.SaveChanges();
                
                Debug.WriteLine($"CartItemCrudService: Товар {cartItem.ProductId} добавлен в корзину с ID: {cartItem.Id}");
                CartItemsChanged?.Invoke(this, EventArgs.Empty);
                
                return cartItem;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"CartItemCrudService: Ошибка при добавлении товара в корзину: {ex.Message}");
                throw;
            }
        }
        
        public List<CartItem> GetCartItemsByUserId(int userId)
        {
            try
            {
                var cartItems = _dbContext.CartItems
                    .Include(ci => ci.Product)
                    .Where(ci => ci.UserId == userId && ci.OrderId == null)
                    .ToList();
                    
                Debug.WriteLine($"CartItemCrudService: Найдено {cartItems.Count} товаров в корзине пользователя {userId}");
                
                return cartItems;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"CartItemCrudService: Ошибка при получении корзины пользователя: {ex.Message}");
                throw;
            }
        }
        
        public List<CartItem> GetCartItemsByOrderId(int orderId)
        {
            try
            {
                var orderItems = _dbContext.CartItems
                    .Include(ci => ci.Product)
                    .Where(ci => ci.OrderId == orderId)
                    .ToList();
                    
                Debug.WriteLine($"CartItemCrudService: Найдено {orderItems.Count} товаров в заказе {orderId}");
                
                return orderItems;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"CartItemCrudService: Ошибка при получении товаров заказа: {ex.Message}");
                throw;
            }
        }
        
        public CartItem GetCartItemById(int id)
        {
            try
            {
                var cartItem = _dbContext.CartItems
                    .Include(ci => ci.Product)
                    .FirstOrDefault(ci => ci.Id == id);
                    
                if (cartItem == null)
                    Debug.WriteLine($"CartItemCrudService: Элемент корзины с ID {id} не найден");
                    
                return cartItem;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"CartItemCrudService: Ошибка при получении элемента корзины: {ex.Message}");
                throw;
            }
        }
        
        public CartItem UpdateCartItemQuantity(int id, int quantity)
        {
            try
            {
                if (quantity <= 0)
                    throw new ArgumentException("Количество должно быть больше нуля", nameof(quantity));
                    
                var cartItem = _dbContext.CartItems.Find(id);
                if (cartItem == null)
                    throw new InvalidOperationException($"Элемент корзины с ID {id} не найден");
                
                cartItem.Quantity = quantity;
                _dbContext.SaveChanges();
                
                Debug.WriteLine($"CartItemCrudService: Количество товара в корзине обновлено: {quantity}");
                CartItemsChanged?.Invoke(this, EventArgs.Empty);
                
                return cartItem;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"CartItemCrudService: Ошибка при обновлении количества товара: {ex.Message}");
                throw;
            }
        }
        
        public bool DeleteCartItem(int id)
        {
            try
            {
                var cartItem = _dbContext.CartItems.Find(id);
                if (cartItem == null)
                {
                    Debug.WriteLine($"CartItemCrudService: Элемент корзины с ID {id} не найден");
                    return false;
                }
                
                _dbContext.CartItems.Remove(cartItem);
                _dbContext.SaveChanges();
                
                Debug.WriteLine($"CartItemCrudService: Элемент корзины с ID {id} успешно удален");
                CartItemsChanged?.Invoke(this, EventArgs.Empty);
                
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"CartItemCrudService: Ошибка при удалении элемента корзины: {ex.Message}");
                throw;
            }
        }
        
        public bool ClearCart(int userId)
        {
            try
            {
                var cartItems = _dbContext.CartItems
                    .Where(ci => ci.UserId == userId && ci.OrderId == null)
                    .ToList();
                    
                if (!cartItems.Any())
                {
                    Debug.WriteLine($"CartItemCrudService: Корзина пользователя {userId} уже пуста");
                    return true;
                }
                
                _dbContext.CartItems.RemoveRange(cartItems);
                _dbContext.SaveChanges();
                
                Debug.WriteLine($"CartItemCrudService: Корзина пользователя {userId} очищена");
                CartItemsChanged?.Invoke(this, EventArgs.Empty);
                
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"CartItemCrudService: Ошибка при очистке корзины: {ex.Message}");
                throw;
            }
        }
        
        public decimal CalculateCartTotal(int userId)
        {
            try
            {
                var total = _dbContext.CartItems
                    .Where(ci => ci.UserId == userId && ci.OrderId == null)
                    .Join(_dbContext.Products, 
                         ci => ci.ProductId, 
                         p => p.Id, 
                         (ci, p) => new { 
                             Quantity = ci.Quantity, 
                             Price = p.Price, 
                             Discount = p.Discount 
                         })
                    .Sum(x => x.Quantity * x.Price * (1 - x.Discount / 100));
                    
                Debug.WriteLine($"CartItemCrudService: Сумма корзины пользователя {userId}: {total}");
                
                return total;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"CartItemCrudService: Ошибка при расчете суммы корзины: {ex.Message}");
                throw;
            }
        }
        
        public bool MoveCartItemsToOrder(int userId, int orderId)
        {
            try
            {
                var cartItems = _dbContext.CartItems
                    .Where(ci => ci.UserId == userId && ci.OrderId == null)
                    .ToList();
                    
                if (!cartItems.Any())
                {
                    Debug.WriteLine($"CartItemCrudService: Корзина пользователя {userId} пуста");
                    return false;
                }
                
                foreach (var item in cartItems)
                {
                    item.OrderId = orderId;
                }
                
                _dbContext.SaveChanges();
                
                Debug.WriteLine($"CartItemCrudService: Товары перемещены из корзины в заказ {orderId}");
                CartItemsChanged?.Invoke(this, EventArgs.Empty);
                
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"CartItemCrudService: Ошибка при перемещении товаров в заказ: {ex.Message}");
                throw;
            }
        }
    }
} 