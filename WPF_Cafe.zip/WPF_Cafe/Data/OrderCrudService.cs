using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using WpfApp1.Data;
using WpfApp1.Models;

namespace WpfApp1.Data
{
    public class OrderCrudService
    {
        private readonly CafeDbContext _dbContext;
        
        public event EventHandler OrdersChanged;
        
        public OrderCrudService()
        {
            _dbContext = new CafeDbContext();
        }
        
        public Order CreateOrder(Order order)
        {
            try
            {
                if (order == null)
                    throw new ArgumentNullException(nameof(order));
                    
                // Устанавливаем время создания
                if (order.OrderDate == default)
                    order.OrderDate = DateTime.Now;
                
                // Проверяем наличие элементов заказа и устанавливаем связи
                if (order.Items != null && order.Items.Any())
                {
                    foreach (var item in order.Items)
                    {
                        // Убедимся, что id элемента заказа равен 0 для создания новой записи
                        item.Id = 0;
                        // Убедимся, что свойство Product равно null для корректного сохранения
                        item.Product = null;
                    }
                }
                
                // Создаем новый контекст, чтобы избежать проблем с отслеживанием объектов
                using (var context = new CafeDbContext())
                {
                    // Отключаем автоматическое обнаружение изменений для лучшей производительности
                    context.Configuration.AutoDetectChangesEnabled = false;
                    
                    // Создаем новый объект заказа
                    var newOrder = new Order
                    {
                        UserId = order.UserId,
                        Status = order.Status,
                        OrderDate = order.OrderDate,
                        DeliveryAddress = order.DeliveryAddress,
                        ContactPhone = order.ContactPhone,
                        Note = order.Note,
                        TotalAmount = order.TotalAmount
                    };
                    
                    // Добавляем заказ
                    context.Orders.Add(newOrder);
                    context.SaveChanges();
                    
                    // Добавляем элементы заказа с установленным OrderId
                    if (order.Items != null && order.Items.Any())
                    {
                        foreach (var item in order.Items)
                        {
                            var newItem = new CartItem
                            {
                                OrderId = newOrder.Id,
                                ProductId = item.ProductId,
                                Price = item.Price,
                                Quantity = item.Quantity,
                                UserId = item.UserId,
                                ProductImage = item.ProductImage
                            };
                            
                            context.CartItems.Add(newItem);
                        }
                        
                        context.SaveChanges();
                    }
                    
                    // Копируем ID созданного заказа
                    order.Id = newOrder.Id;
                    
                    Debug.WriteLine($"OrderCrudService: Заказ создан с ID: {order.Id}");
                    OrdersChanged?.Invoke(this, EventArgs.Empty);
                    
                    return GetOrderById(order.Id); // Возвращаем полный заказ с элементами
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"OrderCrudService: Ошибка при создании заказа: {ex.Message}");
                Debug.WriteLine($"OrderCrudService: {ex.StackTrace}");
                throw;
            }
        }
        
        public List<Order> GetAllOrders()
        {
            try
            {
                return _dbContext.Orders
                    .Include(o => o.Items)
                    .ToList();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"OrderCrudService: Ошибка при получении списка заказов: {ex.Message}");
                return new List<Order>();
            }
        }
        
        public Order GetOrderById(int id)
        {
            try
            {
                return _dbContext.Orders
                    .Include(o => o.Items)
                    .FirstOrDefault(o => o.Id == id);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"OrderCrudService: Ошибка при получении заказа: {ex.Message}");
                return null;
            }
        }
        
        public List<Order> GetOrdersByUserId(int userId)
        {
            try
            {
                return _dbContext.Orders
                    .Include(o => o.Items)
                    .Where(o => o.UserId == userId)
                    .OrderByDescending(o => o.OrderDate)
                    .ToList();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"OrderCrudService: Ошибка при получении заказов пользователя: {ex.Message}");
                return new List<Order>();
            }
        }
        
        public Order UpdateOrder(Order order)
        {
            try
            {
                if (order == null)
                    throw new ArgumentNullException(nameof(order));
                    
                if (order.Id == 0)
                    throw new ArgumentException("ID заказа не может быть 0", nameof(order));
                    
                var existingOrder = _dbContext.Orders
                    .Include(o => o.Items)
                    .FirstOrDefault(o => o.Id == order.Id);
                    
                if (existingOrder == null)
                    throw new InvalidOperationException($"Заказ с ID {order.Id} не найден");
                
                // Обновляем основные свойства заказа
                existingOrder.Status = order.Status;
                existingOrder.DeliveryAddress = order.DeliveryAddress;
                existingOrder.ContactPhone = order.ContactPhone;
                existingOrder.TotalAmount = order.TotalAmount;
                existingOrder.DeliveryDate = order.DeliveryDate;
                existingOrder.Note = order.Note;
                
                // Если обновлены элементы заказа
                if (order.Items != null && order.Items.Any())
                {
                    // Удаляем старые элементы
                    var existingItems = _dbContext.CartItems
                        .Where(ci => ci.OrderId == order.Id)
                        .ToList();
                        
                    foreach (var item in existingItems)
                    {
                        _dbContext.CartItems.Remove(item);
                    }
                    
                    // Добавляем новые элементы
                    foreach (var item in order.Items)
                    {
                        item.OrderId = order.Id;
                        _dbContext.CartItems.Add(item);
                    }
                }
                
                _dbContext.SaveChanges();
                
                Debug.WriteLine($"OrderCrudService: Заказ с ID {order.Id} успешно обновлен");
                OrdersChanged?.Invoke(this, EventArgs.Empty);
                
                return existingOrder;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"OrderCrudService: Ошибка при обновлении заказа: {ex.Message}");
                throw;
            }
        }
        
        public Order UpdateOrderStatus(int orderId, string status)
        {
            try
            {
                var order = _dbContext.Orders.Find(orderId);
                if (order == null)
                    throw new InvalidOperationException($"Заказ с ID {orderId} не найден");
                    
                order.Status = status;
                
                // Если статус "Выполнен" или "Completed", устанавливаем дату доставки и обновляем товары
                if (status == "Выполнен" || status == "Completed")
                {
                    order.DeliveryDate = DateTime.Now;
                    
                    // Загружаем элементы заказа, если их еще нет
                    if (order.Items == null || !order.Items.Any())
                    {
                        var orderWithItems = _dbContext.Orders
                            .Include(o => o.Items)
                            .FirstOrDefault(o => o.Id == orderId);
                        
                        if (orderWithItems != null && orderWithItems.Items != null && orderWithItems.Items.Any())
                        {
                            // Обновляем товары - при вызове из OrderService.UpdateOrderStatus 
                            // обновление товаров будет произведено через ProductService
                            
                            // Добавляем проверки на null и логирование для диагностики
                            Debug.WriteLine($"OrderCrudService: Заказ {orderId} имеет {orderWithItems.Items.Count} товаров");
                            
                            // Проверяем наличие App.ProductCrudService
                            if (App.ProductCrudService == null)
                            {
                                Debug.WriteLine("OrderCrudService: App.ProductCrudService is null, creating new instance");
                            }
                            
                            // Проверяем каждый товар в заказе
                            foreach (var item in orderWithItems.Items)
                            {
                                if (item == null)
                                {
                                    Debug.WriteLine("OrderCrudService: Item в заказе равен null");
                                    continue;
                                }
                                
                                Debug.WriteLine($"OrderCrudService: Товар ID: {item.ProductId}, Количество: {item.Quantity}");
                                if (item.Product == null)
                                {
                                    Debug.WriteLine($"OrderCrudService: Товар.Product is null для ProductId: {item.ProductId}");
                                }
                            }
                            
                            try
                            {
                                // Создаем экземпляр ProductCrudService и выполняем обновление товаров
                                var productCrudService = App.ProductCrudService ?? new ProductCrudService();
                                productCrudService.UpdateProductsAfterPurchase(orderWithItems.Items);
                                Debug.WriteLine($"OrderCrudService: Обновлены товары для заказа {orderId}");
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine($"OrderCrudService: Ошибка при обновлении товаров: {ex.Message}");
                                Debug.WriteLine($"OrderCrudService: StackTrace: {ex.StackTrace}");
                                // Не выбрасываем исключение дальше, чтобы не прерывать выполнение
                            }
                        }
                        else
                        {
                            if (orderWithItems == null)
                            {
                                Debug.WriteLine($"OrderCrudService: Заказ с ID {orderId} не найден при загрузке с включением элементов");
                            }
                            else if (orderWithItems.Items == null)
                            {
                                Debug.WriteLine($"OrderCrudService: У заказа с ID {orderId} коллекция Items равна null");
                            }
                            else if (!orderWithItems.Items.Any())
                            {
                                Debug.WriteLine($"OrderCrudService: У заказа с ID {orderId} нет товаров (пустая коллекция)");
                            }
                        }
                    }
                }
                
                _dbContext.SaveChanges();
                
                Debug.WriteLine($"OrderCrudService: Статус заказа {orderId} успешно обновлен на '{status}'");
                OrdersChanged?.Invoke(this, EventArgs.Empty);
                
                return order;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"OrderCrudService: Ошибка при обновлении статуса заказа: {ex.Message}");
                throw;
            }
        }
        
        public bool DeleteOrder(int id)
        {
            try
            {
                var order = _dbContext.Orders
                    .Include(o => o.Items)
                    .FirstOrDefault(o => o.Id == id);
                    
                if (order == null)
                {
                    Debug.WriteLine($"OrderCrudService: Заказ с ID {id} не найден");
                    return false;
                }
                
                // Удаляем все элементы заказа
                foreach (var item in order.Items.ToList())
                {
                    _dbContext.CartItems.Remove(item);
                }
                
                // Удаляем сам заказ
                _dbContext.Orders.Remove(order);
                _dbContext.SaveChanges();
                
                Debug.WriteLine($"OrderCrudService: Заказ с ID {id} успешно удален");
                OrdersChanged?.Invoke(this, EventArgs.Empty);
                
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"OrderCrudService: Ошибка при удалении заказа: {ex.Message}");
                throw;
            }
        }
        
        public List<Order> SearchOrders(DateTime? fromDate = null, DateTime? toDate = null, 
                                 string status = null, int? userId = null)
        {
            try
            {
                var query = _dbContext.Orders
                    .Include(o => o.Items)
                    .AsQueryable();
                    
                // Применяем фильтры
                if (fromDate.HasValue)
                    query = query.Where(o => o.OrderDate >= fromDate.Value);
                    
                if (toDate.HasValue)
                    query = query.Where(o => o.OrderDate <= toDate.Value);
                    
                if (!string.IsNullOrEmpty(status))
                    query = query.Where(o => o.Status == status);
                    
                if (userId.HasValue)
                    query = query.Where(o => o.UserId == userId.Value);
                    
                // Сортируем по дате (новые сначала)
                query = query.OrderByDescending(o => o.OrderDate);
                
                return query.ToList();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"OrderCrudService: Ошибка при поиске заказов: {ex.Message}");
                throw;
            }
        }
        
        public Dictionary<string, int> GetOrderStatisticsByStatus()
        {
            try
            {
                var statuses = _dbContext.Orders
                    .GroupBy(o => o.Status)
                    .Select(g => new { Status = g.Key, Count = g.Count() })
                    .ToList();
                    
                var result = statuses.ToDictionary(
                    s => s.Status ?? "Неизвестно", 
                    s => s.Count
                );
                
                Debug.WriteLine($"OrderCrudService: Статистика по статусам заказов получена");
                
                return result;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"OrderCrudService: Ошибка при получении статистики заказов: {ex.Message}");
                throw;
            }
        }
    }
} 