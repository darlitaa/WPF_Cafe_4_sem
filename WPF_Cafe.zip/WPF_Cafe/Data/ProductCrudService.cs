using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using WpfApp1.Data;
using WpfApp1.Models;

namespace WpfApp1.Data
{
    public class ProductCrudService
    {
        private readonly CafeDbContext _dbContext;
        
        public event EventHandler ProductsChanged;
        
        public ProductCrudService()
        {
            _dbContext = new CafeDbContext();
        }
          
        public Product CreateProduct(Product product)
        {
            try
            {
                if (product == null)
                    throw new ArgumentNullException(nameof(product));
                    
                Debug.WriteLine($"ProductCrudService: Создание нового продукта: {product.FullName}");
                _dbContext.Products.Add(product);
                _dbContext.SaveChanges();
                
                Debug.WriteLine($"ProductCrudService: Продукт создан с ID: {product.Id}");
                ProductsChanged?.Invoke(this, EventArgs.Empty);
                
                return product;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ProductCrudService: Ошибка при создании продукта: {ex.Message}");
                throw;
            }
        }
        
        public List<Product> GetAllProducts()
        {
            try 
            {
                return _dbContext.Products.ToList();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ProductCrudService: Ошибка при получении списка продуктов: {ex.Message}");
                return new List<Product>();
            }
        }
        
        public Product GetProductById(int id)
        {
            try 
            {
                return _dbContext.Products.FirstOrDefault(p => p.Id == id);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ProductCrudService: Ошибка при получении продукта по ID {id}: {ex.Message}");
                return null;
            }
        }
        
        public Product UpdateProduct(Product product)
        {
            try 
            {
                var existingProduct = _dbContext.Products.Find(product.Id);
                if (existingProduct == null)
                    throw new InvalidOperationException($"Продукт с ID {product.Id} не найден");
                
                // Обновляем свойства существующего продукта
                _dbContext.Entry(existingProduct).CurrentValues.SetValues(product);
                _dbContext.SaveChanges();
                
                Debug.WriteLine($"ProductCrudService: Продукт с ID {product.Id} успешно обновлен");
                ProductsChanged?.Invoke(this, EventArgs.Empty);
                
                return existingProduct;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ProductCrudService: Ошибка при обновлении продукта: {ex.Message}");
                throw;
            }
        }
        
        public bool DeleteProduct(int id)
        {
            try 
            {
                var product = _dbContext.Products.Find(id);
                if (product == null)
                {
                    Debug.WriteLine($"ProductCrudService: Продукт с ID {id} не найден");
                    return false;
                }
                
                // Проверяем, есть ли товар в заказах
                bool isInOrders = _dbContext.CartItems.Any(ci => ci.ProductId == id);
                if (isInOrders)
                {
                    Debug.WriteLine($"ProductCrudService: Нельзя удалить продукт с ID {id}, так как он есть в заказах");
                    throw new InvalidOperationException("Нельзя удалить продукт, так как он есть в заказах");
                }
                
                _dbContext.Products.Remove(product);
                _dbContext.SaveChanges();
                
                Debug.WriteLine($"ProductCrudService: Продукт с ID {id} успешно удален");
                ProductsChanged?.Invoke(this, EventArgs.Empty);
                
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ProductCrudService: Ошибка при удалении продукта: {ex.Message}");
                throw;
            }
        }
        
        public List<Product> SearchProducts(string searchTerm)
        {
            try 
            {
                if (string.IsNullOrWhiteSpace(searchTerm))
                    return GetAllProducts();
                    
                var query = _dbContext.Products.AsQueryable();
                
                // Поиск по различным полям
                query = query.Where(p => 
                    p.ShortName.Contains(searchTerm) || 
                    p.FullName.Contains(searchTerm) || 
                    p.Description.Contains(searchTerm) || 
                    p.Category.Contains(searchTerm) ||
                    p.Manufacturer.Contains(searchTerm));
                    
                var results = query.ToList();
                Debug.WriteLine($"ProductCrudService: Найдено {results.Count} продуктов");
                
                return results;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ProductCrudService: Ошибка при поиске продуктов: {ex.Message}");
                throw;
            }
        }
        
        public List<Product> GetProductsByCategory(string category)
        {
            try 
            {
                if (string.IsNullOrWhiteSpace(category))
                    return GetAllProducts();
                    
                var results = _dbContext.Products
                    .Where(p => p.Category.Equals(category, StringComparison.OrdinalIgnoreCase))
                    .ToList();
                    
                Debug.WriteLine($"ProductCrudService: Найдено {results.Count} продуктов в категории {category}");
                
                return results;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ProductCrudService: Ошибка при получении продуктов по категории: {ex.Message}");
                throw;
            }
        }
        
        public List<string> GetAllCategories()
        {
            try 
            {
                var categories = _dbContext.Products
                    .Select(p => p.Category)
                    .Distinct()
                    .ToList();
                    
                Debug.WriteLine($"ProductCrudService: Найдено {categories.Count} уникальных категорий");
                
                return categories;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ProductCrudService: Ошибка при получении списка категорий: {ex.Message}");
                throw;
            }
        }
        
        public List<string> GetAllManufacturers()
        {
            try 
            {
                var manufacturers = _dbContext.Products
                    .Select(p => p.Manufacturer)
                    .Where(m => !string.IsNullOrEmpty(m))
                    .Distinct()
                    .ToList();
                    
                Debug.WriteLine($"ProductCrudService: Найдено {manufacturers.Count} уникальных производителей");
                
                return manufacturers;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ProductCrudService: Ошибка при получении списка производителей: {ex.Message}");
                throw;
            }
        }
        
        public void UpdateProductsAfterPurchase(List<CartItem> purchasedItems)
        {
            if (purchasedItems == null || !purchasedItems.Any())
            {
                Debug.WriteLine("ProductCrudService: Список товаров для обновления пуст или null");
                return;
            }
            
            Debug.WriteLine($"ProductCrudService: Начато обновление {purchasedItems.Count} товаров после покупки");
            bool productsChanged = false;
            
            try
            {
                foreach (var item in purchasedItems)
                {
                    // Проверка на null
                    if (item == null)
                    {
                        Debug.WriteLine("ProductCrudService: Элемент в списке товаров равен null");
                        continue;
                    }
                    
                    // Определяем ID продукта
                    int productId = 0;
                    if (item.Product != null && item.Product.Id > 0)
                    {
                        productId = item.Product.Id;
                    }
                    else if (item.ProductId > 0)
                    {
                        productId = item.ProductId;
                    }
                    else
                    {
                        Debug.WriteLine("ProductCrudService: Невозможно определить ID продукта");
                        continue;
                    }
                    
                    // Проверяем, что количество товара положительное
                    if (item.Quantity <= 0)
                    {
                        Debug.WriteLine($"ProductCrudService: Количество товара с ID {productId} должно быть положительным");
                        continue;
                    }
                    
                    try
                    {
                        // Получаем продукт из базы данных с защитой от исключений
                        var product = _dbContext.Products.FirstOrDefault(p => p.Id == productId);
                        
                        if (product != null)
                        {
                            Debug.WriteLine($"ProductCrudService: Обновление товара ID {productId}: {product.ShortName}");
                            Debug.WriteLine($"ProductCrudService: Текущее количество: {product.Quantity}, Заказано: {item.Quantity}");
                            Debug.WriteLine($"ProductCrudService: Текущее число покупок: {product.TimesPurchased}");
                            
                            // Обновляем данные продукта с защитой от отрицательных значений
                            if (product.Quantity < item.Quantity)
                            {
                                Debug.WriteLine($"ProductCrudService: Предупреждение - заказанное количество ({item.Quantity}) больше доступного ({product.Quantity})");
                                product.Quantity = 0;
                            }
                            else
                            {
                                product.Quantity -= item.Quantity;
                            }
                            
                            product.InStock = product.Quantity > 0;
                            product.TimesPurchased += item.Quantity;
                            
                            Debug.WriteLine($"ProductCrudService: Новое количество: {product.Quantity}");
                            Debug.WriteLine($"ProductCrudService: Новое число покупок: {product.TimesPurchased}");
                            
                            productsChanged = true;
                        }
                        else
                        {
                            Debug.WriteLine($"ProductCrudService: Ошибка: Товар с ID {productId} не найден в базе данных");
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"ProductCrudService: Ошибка при обработке товара с ID {productId}: {ex.Message}");
                        // Продолжаем с другими товарами
                    }
                }
                
                if (productsChanged)
                {
                    try
                    {
                        // Сохраняем изменения в базе данных
                        _dbContext.SaveChanges();
                        Debug.WriteLine("ProductCrudService: Товары успешно обновлены после покупки");
                        
                        // Убедимся, что событие ProductsChanged вызывается
                        if (ProductsChanged != null)
                        {
                            Debug.WriteLine("ProductCrudService: Вызываем событие ProductsChanged");
                            ProductsChanged.Invoke(this, EventArgs.Empty);
                        }
                        else
                        {
                            Debug.WriteLine("ProductCrudService: Событие ProductsChanged равно null");
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"ProductCrudService: Ошибка при сохранении изменений в базе данных: {ex.Message}");
                        throw;
                    }
                }
                else
                {
                    Debug.WriteLine("ProductCrudService: Ни один товар не был обновлен после покупки");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ProductCrudService: Ошибка при обновлении товаров после покупки: {ex.Message}");
                Debug.WriteLine($"ProductCrudService: StackTrace: {ex.StackTrace}");
                throw;
            }
        }
    }
} 