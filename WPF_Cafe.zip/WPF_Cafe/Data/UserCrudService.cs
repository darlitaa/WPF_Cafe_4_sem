using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using WpfApp1.Data;
using WpfApp1.Models;
using System.Diagnostics;

namespace WpfApp1.Data
{
    public class UserCrudService
    {
        private readonly CafeDbContext _dbContext;
        
        public event EventHandler UsersChanged;

        public UserCrudService()
        {
            _dbContext = new CafeDbContext();
        }

        // Синхронные версии методов для совместимости с существующим кодом
        
        public User CreateUser(User user)
        {
            try
            {
                if (user == null)
                    throw new ArgumentNullException(nameof(user));
                    
                // Проверка, есть ли уже пользователь с таким именем
                if (_dbContext.Users.Any(u => u.Username == user.Username))
                    throw new InvalidOperationException($"Пользователь с именем {user.Username} уже существует");
                
                _dbContext.Users.Add(user);
                _dbContext.SaveChanges();
                
                Debug.WriteLine($"UserCrudService: Пользователь создан с ID: {user.Id}");
                UsersChanged?.Invoke(this, EventArgs.Empty);
                
                return user;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"UserCrudService: Ошибка при создании пользователя: {ex.Message}");
                throw;
            }
        }
        
        public List<User> GetAllUsers()
        {
            try
            {
                return _dbContext.Users.ToList();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"UserCrudService: Ошибка при получении списка пользователей: {ex.Message}");
                return new List<User>();
            }
        }
        
        public User GetUserById(int id)
        {
            try
            {
                return _dbContext.Users.Find(id);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"UserCrudService: Ошибка при получении пользователя по ID: {ex.Message}");
                return null;
            }
        }
        
        public User GetUserByUsername(string username)
        {
            try
            {
                return _dbContext.Users
                    .FirstOrDefault(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase));
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"UserCrudService: Ошибка при получении пользователя по имени: {ex.Message}");
                return null;
            }
        }
        
        public User UpdateUser(User user)
        {
            try
            {
                if (user == null)
                    throw new ArgumentNullException(nameof(user));
                    
                if (user.Id == 0)
                    throw new ArgumentException("ID пользователя не может быть 0", nameof(user));
                    
                var existingUser = _dbContext.Users.Find(user.Id);
                if (existingUser == null)
                    throw new InvalidOperationException($"Пользователь с ID {user.Id} не найден");
                
                // Проверка на уникальность имени пользователя
                if (existingUser.Username != user.Username && 
                    _dbContext.Users.Any(u => u.Username == user.Username))
                {
                    throw new InvalidOperationException($"Пользователь с именем {user.Username} уже существует");
                }
                
                // Обновляем свойства существующего пользователя
                _dbContext.Entry(existingUser).CurrentValues.SetValues(user);
                _dbContext.SaveChanges();
                
                Debug.WriteLine($"UserCrudService: Пользователь с ID {user.Id} успешно обновлен");
                UsersChanged?.Invoke(this, EventArgs.Empty);
                
                return existingUser;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"UserCrudService: Ошибка при обновлении пользователя: {ex.Message}");
                throw;
            }
        }
        
        public bool DeleteUser(int id)
        {
            try
            {
                var user = _dbContext.Users.Find(id);
                if (user == null)
                {
                    Debug.WriteLine($"UserCrudService: Пользователь с ID {id} не найден");
                    return false;
                }
                
                // Проверяем, есть ли у пользователя заказы
                bool hasOrders = _dbContext.Orders.Any(o => o.UserId == id);
                if (hasOrders)
                {
                    Debug.WriteLine($"UserCrudService: Нельзя удалить пользователя с ID {id}, так как у него есть заказы");
                    throw new InvalidOperationException("Нельзя удалить пользователя, так как у него есть заказы");
                }
                
                _dbContext.Users.Remove(user);
                _dbContext.SaveChanges();
                
                Debug.WriteLine($"UserCrudService: Пользователь с ID {id} успешно удален");
                UsersChanged?.Invoke(this, EventArgs.Empty);
                
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"UserCrudService: Ошибка при удалении пользователя: {ex.Message}");
                throw;
            }
        }
        
        public List<User> SearchUsers(string searchTerm)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(searchTerm))
                    return GetAllUsers();
                    
                var query = _dbContext.Users.AsQueryable();
                
                // Поиск по различным полям
                query = query.Where(u => 
                    u.Username.Contains(searchTerm) || 
                    u.FullName.Contains(searchTerm) || 
                    u.Email.Contains(searchTerm) || 
                    u.Phone.Contains(searchTerm) || 
                    u.Address.Contains(searchTerm));
                    
                return query.ToList();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"UserCrudService: Ошибка при поиске пользователей: {ex.Message}");
                throw;
            }
        }

        public bool AddUser(User user)
        {
            try
            {
                // Проверка на уникальность имени пользователя
                if (_dbContext.Users.Any(u => u.Username == user.Username))
                {
                    return false;
                }
                
                _dbContext.Users.Add(user);
                _dbContext.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при добавлении пользователя: {ex.Message}");
                return false;
            }
        }
        
        public bool AuthenticateUser(string username, string password)
        {
            try
            {
                var user = _dbContext.Users.FirstOrDefault(u => u.Username == username && u.Password == password);
                if (user != null)
                {
                    // Проверяем статус блокировки
                    if (user.IsBlocked)
                    {
                        Debug.WriteLine($"UserCrudService: Заблокированный пользователь {username} пытается войти в систему");
                        return false;
                    }
                    
                    // Обновляем дату последнего входа
                    user.LastLoginAt = DateTime.Now;
                    _dbContext.SaveChanges();
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при аутентификации пользователя: {ex.Message}");
                return false;
            }
        }
    }
} 