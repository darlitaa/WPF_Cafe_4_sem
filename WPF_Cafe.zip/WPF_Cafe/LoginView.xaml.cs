using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using WpfApp1.Services;
using WpfApp1.ViewModels;
using System.Threading;

namespace WpfApp1.Views
{
    public partial class LoginView : Window
    {
        private readonly LoginViewModel _viewModel;
        private readonly UserService _userService;
        private const double CompactModeThreshold = 700;

        public LoginView(UserService userService)
        {
            try
            {
                InitializeComponent();
                
                if (userService == null)
                {
                    MessageBox.Show("UserService не инициализирован", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                
                _userService = userService;
                _viewModel = new LoginViewModel(userService);
                
                if (Application.Current == null)
                {
                    MessageBox.Show("Application.Current is null", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                
                try
                {
                    _viewModel.Title = $"{(string)Application.Current.FindResource("Login")} - {(string)Application.Current.FindResource("AppName")}";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при загрузке ресурсов: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    _viewModel.Title = "Вход в систему";
                }
                
                DataContext = _viewModel;
                
                if (_viewModel != null)
                {
                    _viewModel.LoginSuccessful += ViewModel_LoginSuccessful;
                }
                
                if (PasswordBox != null)
                {
                    PasswordBox.PasswordChanged += PasswordBox_PasswordChanged;
                }
                
                if (CompactPasswordBox != null)
                {
                    CompactPasswordBox.PasswordChanged += PasswordBox_PasswordChanged;
                }
                
                UpdateLayoutMode();
                SetLanguageComboBoxSelections();
                ApplyCustomCursor();
                
                Loaded += LoginView_Loaded;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при инициализации окна входа: {ex.Message}\n\nСтек вызовов: {ex.StackTrace}", 
                    "Критическая ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Устаревший конструктор для обратной совместимости
        public LoginView(UserService userService, LocalizationService localizationService) : this(userService)
        {
            // Все настройки выполняются в основном конструкторе
        }

        private void LoginView_Loaded(object sender, RoutedEventArgs e)
        {
            ApplyCustomCursor();
        }

        private void ApplyCustomCursor()
        {
            if (CursorManager.CurrentCursor != null)
            {
                Cursor = CursorManager.CurrentCursor;
            }
        }

        private void SetLanguageComboBoxSelections()
        {
            var currentCulture = Thread.CurrentThread.CurrentUICulture.Name;
            if (currentCulture == "ru-RU")
            {
                cmbLanguage.SelectedIndex = 0;
                cmbLanguageCompact.SelectedIndex = 0;
            }
            else
            {
                cmbLanguage.SelectedIndex = 1;
                cmbLanguageCompact.SelectedIndex = 1;
            }
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            _viewModel.Password = ((PasswordBox)sender).Password;
        }

        private void ViewModel_LoginSuccessful(object sender, EventArgs e)
        {
            if (!_userService.IsUserLoggedIn())
            {
                return;
            }

            var mainView = new MainView();
            Application.Current.MainWindow = mainView;

            if (CursorManager.CurrentCursor != null)
            {
                mainView.Cursor = CursorManager.CurrentCursor;
            }
            
            mainView.Show();
            Close();
        }
        
        private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            UpdateLayoutMode();
        }

        private void UpdateLayoutMode()
        {
            if (ActualWidth < CompactModeThreshold)
            {
                NormalLayout.Visibility = Visibility.Collapsed;
                CompactLayout.Visibility = Visibility.Visible;
            }
            else
            {
                NormalLayout.Visibility = Visibility.Visible;
                CompactLayout.Visibility = Visibility.Collapsed;
            }
        }
        
        private void LanguageComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!IsLoaded || !(sender is ComboBox))
                return;
                
            ComboBox comboBox = (ComboBox)sender;

            if (comboBox == cmbLanguage && cmbLanguageCompact.SelectedIndex != comboBox.SelectedIndex)
                cmbLanguageCompact.SelectedIndex = comboBox.SelectedIndex;
            else if (comboBox == cmbLanguageCompact && cmbLanguage.SelectedIndex != comboBox.SelectedIndex)
                cmbLanguage.SelectedIndex = comboBox.SelectedIndex;

            CultureInfo newCulture;
            if (comboBox.SelectedIndex == 0)
                newCulture = new CultureInfo("ru-RU");
            else 
                newCulture = new CultureInfo("en-US");
                
            Thread.CurrentThread.CurrentCulture = newCulture;
            Thread.CurrentThread.CurrentUICulture = newCulture;
            
            // Перезагружаем ресурсы
            ResourceDictionary dict = new ResourceDictionary
            {
                Source = new Uri($"Resources/StringResources.{newCulture.Name}.xaml", UriKind.Relative)
            };

            Application.Current.Resources.MergedDictionaries.RemoveAt(0);
            Application.Current.Resources.MergedDictionaries.Insert(0, dict);
            
            // Обновляем заголовок
            _viewModel.Title = $"{(string)Application.Current.FindResource("Login")} - {(string)Application.Current.FindResource("AppName")}";
        }
    }
} 