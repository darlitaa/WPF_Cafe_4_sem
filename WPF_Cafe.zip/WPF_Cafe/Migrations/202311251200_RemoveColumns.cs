using System;
using System.Data.Entity.Migrations;
using System.Diagnostics;

namespace WpfApp1.Migrations
{
    public partial class RemoveColumns : DbMigration
    {
        public override void Up()
        {
            try
            {
                // Удаляем столбцы из таблицы Products
                DropColumn("dbo.Products", "Color");
                DropColumn("dbo.Products", "Size");
                DropColumn("dbo.Products", "CountryOfOrigin");
                
                // Удаляем столбец Discriminator из таблицы Users
                DropColumn("dbo.Users", "Discriminator");
                
                Debug.WriteLine("Миграция RemoveColumns успешно выполнена");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при выполнении миграции RemoveColumns: {ex.Message}");
                throw;
            }
        }
        
        public override void Down()
        {
            try
            {
                // Добавляем столбцы обратно (если нужен откат миграции)
                AddColumn("dbo.Products", "Color", c => c.String(maxLength: 50));
                AddColumn("dbo.Products", "Size", c => c.String(maxLength: 50));
                AddColumn("dbo.Products", "CountryOfOrigin", c => c.String(maxLength: 50));
                
                // Добавляем столбец Discriminator обратно
                AddColumn("dbo.Users", "Discriminator", c => c.String(nullable: false, maxLength: 128, defaultValue: "User"));
                
                Debug.WriteLine("Откат миграции RemoveColumns успешно выполнен");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при откате миграции RemoveColumns: {ex.Message}");
                throw;
            }
        }
    }
} 