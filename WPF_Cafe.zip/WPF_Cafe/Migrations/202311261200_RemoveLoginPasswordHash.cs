using System;
using System.Data.Entity.Migrations;
using System.Diagnostics;

namespace WpfApp1.Migrations
{
    public partial class RemoveLoginPasswordHash : DbMigration
    {
        public override void Up()
        {
            try
            {
                // Удаляем столбцы связанные с хешем пароля
                DropColumn("dbo.Users", "PasswordHash");
                
                Debug.WriteLine("Миграция RemoveLoginPasswordHash успешно выполнена");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при выполнении миграции RemoveLoginPasswordHash: {ex.Message}");
                throw;
            }
        }
        
        public override void Down()
        {
            try
            {
                // Добавляем столбцы обратно (если нужен откат миграции)
                AddColumn("dbo.Users", "PasswordHash", c => c.String(maxLength: 128));
                
                Debug.WriteLine("Откат миграции RemoveLoginPasswordHash успешно выполнен");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при откате миграции RemoveLoginPasswordHash: {ex.Message}");
                throw;
            }
        }
    }
} 