using System;
using System.Data.Entity.Migrations;
using System.Diagnostics;

namespace WpfApp1.Migrations
{
    public partial class AddNewFields : DbMigration
    {
        public override void Up()
        {
            try
            {
                // Добавляем столбец UserId в таблицу CartItems
                // Убираем условие not null, так как могут быть уже существующие записи
                AddColumn("dbo.CartItems", "UserId", c => c.Int());
                
                // Добавляем столбцы в таблицу Orders
                AddColumn("dbo.Orders", "ContactPhone", c => c.String(maxLength: 20));
                AddColumn("dbo.Orders", "DeliveryAddress", c => c.String(maxLength: 200));
                AddColumn("dbo.Orders", "Note", c => c.String(maxLength: 500));
                
                Debug.WriteLine("Миграция AddNewFields успешно выполнена");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при выполнении миграции AddNewFields: {ex.Message}");
                throw;
            }
        }
        
        public override void Down()
        {
            try
            {
                // Удаляем добавленные столбцы
                DropColumn("dbo.CartItems", "UserId");
                DropColumn("dbo.Orders", "ContactPhone");
                DropColumn("dbo.Orders", "DeliveryAddress");
                DropColumn("dbo.Orders", "Note");
                
                Debug.WriteLine("Откат миграции AddNewFields успешно выполнен");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при откате миграции AddNewFields: {ex.Message}");
                throw;
            }
        }
    }
} 