using System;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Collections.Generic;
using WpfApp1.Data;
using WpfApp1.Models;
using System.Diagnostics;

namespace WpfApp1.Migrations
{
    public sealed class Configuration : DbMigrationsConfiguration<CafeDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationDataLossAllowed = true;
            ContextKey = "WpfApp1.Data.CafeDbContext";
        }

        protected override void Seed(CafeDbContext context)
        {
            Debug.WriteLine("Сидирование базы данных с тестовыми данными...");

            try
            {
                // Если в базе данных нет пользователей, добавляем демо-данные
                if (!context.Users.Any())
                {
                    // Добавляем демо-пользователей
                    var users = new List<User>
                    {
                        new User
                        {
                            Username = "admin",
                            Password = "admin1",
                            FullName = "Администратор",
                            Email = "admin@cafe.by",
                            Address = "г. Минск, ул.Свердлова 13А",
                            Phone = "+375291234467",
                            IsAdmin = true
                        },
                        new User
                        {
                            Username = "client1",
                            Password = "client1",
                            FullName = "Иван Мирон",
                            Email = "ivan@example.com",
                            Address = "г. Минск, ул.Свердлова 13А",
                            Phone = "+375291234567",
                            IsAdmin = false
                        },
                        new User
                        {
                            Username = "client2",
                            Password = "client2",
                            FullName = "Литвинчук Дарья",
                            Email = "darlita@example.com",
                            Address = "г. Минск, ул.Белорусская 21",
                            Phone = "+375291567291",
                            IsAdmin = false
                        },
                        new User
                        {
                            Username = "client3",
                            Password = "client3",
                            FullName = "Дарья Кузнецова",
                            Email = "cus@example.com",
                            Address = "г. Минск, ул.Мирная 7А",
                            Phone = "+375299634537",
                            IsAdmin = false
                        },
                    };

                    users.ForEach(u => context.Users.AddOrUpdate(x => x.Username, u));
                    context.SaveChanges();
                    Debug.WriteLine($"Создано {users.Count} тестовых пользователей");
                }

                // Если в базе данных нет продуктов, добавляем демо-данные
                if (!context.Products.Any())
                {
                    // Добавляем демо-товары
                    var products = new List<Product>
                    {
                        new Product
                        {
                            ShortName = "Эспрессо",
                            FullName = "Эспрессо классический",
                            Description = "Крепкий классический кофе с насыщенным вкусом.",
                            Category = "Кофе",
                            ImagesJson = "[\"/Resources/Images/Espresso.jpg\"]",
                            Price = 2.5m,
                            Quantity = 100,
                            InStock = true,
                            Manufacturer = "Наше кафе",
                            TimesPurchased = 150
                        },
                        new Product
                        {
                            ShortName = "Латте",
                            FullName = "Кофе Латте с ванилью",
                            Description = "Нежный напиток из эспрессо и молока с ароматом ванили.",
                            Category = "Кофе",
                            ImagesJson = "[\"/Resources/Images/Latte.jpg\"]",
                            Price = 3.5m,
                            Quantity = 80,
                            InStock = true,
                            Manufacturer = "Наше кафе",
                            TimesPurchased = 120
                        },
                        new Product
                        {
                            ShortName = "Чизкейк",
                            FullName = "Чизкейк Нью-Йорк",
                            Description = "Классический американский десерт с нежной текстурой.",
                            Category = "Десерты",
                            ImagesJson = "[\"/Resources/Images/Cheesecake.jpg\"]",
                            Price = 7,
                            Quantity = 30,
                            InStock = true,
                            Manufacturer = "Наша пекарня",
                            TimesPurchased = 80
                        },
                        new Product
                        {
                            ShortName = "Круассан",
                            FullName = "Круассан классический с маслом",
                            Description = "Свежий хрустящий круассан, приготовленный по традиционному французскому рецепту.",
                            Category = "Закуски",
                            ImagesJson = "[\"/Resources/Images/Croissant.jpg\"]",
                            Price = 7,
                            Quantity = 40,
                            InStock = true,
                            Manufacturer = "Наша пекарня",
                            TimesPurchased = 95
                        },
                        new Product
                        {
                            ShortName = "Капучино",
                            FullName = "Капучино с корицей",
                            Description = "Классический капучино с пышной молочной пеной и присыпкой корицы.",
                            Category = "Кофе",
                            ImagesJson = "[\"/Resources/Images/Cappuccino.jpg\"]",
                            Price = 3.5m,
                            Quantity = 75,
                            InStock = true,
                            Manufacturer = "Наше кафе",
                            TimesPurchased = 110
                        },
                        new Product
                        {
                            ShortName = "Тирамису",
                            FullName = "Десерт Тирамису",
                            Description = "Итальянский десерт на основе сыра маскарпоне, кофе и бисквита савоярди.",
                            Category = "Десерты",
                            ImagesJson = "[\"/Resources/Images/Tiramisu.jpg\"]",
                            Price = 7,
                            Quantity = 25,
                            InStock = true,
                            Manufacturer = "Наша пекарня",
                            TimesPurchased = 70
                        }
                    };

                    products.ForEach(p => context.Products.AddOrUpdate(x => x.ShortName, p));
                    context.SaveChanges();
                    Debug.WriteLine($"Создано {products.Count} тестовых товаров");
                }

                // Создаем пример заказа, если нет ни одного заказа
                if (!context.Orders.Any())
                {
                    var clientUser = context.Users.FirstOrDefault(u => u.Username == "client");
                    if (clientUser != null)
                    {
                        var espresso = context.Products.FirstOrDefault(p => p.ShortName == "Эспрессо");
                        var cheesecake = context.Products.FirstOrDefault(p => p.ShortName == "Чизкейк");

                        if (espresso != null && cheesecake != null)
                        {
                            var order = new Order
                            {
                                UserId = clientUser.Id,
                                Status = "В обработке",
                                OrderDate = DateTime.Now.AddDays(-2),
                                DeliveryAddress = clientUser.Address,
                                ContactPhone = clientUser.Phone,
                                Items = new List<CartItem>
                                {
                                    new CartItem
                                    {
                                        ProductId = espresso.Id,
                                        Quantity = 2,
                                        Price = espresso.Price,
                                        ProductImage = espresso.ImagesJson
                                    },
                                    new CartItem
                                    {
                                        ProductId = cheesecake.Id,
                                        Quantity = 1,
                                        Price = cheesecake.Price,
                                        ProductImage = cheesecake.ImagesJson
                                    }
                                }
                            };

                            order.TotalAmount = order.Items.Sum(i => i.Price * i.Quantity);
                            context.Orders.Add(order);
                            context.SaveChanges();
                            Debug.WriteLine("Создан тестовый заказ");
                        }
                    }
                }

                Debug.WriteLine("Сидирование базы данных завершено успешно");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при сидировании базы данных: {ex.Message}");
                Debug.WriteLine(ex.StackTrace);
            }
        }
    }
}