using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Newtonsoft.Json;

namespace WpfApp1.Models
{
    public class CartItem
    {
        [Key]
        public int Id { get; set; }
        
        public int ProductId { get; set; }
        
        [NotMapped]
        public Product Product { get; set; }
        
        // Связь с заказом
        public int? OrderId { get; set; }
        
        [ForeignKey("OrderId")]
        [JsonIgnore]
        public virtual Order Order { get; set; }
        
        // Для сериализации в базу данных
        [JsonIgnore]
        public string ProductJson
        {
            get => Product != null ? JsonConvert.SerializeObject(Product) : null;
            set 
            {
                if (!string.IsNullOrEmpty(value))
                {
                    try
                    {
                        Product = JsonConvert.DeserializeObject<Product>(value);
                        
                        // Проверяем инициализацию списка Images
                        if (Product != null && Product.Images == null)
                        {
                            Product.Images = new System.Collections.Generic.List<string>();
                        }
                    }
                    catch (Exception ex)
                    {
                        // В случае ошибки десериализации создаем пустой продукт
                        System.Diagnostics.Debug.WriteLine($"Ошибка десериализации продукта: {ex.Message}");
                        Product = new Product { Id = ProductId };
                    }
                }
                else
                {
                    Product = null;
                }
            }
        }
        
        public int Quantity { get; set; }
        
        public decimal Price { get; set; }
        
        // Для хранения URL изображения продукта
        public string ProductImage { get; set; }
        
        // Расчетные свойства
        [NotMapped]
        public decimal TotalPrice => Quantity * Price;
        
        [NotMapped]
        public string ProductName => Product?.ShortName;
        
        // Метод для получения изображения продукта
        public string GetProductImage()
        {
            if (!string.IsNullOrEmpty(ProductImage))
                return ProductImage;

            if (Product == null)
                return "/Resources/Images/photo.jpg";
                
            // Проверяем, что Images не null и есть хотя бы один элемент
            if (Product.Images != null && Product.Images.Count > 0)
                return Product.Images[0];
                
            // Если Images пустой, но известен тип продукта, можем подставить дефолтное изображение
            if (!string.IsNullOrEmpty(Product.Category))
            {
                if (Product.Category.Equals("Кофе", StringComparison.OrdinalIgnoreCase))
                    return "/Resources/Images/Espresso.jpg";
                else if (Product.Category.Equals("Десерты", StringComparison.OrdinalIgnoreCase))
                    return "/Resources/Images/Cheesecake.jpg";
                else if (Product.Category.Equals("Закуски", StringComparison.OrdinalIgnoreCase))
                    return "/Resources/Images/Croissant.jpg";
            }
            
            // Возвращаем дефолтное изображение с полным путем
            return "/Resources/Images/photo.jpg";
        }

        public int? UserId { get; set; }
    }
} 