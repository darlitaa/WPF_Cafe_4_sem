using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace WpfApp1.Models
{
    public class Category : INotifyPropertyChanged
    {
        private bool _isSelected;
        private int? _customProductCount;
        private string _iconText = "📁";
        
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string ImagePath { get; set; }
        public List<Product> Products { get; set; } = new List<Product>();
        
        public string IconText
        {
            get => _iconText;
            set
            {
                if (_iconText != value)
                {
                    _iconText = value;
                    OnPropertyChanged();
                }
            }
        }
        
        public int ProductCount 
        { 
            get => _customProductCount ?? Products.Count;
            set 
            {
                _customProductCount = value;
                OnPropertyChanged();
            }
        }
        
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                if (_isSelected != value)
                {
                    _isSelected = value;
                    OnPropertyChanged();
                }
            }
        }
        
        public event PropertyChangedEventHandler PropertyChanged;
        
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
} 