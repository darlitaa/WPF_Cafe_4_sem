using System;

namespace WpfApp1.Models
{
    public class FilterEventArgs : EventArgs
    {
        public decimal MinPrice { get; set; }
        public decimal MaxPrice { get; set; }
        public bool ShowOnlyDiscounted { get; set; }
        public bool ShowOnlyInStock { get; set; }
        public string Manufacturer { get; set; }
    }
} 