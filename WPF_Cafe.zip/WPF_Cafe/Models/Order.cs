using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Newtonsoft.Json;
using System.Linq;

namespace WpfApp1.Models
{
    [Table("Orders")]
    public class Order
    {
        [Key]
        public int Id { get; set; }
        
        public int UserId { get; set; }
        
        [ForeignKey("UserId")]
        public virtual User User { get; set; }
        
        [Required]
        [MaxLength(20)]
        public string Status { get; set; }
        
        public DateTime OrderDate { get; set; }
        
        public DateTime? DeliveryDate { get; set; }
        
        // Коллекция элементов заказа
        public virtual List<CartItem> Items { get; set; }

		[MaxLength(200)]
		public string DeliveryAddress { get; set; }

		[MaxLength(20)]
        public string ContactPhone { get; set; }
        
        [MaxLength(500)]
        public string Note { get; set; }
        
        public decimal TotalAmount { get; set; }
        
        // Рассчитываем общую сумму заказа
        [NotMapped]
        public decimal CalculatedTotalAmount 
        { 
            get
            {
                if (Items == null || !Items.Any())
                    return 0;
                    
                return Items.Sum(i => i.Price * i.Quantity);
            }
        }

        public Order()
        {
            OrderDate = DateTime.Now;
            Status = "Pending";
            Items = new List<CartItem>();
        }
    }
} 