using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Windows;
using Newtonsoft.Json;

namespace WpfApp1.Models
{
    [Table("Products")]
    public class Product
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        [MaxLength(100)]
        public string ShortName { get; set; }
        
        [Required]
        [MaxLength(200)]
        public string FullName { get; set; }
        
        [MaxLength(1000)]
        public string Description { get; set; }
        
        [Required]
        [MaxLength(50)]
        public string Category { get; set; }
        
        [NotMapped]
        public List<string> Images { get; set; }
        
        // Строка с изображениями в формате JSON для хранения в базе данных
        [Column("Images")]
        public string ImagesJson
        {
            get => Images != null ? JsonConvert.SerializeObject(Images) : "[]";
            set 
            {
                try 
                {
                    Images = !string.IsNullOrEmpty(value) 
                        ? JsonConvert.DeserializeObject<List<string>>(value) 
                        : new List<string>();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Ошибка десериализации Images: {ex.Message}");
                    Images = new List<string>();
                }
                
                // Если нет изображений, добавим дефолтное в зависимости от категории
                if (Images.Count == 0 && !string.IsNullOrEmpty(Category))
                {
                    // Используем ImageService если он доступен
                    if (App.ImageService != null)
                    {
                        string defaultImage = App.ImageService.GetDefaultImageForCategory(Category);
                        Images.Add(defaultImage);
                    }
                    else
                    {
                        // Для обратной совместимости
                        if (Category.Equals("Кофе", StringComparison.OrdinalIgnoreCase))
                            Images.Add("Espresso.jpg");
                        else if (Category.Equals("Десерты", StringComparison.OrdinalIgnoreCase))
                            Images.Add("Cheesecake.jpg");
                        else if (Category.Equals("Закуски", StringComparison.OrdinalIgnoreCase))
                            Images.Add("Croissant.jpg");
                    }
                }
            }
        }
        
        public decimal Price { get; set; }
        
        public int Quantity { get; set; }
        
        public decimal Discount { get; set; }
        
        public bool InStock { get; set; }
        
        
        public int TimesPurchased { get; set; }
        
        [MaxLength(100)]
        public string Manufacturer { get; set; }
        
        [NotMapped]
        public bool HasDiscount => Discount > 0;
        
        [NotMapped]
        public decimal DiscountedPrice => Price * (1 - (decimal)Discount / 100);
        
        [NotMapped]
        public decimal OriginalPrice => Price;
        
        [NotMapped]
        public int DiscountPercent => (int)Discount;
        
        [NotMapped]
        public int SoldQuantity => TimesPurchased;
        
        [NotMapped]
        public int AvailableQuantity => Quantity;
        
        [NotMapped]
        public string LocalizedCategory
        { 
            get
            {
                if (Category == "Кофе")
                {
                    try
                    {
                        return (string)Application.Current.FindResource("Coffee");
                    }
                    catch
                    {
                        return "Coffee";
                    }
                }
                else if (Category == "Десерты")
                {
                    try
                    {
                        return (string)Application.Current.FindResource("Desserts");
                    }
                    catch
                    {
                        return "Desserts";
                    }
                }
                else if (Category == "Закуски")
                {
                    try
                    {
                        return (string)Application.Current.FindResource("Snacks");
                    }
                    catch
                    {
                        return "Snacks";
                    }
                }
                return Category;
            }
        }

        public Product()
        {
            Images = new List<string>();
        
        }
    }
} 