using System;

namespace WpfApp1.Models
{
    public class SearchOptions
    {

        public string SearchTerm { get; set; }
        public bool SearchInTitle { get; set; } = true;

        public bool SearchInDescription { get; set; } = true;
    }
} 