using System;
using System.Collections.Generic;
using System.Linq;
using WpfApp1.Models;
using WpfApp1.Services;

namespace WpfApp1.Services
{
    public class AddToCartCommand : IActionCommand
    {
        private readonly CartService _cartService;
        private readonly Product _product;
        private readonly int _quantity;

        public AddToCartCommand(CartService cartService, Product product, int quantity)
        {
            _cartService = cartService ?? throw new ArgumentNullException(nameof(cartService));
            _product = product ?? throw new ArgumentNullException(nameof(product));
            _quantity = quantity > 0 ? quantity : throw new ArgumentException("Количество должно быть больше нуля", nameof(quantity));
        }

        public void Execute()
        {
            _cartService.AddToCart(_product, _quantity);
        }

        public void Undo()
        {
            var cartItem = _cartService.CartItems.FirstOrDefault(item => item.Product.Id == _product.Id);
            if (cartItem != null)
            {
                if (cartItem.Quantity > _quantity)
                {
                    _cartService.UpdateQuantity(cartItem.Id, cartItem.Quantity - _quantity);
                }
                else
                {
                    _cartService.RemoveFromCart(cartItem.Id);
                }
            }
        }
    }

    public class RemoveFromCartCommand : IActionCommand
    {
        private readonly CartService _cartService;
        private readonly int _cartItemId;
        private CartItem _removedItem;
        private int _quantity;
        private bool _isLastItem; // Флаг, указывающий, является ли удаляемый товар последним в корзине

        public RemoveFromCartCommand(CartService cartService, int cartItemId)
        {
            _cartService = cartService ?? throw new ArgumentNullException(nameof(cartService));
            _cartItemId = cartItemId;
            
            // Сохраняем состояние перед удалением
            _removedItem = _cartService.CartItems.FirstOrDefault(item => item.Id == cartItemId);
            if (_removedItem != null)
            {
                _quantity = _removedItem.Quantity;
                
                // Проверяем, является ли этот товар последним в корзине
                _isLastItem = _cartService.CartItems.Count <= 1;
            }
        }

        public void Execute()
        {
            if (_removedItem != null)
            {
                _cartService.RemoveFromCart(_cartItemId);
            }
        }

        public void Undo()
        {
            if (_removedItem != null)
            {
                // Используем RestoreItem вместо AddToCart
                _cartService.RestoreItem(_cartItemId, _removedItem.Product, _quantity);
            }
        }
        
        // Свойство, указывающее, является ли удаляемый товар последним в корзине
        public bool IsLastItem => _isLastItem;
    }

    public class UpdateQuantityCommand : IActionCommand
    {
        private readonly CartService _cartService;
        private readonly int _cartItemId;
        private readonly int _newQuantity;
        private readonly int _oldQuantity;

        public UpdateQuantityCommand(CartService cartService, int cartItemId, int newQuantity)
        {
            _cartService = cartService ?? throw new ArgumentNullException(nameof(cartService));
            _cartItemId = cartItemId;
            _newQuantity = newQuantity > 0 ? newQuantity : throw new ArgumentException("Количество должно быть больше нуля", nameof(newQuantity));
            
            // Сохраняем старое количество для отмены
            var cartItem = _cartService.CartItems.FirstOrDefault(item => item.Id == cartItemId);
            _oldQuantity = cartItem?.Quantity ?? 0;
        }

        public void Execute()
        {
            _cartService.UpdateQuantity(_cartItemId, _newQuantity);
        }

        public void Undo()
        {
            if (_oldQuantity > 0)
            {
                _cartService.UpdateQuantity(_cartItemId, _oldQuantity);
            }
        }
    }

    public class ClearCartCommand : IActionCommand
    {
        private readonly CartService _cartService;
        private readonly List<CartItem> _cartItemsBackup;

        public ClearCartCommand(CartService cartService)
        {
            _cartService = cartService ?? throw new ArgumentNullException(nameof(cartService));
            // Создаем копию элементов корзины перед очисткой
            _cartItemsBackup = new List<CartItem>(_cartService.CartItems);
        }

        public void Execute()
        {
            _cartService.ClearCart();
        }

        public void Undo()
        {
            // Восстанавливаем все элементы
            foreach (var item in _cartItemsBackup)
            {
                _cartService.AddToCart(item.Product, item.Quantity);
            }
        }
    }
} 