using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using WpfApp1.Models;
using WpfApp1.Data;

namespace WpfApp1.Services
{
    public class CartService
    {
        private readonly ObservableCollection<CartItem> _cartItems;
        private readonly ProductService _productService;
        private Data.CartItemCrudService _cartItemCrudService;
        private int _nextCartItemId = 1;
        private int _currentUserId;
        
        public event EventHandler CartChanged;
        public ObservableCollection<CartItem> CartItems => _cartItems;
        public int ItemCount => _cartItems.Sum(item => item.Quantity);
        public decimal TotalPrice => _cartItems.Sum(item => item.TotalPrice);

        public JsonDataService JsonDataService { get; }
        public ProductService ProductService => _productService;

        public CartService(ProductService productService)
        {
            _productService = productService;
            _cartItems = new ObservableCollection<CartItem>();
            Initialize();
        }
        
        private void Initialize()
        {
            try
            {
                // Получаем существующий экземпляр CartItemCrudService или создаем новый
                _cartItemCrudService = App.CartItemCrudService ?? new Data.CartItemCrudService();
                
                // Подписываемся на события изменения корзины
                if (_cartItemCrudService != null)
                {
                    _cartItemCrudService.CartItemsChanged += (sender, args) => LoadCartFromDatabase();
                }
                
                Debug.WriteLine("CartService успешно инициализирован");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при инициализации CartService: {ex.Message}");
            }
        }
        
        // Загрузка корзины из базы данных для текущего пользователя
        public void LoadCartFromDatabase()
        {
            if (_currentUserId <= 0 || _cartItemCrudService == null)
                return;
                
            try
            {
                var cartItems = _cartItemCrudService.GetCartItemsByUserId(_currentUserId);
                
                _cartItems.Clear();
                foreach (var item in cartItems)
                {
                    _cartItems.Add(item);
                }
                
                // Находим максимальный Id для правильной генерации новых Id
                if (cartItems.Any())
                {
                    _nextCartItemId = cartItems.Max(i => i.Id) + 1;
                }
                else
                {
                    _nextCartItemId = 1;
                }
                
                Debug.WriteLine($"Загружено {cartItems.Count} товаров в корзину для пользователя {_currentUserId}");
                CartChanged?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при загрузке корзины из базы данных: {ex.Message}");
            }
        }
        
        public void SetCurrentUser(int userId)
        {
            if (_currentUserId != userId)
            {
                _currentUserId = userId;
                LoadCartFromDatabase();
            }
        }

        public void AddToCart(Product product, int quantity = 1)
        {
            if (product == null)
                throw new ArgumentNullException(nameof(product));
            if (quantity <= 0)
                throw new ArgumentException("Количество должно быть больше нуля", nameof(quantity));
            if (!product.InStock)
                throw new InvalidOperationException("Товар недоступен для заказа");
            
            try
            {
                if (_currentUserId > 0 && _cartItemCrudService != null)
                {
                    // Получаем полный путь к изображению
                    string imagePath = null;
                    if (product.Images != null && product.Images.Count > 0)
                    {
                        imagePath = product.Images[0];
                    }
                    else if (!string.IsNullOrEmpty(product.Category))
                    {
                        imagePath = GetDefaultImagePathForCategory(product.Category);
                    }
                    
                    // Работа с базой данных
                    var cartItem = new CartItem
                    {
                        ProductId = product.Id,
                        UserId = _currentUserId,
                        Price = product.DiscountedPrice,
                        Quantity = quantity,
                        Product = product,
                        ProductImage = imagePath
                    };
                    
                    var result = _cartItemCrudService.CreateCartItem(cartItem);
                    Debug.WriteLine($"Товар {product.FullName} добавлен в корзину пользователя {_currentUserId} через CartItemCrudService");
                    LoadCartFromDatabase(); // Обновляем корзину из базы данных
                }
                else
                {
                    // Работа с локальной корзиной
                    var existingItem = _cartItems.FirstOrDefault(item => 
                        (item.Product != null && item.Product.Id == product.Id) || 
                        (item.ProductId > 0 && item.ProductId == product.Id));
                        
                    if (existingItem != null)
                    {
                        existingItem.Quantity += quantity;
                    }
                    else
                    {
                        // Создаем глубокую копию продукта для предотвращения проблем с Images
                        Product productCopy = new Product
                        {
                            Id = product.Id,
                            ShortName = product.ShortName,
                            FullName = product.FullName,
                            Description = product.Description,
                            Category = product.Category,
                            Price = product.Price,
                            Quantity = product.Quantity,
                            Discount = product.Discount,
                            InStock = product.InStock,
                            Manufacturer = product.Manufacturer,
                            TimesPurchased = product.TimesPurchased
                        };

                        // Копируем список изображений
                        if (product.Images != null && product.Images.Count > 0)
                        {
                            productCopy.Images = new List<string>(product.Images);
                        }
                        else
                        {
                            productCopy.Images = new List<string>();
                            
                            // Если нет изображений, добавим дефолтное в зависимости от категории
                            if (!string.IsNullOrEmpty(product.Category))
                            {
                                // Получаем путь к изображению по умолчанию
                                string defaultImage = GetDefaultImagePathForCategory(product.Category);
                                productCopy.Images.Add(defaultImage);
                            }
                        }
                        
                        // Получаем изображение для CartItem
                        string productImage = null;
                        if (productCopy.Images != null && productCopy.Images.Count > 0)
                        {
                            productImage = productCopy.Images[0];
                        }
                        else if (!string.IsNullOrEmpty(product.Category))
                        {
                            productImage = GetDefaultImagePathForCategory(product.Category);
                        }
                        else
                        {
                            productImage = "/Resources/Images/photo.jpg";
                        }
                        
                        var cartItem = new CartItem
                        {
                            Id = _nextCartItemId++,
                            Product = productCopy,
                            ProductId = product.Id,
                            Price = product.DiscountedPrice,
                            Quantity = quantity,
                            ProductImage = productImage
                        };
                        
                        _cartItems.Add(cartItem);
                    }
                    
                    CartChanged?.Invoke(this, EventArgs.Empty);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при добавлении товара в корзину: {ex.Message}");
                throw;
            }
        }
        
        // Вспомогательный метод для получения пути к изображению по умолчанию
        private string GetDefaultImagePathForCategory(string category)
        {
            if (App.ImageService != null)
            {
                return App.ImageService.GetDefaultImageForCategory(category);
            }
            
            // Для обратной совместимости
            if (category.Equals("Кофе", StringComparison.OrdinalIgnoreCase))
                return "/Resources/Images/Espresso.jpg";
            else if (category.Equals("Десерты", StringComparison.OrdinalIgnoreCase))
                return "/Resources/Images/Cheesecake.jpg";
            else if (category.Equals("Закуски", StringComparison.OrdinalIgnoreCase))
                return "/Resources/Images/Croissant.jpg";
            
            return "/Resources/Images/photo.jpg";
        }
        
        public void RemoveFromCart(int cartItemId)
        {
            try
            {
                if (_currentUserId > 0 && _cartItemCrudService != null)
                {
                    // Работа с базой данных
                    var success = _cartItemCrudService.DeleteCartItem(cartItemId);
                    Debug.WriteLine($"Товар с ID {cartItemId} {(success ? "удален из" : "не найден в")} корзине пользователя {_currentUserId}");
                    LoadCartFromDatabase(); // Обновляем корзину из базы данных
                }
                else
                {
                    // Работа с локальной корзиной
                    var itemToRemove = _cartItems.FirstOrDefault(item => item.Id == cartItemId);
                    if (itemToRemove != null)
                    {
                        _cartItems.Remove(itemToRemove);
                        CartChanged?.Invoke(this, EventArgs.Empty);
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при удалении товара из корзины: {ex.Message}");
                throw;
            }
        }
        
        public void UpdateQuantity(int cartItemId, int newQuantity)
        {
            if (newQuantity <= 0)
                throw new ArgumentException("Количество должно быть больше нуля", nameof(newQuantity));
            
            try
            {
                if (_currentUserId > 0 && _cartItemCrudService != null)
                {
                    // Работа с базой данных
                    var updatedItem = _cartItemCrudService.UpdateCartItemQuantity(cartItemId, newQuantity);
                    Debug.WriteLine($"Количество товара {cartItemId} в корзине пользователя {_currentUserId} изменено на {newQuantity}");
                    LoadCartFromDatabase(); // Обновляем корзину из базы данных
                }
                else
                {
                    // Работа с локальной корзиной
                    var item = _cartItems.FirstOrDefault(i => i.Id == cartItemId);
                    if (item != null)
                    {
                        item.Quantity = newQuantity;
                        CartChanged?.Invoke(this, EventArgs.Empty);
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при обновлении количества товара: {ex.Message}");
                throw;
            }
        }
        
        public void ClearCart()
        {
            try
            {
                if (_currentUserId > 0 && _cartItemCrudService != null)
                {
                    // Работа с базой данных
                    var success = _cartItemCrudService.ClearCart(_currentUserId);
                    Debug.WriteLine($"Корзина пользователя {_currentUserId} очищена");
                    LoadCartFromDatabase(); // Обновляем корзину из базы данных
                }
                else
                {
                    // Работа с локальной корзиной
                    _cartItems.Clear();
                    CartChanged?.Invoke(this, EventArgs.Empty);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при очистке корзины: {ex.Message}");
                throw;
            }
        }

        // Новый метод для восстановления удаленного товара с сохранением оригинального ID и количества
        public void RestoreItem(int cartItemId, Product product, int quantity)
        {
            try
            {
                if (_currentUserId > 0 && _cartItemCrudService != null)
                {
                    // Работа с базой данных
                    var cartItem = new CartItem
                    {
                        ProductId = product.Id,
                        UserId = _currentUserId,
                        Price = product.DiscountedPrice,
                        Quantity = quantity,
                        Product = product,
                        ProductImage = null
                    };
                    
                    // Используем GetProductImage для правильного определения пути изображения
                    cartItem.ProductImage = cartItem.GetProductImage();
                    
                    var result = _cartItemCrudService.CreateCartItem(cartItem);
                    Debug.WriteLine($"Товар {product.FullName} восстановлен в корзине пользователя {_currentUserId}");
                    LoadCartFromDatabase(); // Обновляем корзину из базы данных
                }
                else
                {
                    // Работа с локальной корзиной
                    // Проверяем, не существует ли уже товар с таким ID продукта
                    var existingItem = _cartItems.FirstOrDefault(item => 
                        (item.Product != null && item.Product.Id == product.Id) || 
                        (item.ProductId > 0 && item.ProductId == product.Id));
                    
                    // Если товар с таким ID продукта уже есть, просто увеличиваем его количество
                    if (existingItem != null)
                    {
                        existingItem.Quantity = quantity;
                    }
                    else
                    {
                        // Создаем глубокую копию продукта для предотвращения проблем с Images
                        Product productCopy = new Product
                        {
                            Id = product.Id,
                            ShortName = product.ShortName,
                            FullName = product.FullName,
                            Description = product.Description,
                            Category = product.Category,
                            Price = product.Price,
                            Quantity = product.Quantity,
                            Discount = product.Discount,
                            InStock = product.InStock,
                            Manufacturer = product.Manufacturer,
                            TimesPurchased = product.TimesPurchased
                        };

                        // Копируем список изображений
                        if (product.Images != null && product.Images.Count > 0)
                        {
                            productCopy.Images = new List<string>(product.Images);
                        }
                        else
                        {
                            productCopy.Images = new List<string>();
                            
                            // Если нет изображений, добавим дефолтное в зависимости от категории
                            if (!string.IsNullOrEmpty(product.Category))
                            {
                                // Используем ImageService для получения изображения по умолчанию
                                string defaultImage = App.ImageService.GetDefaultImageForCategory(product.Category);
                                productCopy.Images.Add(defaultImage);
                            }
                        }
                        
                        // Создаем новый элемент корзины с оригинальным ID
                        var cartItem = new CartItem
                        {
                            Id = cartItemId, // Используем тот же ID, что был у удаленного элемента
                            Product = productCopy,
                            ProductId = product.Id,
                            Price = product.DiscountedPrice,
                            Quantity = quantity,
                            ProductImage = null
                        };
                        
                        // Используем GetProductImage для получения правильного пути изображения
                        cartItem.ProductImage = cartItem.GetProductImage();
                        
                        _cartItems.Add(cartItem);
                        
                        // Если ID восстановленного элемента больше счетчика, увеличиваем счетчик
                        if (cartItemId >= _nextCartItemId)
                        {
                            _nextCartItemId = cartItemId + 1;
                        }
                    }
                    
                    CartChanged?.Invoke(this, EventArgs.Empty);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при восстановлении товара в корзине: {ex.Message}");
                throw;
            }
        }
        
        // Метод для перемещения товаров корзины в заказ
        public bool MoveCartItemsToOrder(int orderId)
        {
            try
            {
                if (_currentUserId > 0 && _cartItemCrudService != null)
                {
                    // Работа с базой данных
                    var success = _cartItemCrudService.MoveCartItemsToOrder(_currentUserId, orderId);
                    Debug.WriteLine($"Товары из корзины пользователя {_currentUserId} перемещены в заказ {orderId}");
                    
                    if (success)
                    {
                        LoadCartFromDatabase(); // Обновляем корзину из базы данных
                        return true;
                    }
                    return false;
                }
                else
                {
                    // В случае локальной корзины этот метод не используется
                    // Очистка корзины происходит в методе CreateOrder сервиса OrderService
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при перемещении товаров в заказ: {ex.Message}");
                return false;
            }
        }
    }
}