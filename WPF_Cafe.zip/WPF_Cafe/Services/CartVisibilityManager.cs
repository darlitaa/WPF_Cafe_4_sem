using System;
using System.Windows;
using WpfApp1.Views;

namespace WpfApp1.Services
{
    /// <summary>
    /// Глобальный менеджер для управления видимостью корзины из любого места приложения
    /// </summary>
    public static class CartVisibilityManager
    {
        /// <summary>
        /// Попытка показать корзину всеми возможными способами
        /// </summary>
        public static void ShowCart()
        {
            // Перебираем все открытые окна
            foreach (Window window in Application.Current.Windows)
            {
                if (window is MainView mainView && window.IsVisible)
                {
                    try
                    {
                        // Вызываем публичный метод ShowCart
                        mainView.ShowCart();
                        
                        // Дополнительно обновляем лейаут
                        mainView.UpdateLayout();
                        
                        // Нашли и показали - выходим
                        return;
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine($"Ошибка при попытке открыть корзину через MainView: {ex.Message}");
                    }
                }
            }

            // Если не удалось найти MainView, выводим отладочное сообщение
            System.Diagnostics.Debug.WriteLine("Не удалось найти открытое окно MainView для отображения корзины");
        }
    }
} 