using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Media.Imaging;
using System.Linq;
using System.Windows;
using Microsoft.Win32;
using System.Diagnostics;
using System.Reflection;

namespace WpfApp1.Services
{
	/// <summary>
	/// Сервис для работы с продуктовыми картинками
	/// </summary>
	public class ImageService
	{
		private readonly string _defaultImagePath = "/Resources/Images/photo.jpg";
		private readonly Dictionary<string, string> _categoryDefaultImages = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
		{
			{ "Кофе", "/Resources/Images/Espresso.jpg" },
			{ "Десерты", "/Resources/Images/Cheesecake.jpg" },
			{ "Выпечка", "/Resources/Images/Croissant.jpg" }
		};

		private readonly Dictionary<string, string> _fileNameCaseMapping = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
		{
			{ "cheesecake.jpg", "Cheesecake.jpg" },
			{ "croissant.jpg", "Croissant.jpg" },
			{ "espresso.jpg", "Espresso.jpg" },
			{ "latte.jpg", "Latte.jpg" },
			{ "cappuccino.jpg", "Cappuccino.jpg" },
			{ "tiramisu.jpg", "Tiramisu.jpg" }
		};

		// Директория для сохранения загруженных изображений
		private readonly string _uploadDirectory;
		// Директория для ресурсных изображений
		private readonly string _resourcesImagesDirectory;
		// Базовая директория проекта
		private readonly string _projectDirectory;

		public ImageService()
		{
			// Получаем директорию проекта (корневую папку)
			_projectDirectory = Directory.GetCurrentDirectory();
			
			// Создаем папку для загрузки если ее нет
			_uploadDirectory = Path.Combine(_projectDirectory, "UploadedImages");
			if (!Directory.Exists(_uploadDirectory))
			{
				Directory.CreateDirectory(_uploadDirectory);
			}
			
			// Используем относительный путь к папке ресурсов
			_resourcesImagesDirectory = Path.Combine(_projectDirectory, "Resources", "Images");
			if (!Directory.Exists(_resourcesImagesDirectory))
			{
				Directory.CreateDirectory(_resourcesImagesDirectory);
			}
		}

		/// <summary>
		/// Получить путь к изображению по умолчанию для заданной категории
		/// </summary>
		public string GetDefaultImageForCategory(string category)
		{
			if (string.IsNullOrEmpty(category))
				return _defaultImagePath;

			if (_categoryDefaultImages.TryGetValue(category, out string defaultImage))
				return defaultImage;

			return _defaultImagePath;
		}

		/// <summary>
		/// Загружает изображение из файла и сохраняет его в директорию
		/// </summary>
		/// <returns>Путь к загруженному изображению</returns>
		public string UploadImage()
		{
			try
			{
				OpenFileDialog openFileDialog = new OpenFileDialog
				{
					Filter = "Изображения|*.jpg;*.jpeg;*.png;*.gif;*.bmp|Все файлы|*.*",
					Title = "Выберите изображение"
				};

				if (openFileDialog.ShowDialog() == true)
				{
					string selectedFile = openFileDialog.FileName;
					string originalFileName = Path.GetFileName(selectedFile);
					
					// Проверяем, находится ли выбранный файл в папке Resources/Images
					bool isInResourcesFolder = false;
					
					// Нормализуем пути для корректного сравнения
					string normalizedSelectedPath = Path.GetDirectoryName(selectedFile).ToLower().Replace('\\', '/');
					string normalizedResourcesPath = _resourcesImagesDirectory.ToLower().Replace('\\', '/');
					
					// Проверяем, находится ли выбранный файл внутри папки Resources/Images
					if (normalizedSelectedPath.Contains(normalizedResourcesPath))
					{
						// Если файл уже в папке Resources/Images, возвращаем относительный путь
						isInResourcesFolder = true;
						
						// Создаем относительный путь от корня проекта
						string relativePath = selectedFile.Replace(_projectDirectory, "").Replace('\\', '/');
						if (!relativePath.StartsWith("/"))
							relativePath = "/" + relativePath;
							
						MessageBox.Show($"Выбрано изображение из папки ресурсов", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
						return relativePath;
					}
					
					// Если файл не в папке Resources/Images, то мы имеем два варианта:
					// 1. Скопировать файл в папку Resources/Images и вернуть относительный путь
					// 2. Вернуть абсолютный путь к файлу без копирования
					
					// Используем вариант 2 - вернуть абсолютный путь без копирования
					MessageBox.Show($"Выбрано изображение из внешней папки", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
					return selectedFile; // Возвращаем абсолютный путь к файлу
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Ошибка при загрузке изображения: {ex.Message}");
				MessageBox.Show($"Не удалось загрузить изображение: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
			}

			return null;
		}

		/// <summary>
		/// Нормализует путь изображения, проверяет наличие файла и его доступность
		/// </summary>
		public string NormalizeImagePath(string imagePath)
		{
			if (string.IsNullOrEmpty(imagePath))
				return _defaultImagePath;

			try
			{
				// Получаем имя файла из пути
				string fileName = Path.GetFileName(imagePath.Replace('\\', '/'));

				// Проверяем есть ли файл в нашем маппинге регистров
				if (_fileNameCaseMapping.TryGetValue(fileName, out string correctCaseFileName))
				{
					// Получаем имя папки в пути из строки с правильным регистром
					string directory = Path.GetDirectoryName(imagePath.Replace('\\', '/'));
					directory = directory.Replace('\\', '/');

					// Локальный файл
					if (string.IsNullOrEmpty(directory) || directory == ".")
						return correctCaseFileName;

					// Составляем новый путь с правильным регистром имени файла
					if (directory.StartsWith("/"))
						return $"{directory}/{correctCaseFileName}";
					else
						return $"/{directory}/{correctCaseFileName}";
				}

				return imagePath;
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Ошибка при нормализации пути изображения: {ex.Message}");
				return imagePath;
			}
		}

		/// <summary>
		/// Загружает BitmapImage из пути к изображению
		/// </summary>
		public BitmapImage LoadImage(string imagePath)
		{
			try
			{
				if (string.IsNullOrEmpty(imagePath))
					return new BitmapImage(new Uri(_defaultImagePath, UriKind.Relative));

				// Нормализуем путь
				string normalizedPath = NormalizeImagePath(imagePath);
				
				// Проверяем, является ли путь абсолютным
				bool isAbsolutePath = Path.IsPathRooted(normalizedPath) || 
									 (normalizedPath.Length > 1 && normalizedPath[1] == ':'); // Проверка на формат "C:\"
				
				// Проверяем, существует ли файл по указанному пути
				string filePath = normalizedPath;
				
				if (!isAbsolutePath && normalizedPath.StartsWith("/"))
				{
					// Если путь начинается с / и не является абсолютным, используем его относительно корня проекта
					string relativePath = normalizedPath.TrimStart('/').Replace('/', '\\');
					filePath = Path.Combine(_projectDirectory, relativePath);
				}

				if (!File.Exists(filePath))
				{
					Debug.WriteLine($"Файл не найден: {filePath}");
					return new BitmapImage(new Uri(_defaultImagePath, UriKind.Relative));
				}

				BitmapImage image = new BitmapImage();
				image.BeginInit();

				// Используем правильный путь как источник для UriSource
				if (isAbsolutePath)
				{
					// Для абсолютного пути к файлу
					image.UriSource = new Uri(filePath);
				}
				else if (normalizedPath.StartsWith("/"))
				{
					// Для относительного пути к ресурсу URI
					image.UriSource = new Uri(normalizedPath, UriKind.Relative);
				}
				else
				{
					// Для абсолютного пути к файлу, который не начинается с "/"
					image.UriSource = new Uri(filePath, UriKind.Absolute);
				}

				image.CacheOption = BitmapCacheOption.OnLoad;
				image.CreateOptions = BitmapCreateOptions.IgnoreImageCache;
				image.EndInit();
				return image;
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Ошибка при загрузке изображения: {ex.Message}");
				return new BitmapImage(new Uri(_defaultImagePath, UriKind.Relative));
			}
		}

		/// <summary>
		/// Удаляет изображение из системы
		/// </summary>
		public bool DeleteImage(string imagePath)
		{
			try
			{
				// Удаляем только изображения из папок UploadedImages и Resources/Images
				if (string.IsNullOrEmpty(imagePath) || 
					(!imagePath.Contains("UploadedImages") && !imagePath.Contains("Resources/Images")))
					return false;

				string filePath = imagePath;
				if (imagePath.StartsWith("/"))
				{
					// Получаем физический путь к файлу относительно корня проекта
					string relativePath = imagePath.TrimStart('/').Replace('/', '\\');
					filePath = Path.Combine(_projectDirectory, relativePath);
				}

				if (File.Exists(filePath))
				{
					File.Delete(filePath);
					return true;
				}

				return false;
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Ошибка при удалении изображения: {ex.Message}");
				return false;
			}
		}
	}
}