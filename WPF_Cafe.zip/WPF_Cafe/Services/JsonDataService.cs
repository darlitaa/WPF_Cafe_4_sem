using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;

namespace WpfApp1.Services
{
    public class JsonDataService
    {
        private readonly string _dataFolder = "Data";

        public JsonDataService()
        {
            if (!Directory.Exists(_dataFolder))
            {
                Directory.CreateDirectory(_dataFolder);
            }
        }

        public List<T> LoadData<T>(string fileName)
        {
            var filePath = Path.Combine(_dataFolder, fileName);
            if (!File.Exists(filePath))
            {
                return new List<T>();
            }

            try
            {
                using (var reader = new StreamReader(filePath))
                {
                    var json = reader.ReadToEnd();
                    return JsonConvert.DeserializeObject<List<T>>(json) ?? new List<T>();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading data: {ex.Message}");
                return new List<T>();
            }
        }

        public void SaveData<T>(List<T> data, string fileName)
        {
            var filePath = Path.Combine(_dataFolder, fileName);
            try
            {
                var json = JsonConvert.SerializeObject(data, Formatting.Indented);
                using (var writer = new StreamWriter(filePath))
                {
                    writer.Write(json);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving data: {ex.Message}");
            }
        }
    }
} 