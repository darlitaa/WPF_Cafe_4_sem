using System;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Windows;
using System.IO;
using System.Configuration;
using System.Diagnostics;

namespace WpfApp1.Services
{
    public class LocalizationService
    {
        private const string SettingsFileName = "language_settings.txt";

        public event EventHandler LanguageChanged;

        private CultureInfo _currentCulture;

        public static LocalizationService Instance { get; private set; }

        public CultureInfo[] SupportedLanguages { get; } = {
            new CultureInfo("ru-RU"),
            new CultureInfo("en-US")
        };
        
        public CultureInfo CurrentCulture
        {
            get { return _currentCulture; }
            set
            {
                if (_currentCulture != value)
                {
                    _currentCulture = value;
                    Thread.CurrentThread.CurrentCulture = value;
                    Thread.CurrentThread.CurrentUICulture = value;

                    UpdateResources(value);

                    SaveCurrentLanguage(value.Name);

                    OnLanguageChanged();
                }
            }
        }
        
        public LocalizationService()
        {
            Instance = this;

            _currentCulture = new CultureInfo("ru-RU");
  
            Thread.CurrentThread.CurrentCulture = _currentCulture;
            Thread.CurrentThread.CurrentUICulture = _currentCulture;

            UpdateResources(_currentCulture);

            SaveCurrentLanguage(_currentCulture.Name);
        }
        
        private void UpdateResources(CultureInfo culture)
        {
            Application.Current.Resources.MergedDictionaries.Remove(
                Application.Current.Resources.MergedDictionaries
                    .FirstOrDefault(d => d.Source != null && d.Source.OriginalString.Contains("StringResources")));
            ResourceDictionary resourceDict = new ResourceDictionary();
            resourceDict.Source = new Uri($"pack://application:,,,/WpfApp1;component/Resources/StringResources.{culture.Name}.xaml", 
                UriKind.Absolute);
            Application.Current.Resources.MergedDictionaries.Add(resourceDict);
        }

        private void OnLanguageChanged()
        {
            LanguageChanged?.Invoke(this, EventArgs.Empty);
        }

        private void SaveCurrentLanguage(string cultureName)
        {
            try
            {
                string appDataPath = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "WpfApp1");
                
                if (!Directory.Exists(appDataPath))
                {
                    Directory.CreateDirectory(appDataPath);
                }
                
                string filePath = Path.Combine(appDataPath, SettingsFileName);
                File.WriteAllText(filePath, cultureName);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error saving language settings: {ex.Message}");
            }
        }
   
        public string GetLocalizedString(string key)
        {
            try
            {
                if (Application.Current.Resources.Contains(key))
                {
                    return (string)Application.Current.FindResource(key);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error getting localized string '{key}': {ex.Message}");
            }
            return key;
        }
    }
} 