using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Collections.ObjectModel;
using WpfApp1.Data;
using WpfApp1.Models;
using System.Diagnostics;
using System.IO;

namespace WpfApp1.Services
{
    public class OrderService
    {
        private readonly CafeDbContext _dbContext;
        private readonly ProductService _productService;
        private readonly JsonDataService _jsonDataService;
        private readonly CartService _cartService;
        private Data.OrderCrudService _orderCrudService;
        private Data.CartItemCrudService _cartItemCrudService;
        private List<Order> _orders; // Для работы с JSON
        private readonly string _ordersFileName = "orders.json";
        private bool _useDatabase;
        
        public event EventHandler OrdersChanged;

        public OrderService(ProductService productService)
        {
            _dbContext = new CafeDbContext();
            _productService = productService;
            _jsonDataService = App.JsonDataService; // Получаем JsonDataService из App
            _useDatabase = true; // Активируем использование базы данных
        }

        public OrderService(JsonDataService jsonDataService, CartService cartService)
        {
            _dbContext = new CafeDbContext();
            _cartService = cartService;
            _jsonDataService = jsonDataService;
            _useDatabase = true; // Активируем использование базы данных
            _productService = cartService?.ProductService; // Получаем ProductService из CartService
        }

        public void Initialize()
        {
            try
            {
                // Получаем существующие экземпляры CRUD сервисов или создаем новые
                _orderCrudService = App.OrderCrudService ?? new Data.OrderCrudService();
                _cartItemCrudService = App.CartItemCrudService ?? new Data.CartItemCrudService();
                
                // Подписываемся на события изменения заказов
                if (_orderCrudService != null)
                {
                    _orderCrudService.OrdersChanged += (sender, args) => RefreshOrders();
                }
                
                if (!_useDatabase)
                {
                    try
                    {
                        // Проверяем, существует ли файл с заказами
                        string fullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, _ordersFileName);
                        Debug.WriteLine($"OrderService: Инициализация сервиса заказов");
                        Debug.WriteLine($"OrderService: Путь к файлу заказов: {fullPath}");
                        
                        if (File.Exists(fullPath))
                        {
                            Debug.WriteLine("OrderService: Файл заказов существует");
                        }
                        else
                        {
                            Debug.WriteLine("OrderService: Файл заказов не существует, будет создан новый файл");
                        }
                        
                        _orders = _jsonDataService.LoadData<Order>(_ordersFileName);
                if (_orders == null)
                        {
                            Debug.WriteLine("OrderService: Заказы не найдены, создание пустого списка");
                            _orders = new List<Order>();
                            _jsonDataService.SaveData(_orders, _ordersFileName);
                        }
                        else
                        {
                            Debug.WriteLine($"OrderService: Загружено заказов: {_orders.Count}");
                            // Выводим ID нескольких первых заказов для проверки
                            if (_orders.Count > 0)
                            {
                                foreach (var order in _orders.Take(3))
                                {
                                    Debug.WriteLine($"OrderService: Заказ ID: {order.Id}, Пользователь: {order.UserId}, Статус: {order.Status}, Количество товаров: {order.Items?.Count ?? 0}");
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"OrderService: Ошибка при загрузке заказов: {ex.Message}");
                        Debug.WriteLine($"OrderService: {ex.StackTrace}");
                        _orders = new List<Order>();
                        _jsonDataService.SaveData(_orders, _ordersFileName);
                    }
                }
                else
                {
                    Debug.WriteLine("OrderService: Используется режим базы данных для заказов");
                    try 
                    {
                        // Проверяем доступность базы данных
                        var count = _orderCrudService != null ? 
                            _orderCrudService.GetAllOrders().Count : 
                            _dbContext.Orders.Count();
                            
                        Debug.WriteLine($"OrderService: Подключение к базе данных успешно. Всего заказов: {count}");
                    } 
                    catch (Exception ex) 
                    {
                        Debug.WriteLine($"OrderService: Ошибка при подключении к базе данных: {ex.Message}");
                    }
                }
                
                Debug.WriteLine("OrderService успешно инициализирован");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"OrderService: Ошибка при инициализации: {ex.Message}");
                Debug.WriteLine(ex.StackTrace);
            }
        }
        
        public void RefreshOrders()
        {
            Debug.WriteLine("OrderService: Обновление данных о заказах");
            OrdersChanged?.Invoke(this, EventArgs.Empty);
        }

        public List<Order> GetAllOrders()
        {
            Debug.WriteLine("OrderService: Запрос всех заказов");
            
            if (_useDatabase)
            {
                try
                {
                    List<Order> orders;
                    
                    if (_orderCrudService != null)
                    {
                        orders = _orderCrudService.GetAllOrders();
                        Debug.WriteLine($"OrderService: Получено заказов через OrderCrudService: {orders.Count}");
                    }
                    else
                    {
                        orders = _dbContext.Orders
                            .Include(o => o.Items)
                            .Include(o => o.User)
                            .OrderByDescending(o => o.OrderDate)
                            .ToList();
                        
                        Debug.WriteLine($"OrderService: Получено заказов через прямой доступ к БД: {orders.Count}");
                    }
                    
                    // Догружаем связанные продукты для элементов заказа
                    if (_productService != null)
                    {
                        foreach (var order in orders)
                        {
                            foreach (var item in order.Items)
                            {
                                item.Product = _productService.GetProductById(item.ProductId);
                            }
                        }
                    }
                    
                    return orders;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"OrderService: Ошибка при получении заказов: {ex.Message}");
                    return new List<Order>();
                }
            }
            else
            {
                if (_orders == null)
                {
                    Debug.WriteLine("OrderService: Список заказов NULL, повторная инициализация");
                    Initialize();
                }
                
                if (_orders == null)
                {
                    Debug.WriteLine("OrderService: Список заказов все еще NULL после инициализации, возвращаем пустой список");
                    return new List<Order>();
                }
                
                Debug.WriteLine($"OrderService: Возвращение всех заказов: {_orders.Count}");
            return _orders.ToList();
            }
        }

        public List<Order> GetUserOrders(int userId)
        {
            Debug.WriteLine($"OrderService: Получение заказов для пользователя с ID: {userId}");
            
            if (_useDatabase)
            {
                try
                {
                    List<Order> orders;
                    
                    if (_orderCrudService != null)
                    {
                        orders = _orderCrudService.GetOrdersByUserId(userId);
                        Debug.WriteLine($"OrderService: Найдено заказов пользователя через OrderCrudService: {orders.Count}");
                    }
                    else
                    {
                        orders = _dbContext.Orders
                            .Include(o => o.Items)
                            .Where(o => o.UserId == userId)
                            .OrderByDescending(o => o.OrderDate)
                            .ToList();
                        
                        Debug.WriteLine($"OrderService: Найдено заказов пользователя через прямой доступ к БД: {orders.Count}");
                    }
                    
                    // Догружаем связанные продукты для элементов заказа
                    if (_productService != null)
                    {
                        foreach (var order in orders)
                        {
                            foreach (var item in order.Items)
                            {
                                item.Product = _productService.GetProductById(item.ProductId);
                            }
                        }
                    }
                    
                    return orders;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"OrderService: Ошибка при получении заказов пользователя: {ex.Message}");
                    return new List<Order>();
                }
            }
            else
            {
                if (_orders == null)
                {
                    Debug.WriteLine("OrderService: Список заказов NULL при получении заказов пользователя, повторная инициализация");
                    Initialize();
                }
                
                if (_orders == null)
                {
                    Debug.WriteLine("OrderService: Список заказов все еще NULL после инициализации, возвращаем пустой список");
                    return new List<Order>();
                }
                
                var result = _orders
                    .Where(o => o.UserId == userId)
                    .OrderByDescending(o => o.OrderDate)
                    .ToList();
                    
                Debug.WriteLine($"OrderService: Найдено заказов для пользователя {userId}: {result.Count}");
                return result;
            }
        }

        // Перегрузка для поддержки строковых идентификаторов
        public List<Order> GetUserOrders(string userIdStr)
        {
            Debug.WriteLine($"Получение заказов для пользователя со строковым ID: {userIdStr}");
            
            if (int.TryParse(userIdStr, out int userId))
            {
                return GetUserOrders(userId);
            }
            
            Debug.WriteLine($"Не удалось преобразовать ID пользователя: {userIdStr}");
            return new List<Order>();
        }

        public Order GetOrderById(int id)
        {
            try
            {
                if (_useDatabase)
                {
                    Order order;
                    
                    if (_orderCrudService != null)
                    {
                        order = _orderCrudService.GetOrderById(id);
                        Debug.WriteLine($"OrderService: Получен заказ с ID {id} через OrderCrudService");
                    }
                    else
                    {
                        order = _dbContext.Orders
                            .Include(o => o.Items)
                            .FirstOrDefault(o => o.Id == id);
                            
                        Debug.WriteLine($"OrderService: Получен заказ с ID {id} через прямой доступ к БД");
                    }
                    
                    // Догружаем связанные продукты для элементов заказа
                    if (order != null && _productService != null)
                    {
                        foreach (var item in order.Items)
                        {
                            item.Product = _productService.GetProductById(item.ProductId);
                        }
                    }
                    
                    return order;
                }
                else
                {
                    return _orders.FirstOrDefault(o => o.Id == id);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"OrderService: Ошибка при получении заказа по ID {id}: {ex.Message}");
                return null;
            }
        }

        // Перегрузка для поддержки строковых идентификаторов
        public Order GetOrderById(string idStr)
        {
            if (int.TryParse(idStr, out int id))
            {
                return GetOrderById(id);
            }
            return null;
        }

        public Order CreateOrder(Order order)
        {
            Debug.WriteLine("OrderService: Создание нового заказа");
            
            // Общая обработка заказа для обоих режимов
            if (order.Items != null)
            {
                // Устанавливаем ProductId для тех элементов, у которых есть только Product
                foreach (var item in order.Items)
                {
                    if (item.ProductId == 0 && item.Product != null)
                    {
                        item.ProductId = item.Product.Id;
                    }
                    
                    // Убедимся, что у каждого элемента есть цена
                    if (item.Price == 0 && item.Product != null)
                    {
                        item.Price = item.Product.DiscountedPrice;
                    }
                    
                    // Сохраняем изображение продукта
                    if (string.IsNullOrEmpty(item.ProductImage) && item.Product != null && item.Product.Images != null && item.Product.Images.Count > 0)
                    {
                        item.ProductImage = item.Product.ImagesJson;
                    }

                    // Сбрасываем Id каждого элемента, чтобы EF создал новые записи
                    item.Id = 0;
                    // Очищаем объект Product, чтобы не было проблем с отслеживанием
                    item.Product = null;
                }
                
                // Рассчитываем общую сумму заказа
                order.TotalAmount = order.Items.Sum(i => i.Price * i.Quantity);
            }
            
            if (_useDatabase)
            {
                // Для базы данных используем другой подход
                try
                {
                    Order createdOrder = null;
                    
                    if (_orderCrudService != null)
                    {
                        try
                        {
                            createdOrder = _orderCrudService.CreateOrder(order);
                            Debug.WriteLine($"OrderService: Заказ создан с ID: {createdOrder.Id} через OrderCrudService");
                        }
                        catch (Exception ex)
                        {
                            Debug.WriteLine($"OrderService: Ошибка при создании заказа через OrderCrudService: {ex.Message}");
                            Debug.WriteLine(ex.StackTrace);
                            // Пробуем метод прямого доступа в случае ошибки
                            createdOrder = null;
                        }
                    }
                    
                    if (createdOrder == null)
                    {
                        // Добавляем заказ в БД напрямую
                        using (var context = new CafeDbContext())
                        {
                            // Убедимся, что объект Order не отслеживается
                            context.Configuration.AutoDetectChangesEnabled = false;
                            
                            // Добавляем заказ и его элементы
                            var dbOrder = new Order
                            {
                                UserId = order.UserId,
                                Status = order.Status,
                                OrderDate = order.OrderDate,
                                DeliveryAddress = order.DeliveryAddress,
                                ContactPhone = order.ContactPhone,
                                Note = order.Note,
                                TotalAmount = order.TotalAmount,
                                Items = order.Items.Select(i => new CartItem
                                {
                                    ProductId = i.ProductId,
                                    Quantity = i.Quantity,
                                    Price = i.Price,
                                    UserId = i.UserId,
                                    ProductImage = i.ProductImage
                                }).ToList()
                            };

                            context.Orders.Add(dbOrder);
                            context.SaveChanges();
                            
                            // Копируем ID созданного заказа в исходный объект
                            order.Id = dbOrder.Id;
                            createdOrder = dbOrder;
                            
                            Debug.WriteLine($"OrderService: Заказ создан с ID: {createdOrder.Id} через прямой доступ к БД");
                        }
                    }
                    
                    // Обновление количества товаров выполняется в CheckoutViewModel напрямую
                    // через метод UpdateProductQuantities перед вызовом CreateOrder
                    
                    // Явно вызываем событие обновления продуктов для обновления интерфейса
                    _productService?.RaiseProductsUpdated();
                    
                    RefreshOrders();
                    return createdOrder;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"OrderService: Ошибка при создании заказа: {ex.Message}");
                    Debug.WriteLine(ex.StackTrace);
                    throw; // Пробрасываем исключение, чтобы оно было обработано в CheckoutViewModel
                }
            }
            else
            {
                // Для JSON используем существующий код
                // Генерируем ID для заказа, если его нет
                if (order.Id == 0)
                {
                    order.Id = _orders.Count > 0 ? _orders.Max(o => o.Id) + 1 : 1;
                }
                
                _orders.Add(order);
                _jsonDataService.SaveData(_orders, _ordersFileName);
                
                // Обновление количества товаров выполняется в CheckoutViewModel напрямую
                // через метод UpdateProductQuantities перед вызовом CreateOrder
                
                // Явно вызываем событие обновления продуктов для обновления интерфейса
                _productService?.RaiseProductsUpdated();
                
                // Очищаем корзину после создания заказа
                _cartService.ClearCart();
                
                // Важно: вызываем событие обновления заказов для всех пользователей
                RefreshOrders();
            }
            
            return order;
        }

        public void UpdateOrder(Order order)
        {
            Debug.WriteLine($"OrderService: Обновление заказа ID: {order.Id}");
            
            if (_useDatabase)
            {
                try
                {
                    if (_orderCrudService != null)
                    {
                        _orderCrudService.UpdateOrder(order);
                        Debug.WriteLine($"OrderService: Заказ ID {order.Id} успешно обновлен через OrderCrudService");
                    }
                    else
                    {
                        // Получаем существующий заказ из базы данных
                        var existingOrder = _dbContext.Orders
                            .Include(o => o.Items)
                            .FirstOrDefault(o => o.Id == order.Id);
                        
                        if (existingOrder != null)
                        {
                            // Обновляем свойства заказа
                            _dbContext.Entry(existingOrder).CurrentValues.SetValues(order);
                            
                            // Обновляем элементы заказа
                            if (order.Items != null)
                            {
                                // Удаляем элементы, которых нет в обновленном заказе
                                var itemsToRemove = existingOrder.Items
                                    .Where(i => !order.Items.Any(oi => oi.Id == i.Id))
                                    .ToList();
                                    
                                foreach (var item in itemsToRemove)
                                {
                                    _dbContext.CartItems.Remove(item);
                                }
                                
                                // Обновляем существующие и добавляем новые элементы
                                foreach (var item in order.Items)
                                {
                                    if (item.Id == 0)
                                    {
                                        // Новый элемент
                                        item.OrderId = order.Id;
                                        existingOrder.Items.Add(item);
                                    }
                                    else
                                    {
                                        // Существующий элемент
                                        var existingItem = existingOrder.Items.FirstOrDefault(i => i.Id == item.Id);
                                        if (existingItem != null)
                                        {
                                            _dbContext.Entry(existingItem).CurrentValues.SetValues(item);
                                        }
                                    }
                                }
                            }
                            
                            // Обновляем общую сумму заказа
                            existingOrder.TotalAmount = existingOrder.Items.Sum(i => i.Price * i.Quantity);
                            
                            _dbContext.SaveChanges();
                            Debug.WriteLine($"OrderService: Заказ ID {order.Id} успешно обновлен через прямой доступ к БД");
                        }
                        else
                        {
                            Debug.WriteLine($"OrderService: Заказ ID {order.Id} не найден");
                        }
                    }
                    
                    RefreshOrders();
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"OrderService: Ошибка при обновлении заказа: {ex.Message}");
                }
            }
            else
            {
                var index = _orders.FindIndex(o => o.Id == order.Id);
                if (index != -1)
                {
                    _orders[index] = order;
                    _jsonDataService.SaveData(_orders, _ordersFileName);
                }
            }
        }

        public void UpdateOrderStatus(int orderId, string status)
        {
            Debug.WriteLine($"OrderService: Обновление статуса заказа ID: {orderId} на '{status}'");
            
            if (_useDatabase)
            {
                try
                {
                    if (_orderCrudService != null)
                    {
                        _orderCrudService.UpdateOrderStatus(orderId, status);
                        Debug.WriteLine($"OrderService: Статус заказа ID {orderId} успешно обновлен на '{status}' через OrderCrudService");
                    }
                    else
                    {
                        var order = _dbContext.Orders.FirstOrDefault(o => o.Id == orderId);
                        if (order != null)
                        {
                            // Проверка на корректность перехода статуса (если есть бизнес-логика)
                            order.Status = status;
                            
                            // Если статус "Выполнен" или "Completed", устанавливаем дату доставки
                            if (status == "Выполнен" || status == "Completed")
                            {
                                order.DeliveryDate = DateTime.Now;
                                
                                // Загружаем элементы заказа, если их еще нет
                                if (order.Items == null || !order.Items.Any())
                                {
                                    var orderWithItems = _dbContext.Orders
                                        .Include(o => o.Items)
                                        .FirstOrDefault(o => o.Id == orderId);
                                    
                                    if (orderWithItems != null && orderWithItems.Items != null)
                                    {
                                        // Обновляем информацию о товарах в БД при выполнении заказа
                                        _productService?.UpdateProductsAfterPurchase(orderWithItems.Items);
                                        
                                        // Явно вызываем событие обновления продуктов для обновления интерфейса
                                        _productService?.RaiseProductsUpdated();
                                    }
                                }
                                else
                                {
                                    // Обновляем информацию о товарах в БД при выполнении заказа
                                    _productService?.UpdateProductsAfterPurchase(order.Items);
                                    
                                    // Явно вызываем событие обновления продуктов для обновления интерфейса
                                    _productService?.RaiseProductsUpdated();
                                }
                            }
                            
                            _dbContext.SaveChanges();
                            Debug.WriteLine($"OrderService: Статус заказа ID {orderId} успешно обновлен на '{status}' через прямой доступ к БД");
                        }
                        else
                        {
                            Debug.WriteLine($"OrderService: Заказ ID {orderId} не найден при обновлении статуса");
                        }
                    }
                    
                    RefreshOrders();
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"OrderService: Ошибка при обновлении статуса заказа: {ex.Message}");
                }
            }
            else
        {
            var order = _orders.FirstOrDefault(o => o.Id == orderId);
            if (order != null)
            {
                    order.Status = status;
                    
                    if (status == "Delivered")
                    {
                        order.DeliveryDate = DateTime.Now;
                        
                        // Обновляем информацию о товарах при выполнении заказа
                        if (order.Items != null && order.Items.Any())
                        {
                            _productService?.UpdateProductsAfterPurchase(order.Items);
                            
                            // Явно вызываем событие обновления продуктов для обновления интерфейса
                            _productService?.RaiseProductsUpdated();
                        }
                    }
                    
                    _jsonDataService.SaveData(_orders, _ordersFileName);
                }
            }
        }

        public void DeleteOrder(int id)
        {
            Debug.WriteLine($"OrderService: Удаление заказа ID: {id}");
            
            if (_useDatabase)
            {
                try
                {
                    if (_orderCrudService != null)
                    {
                        bool result = _orderCrudService.DeleteOrder(id);
                        Debug.WriteLine($"OrderService: Заказ ID {id} {(result ? "успешно удален" : "не удалось удалить")} через OrderCrudService");
                    }
                    else
                    {
                        var order = _dbContext.Orders
                            .Include(o => o.Items)
                            .FirstOrDefault(o => o.Id == id);
                            
            if (order != null)
                        {
                            // Удаляем все элементы заказа
                            foreach (var item in order.Items.ToList())
                            {
                                _dbContext.CartItems.Remove(item);
                            }
                            
                            // Удаляем сам заказ
                            _dbContext.Orders.Remove(order);
                            _dbContext.SaveChanges();
                            
                            Debug.WriteLine($"OrderService: Заказ ID {id} успешно удален через прямой доступ к БД");
                        }
                        else
                        {
                            Debug.WriteLine($"OrderService: Заказ ID {id} не найден при удалении");
                        }
                    }
                    
                    RefreshOrders();
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"OrderService: Ошибка при удалении заказа: {ex.Message}");
                }
            }
            else
            {
                var index = _orders.FindIndex(o => o.Id == id);
                if (index != -1)
                {
                    _orders.RemoveAt(index);
                    _jsonDataService.SaveData(_orders, _ordersFileName);
                }
            }
        }

        public void CompleteOrder(int orderId)
        {
            UpdateOrderStatus(orderId, "Completed");
        }

        public void CancelOrder(int orderId)
        {
            UpdateOrderStatus(orderId, "Cancelled");
        }

        public void CompleteOrder(string orderIdStr)
        {
            if (int.TryParse(orderIdStr, out int orderId))
            {
                CompleteOrder(orderId);
            }
        }
        
        public void CancelOrder(string orderIdStr)
        {
            if (int.TryParse(orderIdStr, out int orderId))
            {
                CancelOrder(orderId);
            }
        }
        
        public bool DeleteOrder(string orderIdStr)
        {
            if (int.TryParse(orderIdStr, out int orderId))
            {
                DeleteOrder(orderId);
                return true;
            }
            return false;
        }
        
        public void UpdateOrderStatus(string orderIdStr, string newStatus)
        {
            if (int.TryParse(orderIdStr, out int orderId))
            {
                UpdateOrderStatus(orderId, newStatus);
            }
        }
        
        public void AddOrder(Order order)
        {
            CreateOrder(order);
        }
    }
} 