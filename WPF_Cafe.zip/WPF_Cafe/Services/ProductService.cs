using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Diagnostics;
using WpfApp1.Data;
using WpfApp1.Models;

namespace WpfApp1.Services
{
    public class ProductService
    {
        private readonly CafeDbContext _dbContext;
        private List<Category> _cachedCategories;
        private List<Product> _cachedProducts;
        private Data.ProductCrudService _productCrudService;
        private bool _isInitialized = false;
        
        public event EventHandler ProductsUpdated;

        // Добавляем публичный метод для возбуждения события
        public void RaiseProductsUpdated()
        {
            ProductsUpdated?.Invoke(this, EventArgs.Empty);
            Debug.WriteLine("ProductService: Событие ProductsUpdated вызвано через публичный метод");
        }

        public ProductService(JsonDataService jsonDataService)
        {
            _dbContext = new CafeDbContext();
            _cachedCategories = new List<Category>();
            _cachedProducts = new List<Product>();
        }

        public void Initialize()
        {
            try
            {
                // Получаем существующий экземпляр ProductCrudService или создаем новый
                _productCrudService = App.ProductCrudService ?? new Data.ProductCrudService();
                
                // Подписываемся на событие изменения товаров для обновления кэша
                if (_productCrudService != null)
                {
                    _productCrudService.ProductsChanged += (sender, args) => 
                    {
                        try
                        {
                            // Загружаем данные напрямую из БД
                            _cachedProducts = _dbContext.Products.ToList();
                            RaiseProductsUpdated();
                        }
                        catch (Exception ex)
                        {
                            Debug.WriteLine($"Ошибка при обработке события изменения товаров: {ex.Message}");
                        }
                    };
                }
                
                // Категории мы будем хранить в памяти, так как они используются только для отображения
                _cachedCategories = new List<Category>
                {
                    new Category
                    {
                        Id = 1,
                        Name = "Кофе",
                        Description = "Различные виды кофейных напитков",
                        ImagePath = "/Resources/Images/photo.jpg"
                    },
                    new Category
                    {
                        Id = 2,
                        Name = "Десерты",
                        Description = "Вкусные десерты для вашего удовольствия",
                        ImagePath = "/Resources/Images/photo.jpg"
                    },
                    new Category
                    {
                        Id = 3,
                        Name = "Закуски",
                        Description = "Лёгкие закуски",
                        ImagePath = "/Resources/Images/photo.jpg"
                    }
                };
                
                // Прямая загрузка из БД вместо вызова RefreshProducts
                _cachedProducts = _dbContext.Products.ToList();
                
                Debug.WriteLine("ProductService успешно инициализирован");
                _isInitialized = true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ProductService: Ошибка при инициализации сервиса товаров: {ex.Message}");
            }
        }

        public List<Product> GetAllProducts()
        {
            if (!_isInitialized)
            {
                // Не вызываем инициализацию, чтобы избежать рекурсии
                return _cachedProducts.Count > 0 ? _cachedProducts : _dbContext.Products.ToList();
            }
            
            return _productCrudService?.GetAllProducts() ?? _cachedProducts;
        }

        public List<Category> GetAllCategories()
        {
            var products = GetAllProducts();
            
            foreach (var category in _cachedCategories)
            {
                category.Products = products
                    .Where(p => p.Category == category.Name)
                    .ToList();
            }
            
            return _cachedCategories;
        }

        public List<Product> GetProductsByCategory(string categoryName)
        {
            if (!_isInitialized)
            {
                // Не вызываем инициализацию, чтобы избежать рекурсии
                string databaseCategoryName = GetStandardCategoryName(categoryName);
                return _dbContext.Products
                    .Where(p => p.Category.Equals(databaseCategoryName, StringComparison.OrdinalIgnoreCase))
                    .ToList();
            }
            
            string dbCategoryName = GetStandardCategoryName(categoryName);
            
            if (_productCrudService != null)
            {
                return _productCrudService.GetProductsByCategory(dbCategoryName);
            }
            
            return _cachedProducts
                .Where(p => p.Category == dbCategoryName)
                .ToList();
        }

        private string GetStandardCategoryName(string localizedCategoryName)
        {
            if (localizedCategoryName == "Кофе")
                return "Кофе";
            if (localizedCategoryName == "Десерты")
                return "Десерты";
            if (localizedCategoryName == "Закуски")
                return "Закуски";
            if (localizedCategoryName == "Coffee")
                return "Кофе";
            if (localizedCategoryName == "Desserts")
                return "Десерты";
            if (localizedCategoryName == "Snacks")
                return "Закуски";
            return localizedCategoryName;
        }

        public Product GetProductById(int id)
        {
            if (!_isInitialized)
            {
                // Не вызываем инициализацию, чтобы избежать рекурсии
                return _dbContext.Products.FirstOrDefault(p => p.Id == id);
            }
            
            return _productCrudService?.GetProductById(id) ?? 
                    _cachedProducts.FirstOrDefault(p => p.Id == id);
        }

        public void AddProduct(Product product)
        {
            try
            {
                if (_productCrudService != null)
                {
                    _productCrudService.CreateProduct(product);
                    Debug.WriteLine($"Продукт {product.FullName} добавлен через ProductCrudService");
                }
                else
                {
                    _dbContext.Products.Add(product);
                    _dbContext.SaveChanges();
                    // Обновляем кэш напрямую
                    _cachedProducts = _dbContext.Products.ToList();
                    Debug.WriteLine($"Продукт {product.FullName} добавлен через прямой доступ к БД");
                }
                
                RaiseProductsUpdated();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при добавлении продукта {product.FullName}: {ex.Message}");
                throw;
            }
        }

        public void UpdateProduct(Product product)
        {
            try
            {
                if (_productCrudService != null)
                {
                    _productCrudService.UpdateProduct(product);
                    Debug.WriteLine($"Продукт {product.FullName} обновлен через ProductCrudService");
                }
                else
                {
                    var existingProduct = _dbContext.Products.FirstOrDefault(p => p.Id == product.Id);
                    if (existingProduct != null)
                    {
                        _dbContext.Entry(existingProduct).CurrentValues.SetValues(product);
                        
                        // Обновляем свойства JSON вручную
                        existingProduct.ImagesJson = product.ImagesJson;
                        
                        _dbContext.SaveChanges();
                        // Обновляем кэш напрямую
                        _cachedProducts = _dbContext.Products.ToList();
                        Debug.WriteLine($"Продукт {product.FullName} обновлен через прямой доступ к БД");
                    }
                }
                
                RaiseProductsUpdated();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при обновлении продукта {product.FullName}: {ex.Message}");
                throw;
            }
        }

        public void DeleteProduct(int id)
        {
            try
            {
                if (_productCrudService != null)
                {
                    _productCrudService.DeleteProduct(id);
                    Debug.WriteLine($"Продукт с ID {id} удален через ProductCrudService");
                }
                else
                {
                    var product = _dbContext.Products.FirstOrDefault(p => p.Id == id);
                    if (product != null)
                    {
                        _dbContext.Products.Remove(product);
                        _dbContext.SaveChanges();
                        // Обновляем кэш напрямую
                        _cachedProducts = _dbContext.Products.ToList();
                        Debug.WriteLine($"Продукт с ID {id} удален через прямой доступ к БД");
                    }
                }
                
                RaiseProductsUpdated();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при удалении продукта с ID {id}: {ex.Message}");
                throw;
            }
        }

        public List<Product> SearchProducts(string searchTerm, SearchOptions options = null)
        {
            var allProducts = GetAllProducts();
            return FilterBySearchTerm(allProducts, options ?? new SearchOptions { SearchTerm = searchTerm });
        }

        public void UpdateProductsAfterPurchase(List<CartItem> purchasedItems)
        {
            try
            {
                if (purchasedItems == null || !purchasedItems.Any())
                {
                    Debug.WriteLine("UpdateProductsAfterPurchase: Список товаров пуст или null");
                    return;
                }
                
                Debug.WriteLine($"UpdateProductsAfterPurchase: Начато обновление {purchasedItems.Count} товаров");
                
                if (_productCrudService != null)
                {
                    try
                    {
                        // Проверяем каждый товар перед передачей в ProductCrudService
                        foreach (var item in purchasedItems)
                {
                            if (item == null)
                            {
                                Debug.WriteLine("ProductService: Item в заказе равен null");
                                continue;
                            }
                            
                            Debug.WriteLine($"ProductService: Товар ID: {(item.Product != null ? item.Product.Id : item.ProductId)}, Количество: {item.Quantity}");
                            if (item.Product == null)
                            {
                                Debug.WriteLine($"ProductService: Товар.Product is null для ProductId: {item.ProductId}");
                                
                                // Если Product null, но есть ProductId, можно попробовать загрузить товар
                                if (item.ProductId > 0)
                                {
                                    var product = GetProductById(item.ProductId);
                    if (product != null)
                    {
                                        Debug.WriteLine($"ProductService: Удалось загрузить товар по ID {item.ProductId}");
                                        item.Product = product;
                                    }
                                }
                            }
                        }
                        
                        // Используем метод из ProductCrudService
                        _productCrudService.UpdateProductsAfterPurchase(purchasedItems);
                        Debug.WriteLine("Обновлены товары после покупки через ProductCrudService");
                    }
                    catch (Exception ex)
                {
                        Debug.WriteLine($"ProductService: Ошибка при обновлении товаров через ProductCrudService: {ex.Message}");
                        Debug.WriteLine($"ProductService: StackTrace: {ex.StackTrace}");
                        
                        // В случае ошибки пробуем обновить напрямую через _dbContext
                        UpdateProductsDirectly(purchasedItems);
                    }
                }
                else
                {
                    // Обновляем напрямую через _dbContext
                    UpdateProductsDirectly(purchasedItems);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при обновлении товаров после покупки: {ex.Message}");
                Debug.WriteLine($"ProductService: StackTrace: {ex.StackTrace}");
                throw;
            }
        }
        
        private void UpdateProductsDirectly(List<CartItem> purchasedItems)
        {
            // Используем прямое обновление через _dbContext
            bool productsChanged = false;
            
            foreach (var item in purchasedItems)
            {
                if (item == null) continue;
                
                int productId = item.Product != null ? item.Product.Id : item.ProductId;
                if (productId <= 0)
                {
                    Debug.WriteLine($"ProductService: Невозможно определить ID товара для обновления");
                    continue;
                }
                
                var product = GetProductById(productId);
                
                if (product != null)
                {
                    Debug.WriteLine($"Обновление товара ID {productId}: {product.ShortName}");
                    Debug.WriteLine($"  - Текущее количество: {product.Quantity}, Заказано: {item.Quantity}");
                    Debug.WriteLine($"  - Текущее число покупок: {product.TimesPurchased}");
                    
                    product.Quantity -= item.Quantity;
                    product.InStock = product.Quantity > 0;
                    product.TimesPurchased += item.Quantity;
                    
                    Debug.WriteLine($"  - Новое количество: {product.Quantity}");
                    Debug.WriteLine($"  - Новое число покупок: {product.TimesPurchased}");
                    Debug.WriteLine($"  - Доступность (InStock): {product.InStock}");
                    
                    UpdateProduct(product);
                    productsChanged = true;
                }
                else
                {
                    Debug.WriteLine($"Ошибка: Товар с ID {productId} не найден при обновлении после покупки");
                }
            }
            
            if (productsChanged)
            {
                Debug.WriteLine("Обновлены товары после покупки через прямой доступ к БД");
                
                // Обновляем кэш продуктов
                if (_dbContext != null)
                {
                    _cachedProducts = _dbContext.Products.ToList();
                    Debug.WriteLine("Кэш продуктов обновлен после изменения товаров");
                }
                
                RaiseProductsUpdated();
            }
            else
            {
                Debug.WriteLine("Ни один товар не был обновлен после покупки");
            }
        }

        public List<Product> FilterBySearchTerm(List<Product> products, SearchOptions options)
        {
            if (string.IsNullOrWhiteSpace(options.SearchTerm))
                return products;

            var lowercaseSearchTerm = options.SearchTerm.ToLower().Trim();
            var searchTerms = lowercaseSearchTerm.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            var matchedProducts = new Dictionary<Product, int>();

            foreach (var product in products)
            {
                int relevanceScore = 0;
                bool matchFound = false;

                if (!options.SearchInTitle && !options.SearchInDescription)
                    continue;

                if (options.SearchInTitle)
                {
                    string shortNameLower = product.ShortName.ToLower();
                    string fullNameLower = product.FullName.ToLower();

                    if (shortNameLower.Contains(lowercaseSearchTerm) || fullNameLower.Contains(lowercaseSearchTerm))
                    {
                        relevanceScore += 60;
                        matchFound = true;
                    }
                    else if (searchTerms.Length > 1)
                    {
                        int matchedTerms = 0;
                        foreach (var term in searchTerms)
                        {
                            if (term.Length < 3)
                                continue;

                            if (shortNameLower.Contains(term) || fullNameLower.Contains(term))
                            {
                                matchedTerms++;
                            }
                        }

                        if (matchedTerms > 0)
                        {
                            relevanceScore += matchedTerms * 40 / searchTerms.Length;
                            matchFound = true;
                        }
                    }
                }

                if (options.SearchInDescription && product.Description != null)
                {
                    string descLower = product.Description.ToLower();

                    if (descLower.Contains(lowercaseSearchTerm))
                    {
                        relevanceScore += 30;
                        matchFound = true;
                    }
                    else if (searchTerms.Length > 1)
                    {
                        int matchedTerms = 0;
                        foreach (var term in searchTerms)
                        {
                            if (term.Length < 3)
                                continue;

                            if (descLower.Contains(term))
                            {
                                matchedTerms++;
                            }
                        }

                        if (matchedTerms > 0)
                        {
                            relevanceScore += matchedTerms * 20 / searchTerms.Length;
                            matchFound = true;
                        }
                    }
                }

                if (matchFound)
                {
                    relevanceScore += product.InStock ? 10 : 0;
                    matchedProducts.Add(product, relevanceScore);
                }
            }

            if (matchedProducts.Count == 0)
                return new List<Product>();

            return matchedProducts.OrderByDescending(kvp => kvp.Value)
                    .Select(kvp => kvp.Key)
                    .ToList();
        }

        public List<string> GetDistinctManufacturers()
        {
            if (_productCrudService != null)
            {
                return _productCrudService.GetAllManufacturers();
            }
            
            return _cachedProducts
                .Select(p => p.Manufacturer)
                .Distinct()
                .Where(m => !string.IsNullOrEmpty(m))
                .ToList();
        }

        public decimal GetMinProductPrice()
        {
            var products = GetAllProducts();
            if (products.Count == 0) return 0;
            return products.Min(p => p.Price);
        }

        public decimal GetMaxProductPrice()
        {
            var products = GetAllProducts();
            if (products.Count == 0) return 0;
            return products.Max(p => p.Price);
        }

        // Добавляем метод для прямого обновления количества товаров без промежуточных объектов
        public void UpdateProductQuantityDirect(int productId, int quantityToDecrease)
        {
            try
            {
                Debug.WriteLine($"ProductService: Прямое обновление количества товара ID {productId}, уменьшение на {quantityToDecrease}");
                
                if (quantityToDecrease <= 0)
                {
                    Debug.WriteLine("ProductService: Количество для уменьшения должно быть положительным");
                    return;
                }
                
                var product = GetProductById(productId);
                
                if (product == null)
                {
                    Debug.WriteLine($"ProductService: Товар с ID {productId} не найден");
                    throw new InvalidOperationException($"Товар с ID {productId} не найден");
                }
                
                Debug.WriteLine($"ProductService: Текущее количество товара: {product.Quantity}, уменьшаем на: {quantityToDecrease}");
                
                // Проверяем, достаточно ли товара на складе
                if (product.Quantity < quantityToDecrease)
                {
                    Debug.WriteLine($"ProductService: Ошибка - заказанное количество ({quantityToDecrease}) больше доступного ({product.Quantity})");
                    throw new InvalidOperationException($"Недостаточно товара '{product.ShortName}' на складе. Доступно: {product.Quantity}, запрошено: {quantityToDecrease}");
                }
                
                product.Quantity -= quantityToDecrease;
                product.InStock = product.Quantity > 0;
                product.TimesPurchased += quantityToDecrease;
                
                Debug.WriteLine($"ProductService: Новое количество товара: {product.Quantity}");
                Debug.WriteLine($"ProductService: Доступность (InStock): {product.InStock}");
                
                // Обновляем товар в базе данных
                if (_productCrudService != null)
                {
                    _productCrudService.UpdateProduct(product);
                }
                else
                {
                    var dbProduct = _dbContext.Products.FirstOrDefault(p => p.Id == productId);
                    if (dbProduct != null)
                    {
                        dbProduct.Quantity = product.Quantity;
                        dbProduct.InStock = product.InStock;
                        dbProduct.TimesPurchased = product.TimesPurchased;
                        _dbContext.SaveChanges();
                    }
                }
                
                // Уведомляем об изменении товаров
                RaiseProductsUpdated();
                
                Debug.WriteLine($"ProductService: Товар ID {productId} успешно обновлен");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ProductService: Ошибка при прямом обновлении количества товара: {ex.Message}");
                Debug.WriteLine($"ProductService: {ex.StackTrace}");
                throw; // Пробрасываем исключение дальше для обработки в вызывающем коде
            }
        }
    }
}