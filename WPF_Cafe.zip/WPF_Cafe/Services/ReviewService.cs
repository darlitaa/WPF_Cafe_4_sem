using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using WpfApp1.Data;
using WpfApp1.Models;

namespace WpfApp1.Services
{
    public class ReviewService
    {
        private readonly CafeDbContext _dbContext;
        
        public event EventHandler ReviewsChanged;

        public ReviewService()
        {
            try 
            {
                _dbContext = new CafeDbContext();
                Debug.WriteLine("ReviewService успешно инициализирован");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при инициализации ReviewService: {ex.Message}");
                throw;
            }
        }
        
        // Публичный метод для вызова события обновления отзывов
        public void RaiseReviewsChanged()
        {
            Debug.WriteLine("Вызов события ReviewsChanged вручную");
            ReviewsChanged?.Invoke(this, EventArgs.Empty);
        }
        
        public List<Review> GetAllReviews()
        {
            try
            {
                var reviews = _dbContext.Reviews.Include("User").ToList();
                Debug.WriteLine($"Получено {reviews.Count} отзывов");
                return reviews;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при получении всех отзывов: {ex.Message}");
                return new List<Review>();
            }
        }
        
        public Review GetReviewById(int id)
        {
            try
            {
                var review = _dbContext.Reviews.Include("User").FirstOrDefault(r => r.Id == id);
                if (review != null)
                {
                    Debug.WriteLine($"Получен отзыв с ID {id}");
                }
                else
                {
                    Debug.WriteLine($"Отзыв с ID {id} не найден");
                }
                return review;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при получении отзыва по ID {id}: {ex.Message}");
                return null;
            }
        }
        
        public Review GetReviewByUserId(int userId)
        {
            try
            {
                var review = _dbContext.Reviews.Include("User").FirstOrDefault(r => r.UserId == userId);
                if (review != null)
                {
                    Debug.WriteLine($"Получен отзыв пользователя с ID {userId}");
                }
                else
                {
                    Debug.WriteLine($"Отзыв пользователя с ID {userId} не найден");
                }
                return review;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при получении отзыва по ID пользователя {userId}: {ex.Message}");
                return null;
            }
        }
        
        public bool HasUserReview(int userId)
        {
            try
            {
                bool hasReview = _dbContext.Reviews.Any(r => r.UserId == userId);
                Debug.WriteLine($"Проверка наличия отзыва пользователя {userId}: {(hasReview ? "Отзыв существует" : "Отзыва нет")}");
                return hasReview;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при проверке наличия отзыва пользователя {userId}: {ex.Message}");
                return false;
            }
        }
        
        public void AddReview(Review review)
        {
            try
            {
                Debug.WriteLine($"Попытка добавить отзыв пользователя {review.UserId}");
                
                if (review == null)
                {
                    Debug.WriteLine("Ошибка: объект отзыва равен null");
                    throw new ArgumentNullException(nameof(review));
                }
                
                if (HasUserReview(review.UserId))
                {
                    Debug.WriteLine($"Ошибка: пользователь {review.UserId} уже оставил отзыв");
                    throw new Exception("Пользователь уже оставил отзыв");
                }
                
                review.CreatedAt = DateTime.Now;
                _dbContext.Reviews.Add(review);
                _dbContext.SaveChanges();
                
                Debug.WriteLine($"Отзыв пользователя ID {review.UserId} успешно добавлен в базу данных");
                
                ReviewsChanged?.Invoke(this, EventArgs.Empty);
                Debug.WriteLine("Событие ReviewsChanged успешно вызвано");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при добавлении отзыва: {ex.Message}");
                Debug.WriteLine($"Стек вызовов: {ex.StackTrace}");
                throw;
            }
        }
        
        public void UpdateReview(Review review)
        {
            try
            {
                Debug.WriteLine($"Попытка обновить отзыв с ID {review.Id}");
                
                if (review == null)
                {
                    Debug.WriteLine("Ошибка: объект отзыва равен null");
                    throw new ArgumentNullException(nameof(review));
                }
                
                var existingReview = _dbContext.Reviews.FirstOrDefault(r => r.Id == review.Id);
                if (existingReview != null)
                {
                    existingReview.Text = review.Text;
                    existingReview.Rating = review.Rating;
                    _dbContext.SaveChanges();
                    
                    Debug.WriteLine($"Отзыв ID {review.Id} успешно обновлен в базе данных");
                    
                    ReviewsChanged?.Invoke(this, EventArgs.Empty);
                    Debug.WriteLine("Событие ReviewsChanged успешно вызвано");
                }
                else
                {
                    Debug.WriteLine($"Ошибка: отзыв с ID {review.Id} не найден");
                    throw new Exception($"Отзыв с ID {review.Id} не найден");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при обновлении отзыва: {ex.Message}");
                Debug.WriteLine($"Стек вызовов: {ex.StackTrace}");
                throw;
            }
        }
        
        public void DeleteReview(int id)
        {
            try
            {
                Debug.WriteLine($"Попытка удалить отзыв с ID {id}");
                
                var review = _dbContext.Reviews.FirstOrDefault(r => r.Id == id);
                if (review != null)
                {
                    _dbContext.Reviews.Remove(review);
                    _dbContext.SaveChanges();
                    
                    Debug.WriteLine($"Отзыв ID {id} успешно удален из базы данных");
                    
                    ReviewsChanged?.Invoke(this, EventArgs.Empty);
                    Debug.WriteLine("Событие ReviewsChanged успешно вызвано");
                }
                else
                {
                    Debug.WriteLine($"Предупреждение: отзыв с ID {id} не найден для удаления");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при удалении отзыва: {ex.Message}");
                Debug.WriteLine($"Стек вызовов: {ex.StackTrace}");
                throw;
            }
        }
        
        public double GetAverageRating()
        {
            try
            {
                var reviews = _dbContext.Reviews.ToList();
                if (reviews.Count == 0)
                {
                    Debug.WriteLine("Нет отзывов для расчета среднего рейтинга");
                    return 0;
                }
                
                double average = reviews.Average(r => r.Rating);
                Debug.WriteLine($"Рассчитан средний рейтинг: {average:F2} на основе {reviews.Count} отзывов");
                return average;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при получении среднего рейтинга: {ex.Message}");
                return 0;
            }
        }
    }
} 