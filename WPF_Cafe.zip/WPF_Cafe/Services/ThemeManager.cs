using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;
using System.Linq;

namespace WpfApp1.Services
{
    public class ThemeManager
    {
        public enum Theme
        {
            Default,     // Обычная (белая)
            SkyBlue,     // Светло-небесно-голубая
            CoffeeTheme,      // Кофейная
            Biscuit      // Бисквитная
        }

        private static readonly Dictionary<Theme, ResourceDictionary> _themeResources = new Dictionary<Theme, ResourceDictionary>();
        private static Theme _currentTheme = Theme.Default;
        private static ResourceDictionary _currentThemeResourceDictionary = null;

        public static Theme CurrentTheme
        {
            get { return _currentTheme; }
        }

        public static void Initialize()
        {
            CreateThemes();
            ApplyTheme(Theme.Default);
        }

        public static void ApplyTheme(Theme theme)
        {
            if (!_themeResources.ContainsKey(theme))
            {
                throw new ArgumentException($"Тема {theme} не найдена", nameof(theme));
            }

            _currentTheme = theme;

            // Удаляем предыдущую тему из MergedDictionaries, если она была добавлена
            if (_currentThemeResourceDictionary != null && 
                Application.Current.Resources.MergedDictionaries.Contains(_currentThemeResourceDictionary))
            {
                Application.Current.Resources.MergedDictionaries.Remove(_currentThemeResourceDictionary);
            }

            // Сохраняем ссылку на новую тему
            _currentThemeResourceDictionary = _themeResources[theme];

            // Добавляем тему в начало списка, чтобы она имела приоритет
            Application.Current.Resources.MergedDictionaries.Insert(0, _currentThemeResourceDictionary);

            // Обновляем все основные ресурсы в главном словаре для совместимости
            foreach (var key in _currentThemeResourceDictionary.Keys)
            {
                if (Application.Current.Resources.Contains(key))
                {
                    Application.Current.Resources[key] = _currentThemeResourceDictionary[key];
                }
            }
        }

        private static void CreateThemes()
        {
            // Обычная (белая) тема
            var defaultTheme = new ResourceDictionary();
            
            defaultTheme["PrimaryBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#4CAF50"));
            defaultTheme["PrimaryLightBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#C8E6C9"));
            defaultTheme["PrimaryDarkBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#2E7D32"));
            defaultTheme["SecondaryBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF9800"));
            defaultTheme["BackgroundBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#F9F9F9"));
            defaultTheme["CardBackgroundBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFFFFF"));
            defaultTheme["TextPrimaryBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#212121"));
            defaultTheme["TextSecondaryBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#757575"));
            defaultTheme["BorderBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#EEEEEE"));
            
            _themeResources[Theme.Default] = defaultTheme;

            // Светло-небесно-голубая тема
            var skyBlueTheme = new ResourceDictionary();
            
            skyBlueTheme["PrimaryBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#2196F3"));
            skyBlueTheme["PrimaryLightBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#BBDEFB"));
            skyBlueTheme["PrimaryDarkBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1976D2"));
            skyBlueTheme["SecondaryBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF4081"));
            skyBlueTheme["BackgroundBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#F5F9FF"));
            skyBlueTheme["CardBackgroundBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFFFFF"));
            skyBlueTheme["TextPrimaryBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#263238"));
            skyBlueTheme["TextSecondaryBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#607D8B"));
            skyBlueTheme["BorderBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#E3F2FD"));
            
            _themeResources[Theme.SkyBlue] = skyBlueTheme;

            // Кофейная тема
            var coffeeTheme = new ResourceDictionary();
            
            coffeeTheme["PrimaryBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#795548"));
            coffeeTheme["PrimaryLightBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#D7CCC8"));
            coffeeTheme["PrimaryDarkBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#5D4037"));
            coffeeTheme["SecondaryBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF9E80"));
            coffeeTheme["BackgroundBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#EFEBE9"));
            coffeeTheme["CardBackgroundBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFFFFF"));
            coffeeTheme["TextPrimaryBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#3E2723"));
            coffeeTheme["TextSecondaryBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#6D4C41"));
            coffeeTheme["BorderBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#D7CCC8"));
            
            _themeResources[Theme.CoffeeTheme] = coffeeTheme;

            // Бисквитная тема
            var biscuitTheme = new ResourceDictionary();
            
            biscuitTheme["PrimaryBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#F9A825"));
            biscuitTheme["PrimaryLightBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFECB3"));
            biscuitTheme["PrimaryDarkBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#F57F17"));
            biscuitTheme["SecondaryBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#EC407A"));
            biscuitTheme["BackgroundBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFF8E1"));
            biscuitTheme["CardBackgroundBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFFFFF"));
            biscuitTheme["TextPrimaryBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#3E2723"));
            biscuitTheme["TextSecondaryBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#8D6E63"));
            biscuitTheme["BorderBrush"] = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFE082"));
            
            _themeResources[Theme.Biscuit] = biscuitTheme;
        }

        public static Theme GetNextTheme()
        {
            var themes = Enum.GetValues(typeof(Theme));
            int currentIndex = (int)_currentTheme;
            int nextIndex = (currentIndex + 1) % themes.Length;
            return (Theme)nextIndex;
        }
    }
} 