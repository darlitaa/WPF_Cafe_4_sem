﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Services
{
	public interface IActionCommand
	{
		void Execute();
		void Undo();
	}

	public class UndoManager
	{
		private readonly Stack<IActionCommand> _undoStack = new Stack<IActionCommand>();
		private readonly Stack<IActionCommand> _redoStack = new Stack<IActionCommand>();
		private MainWindow _mainWindow;

		// Событие для уведомления об изменении состояния стеков команд
		public event EventHandler StateChanged;

		public UndoManager(MainWindow mainWindow = null)
		{
			_mainWindow = mainWindow;
		}

		public void ExecuteAction(IActionCommand command)
		{
			command.Execute();
			_undoStack.Push(command);
			_redoStack.Clear(); // При новом действии Redo становится недоступным
			
			// Вызываем событие после изменения состояния
			StateChanged?.Invoke(this, EventArgs.Empty);
		}

		public void Undo()
		{
			if (_undoStack.Count == 0) return;

			var command = _undoStack.Pop();
			command.Undo();
			_redoStack.Push(command);
			
			// Вызываем событие после изменения состояния
			StateChanged?.Invoke(this, EventArgs.Empty);
		}

		public void Redo()
		{
			if (_redoStack.Count == 0) return;

			var command = _redoStack.Pop();
			command.Execute();
			_undoStack.Push(command);
			
			// Вызываем событие после изменения состояния
			StateChanged?.Invoke(this, EventArgs.Empty);
		}

		public bool CanUndo => _undoStack.Count > 0;

		public bool CanRedo => _redoStack.Count > 0;

		// Возвращает команду, которая будет отменена, без её извлечения
		public IActionCommand Peek()
		{
			if (_undoStack.Count == 0) return null;
			return _undoStack.Peek();
		}

		// Возвращает команду, которая будет повторена, без её извлечения
		public IActionCommand PeekRedo()
		{
			if (_redoStack.Count == 0) return null;
			return _redoStack.Peek();
		}

		public void Clear()
		{
			_undoStack.Clear();
			_redoStack.Clear();
			
			// Вызываем событие после изменения состояния
			StateChanged?.Invoke(this, EventArgs.Empty);
		}
	}
}
