using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using WpfApp1.Data;
using WpfApp1.Models;

namespace WpfApp1.Services
{
    public class UserService
    {
        private readonly CafeDbContext _dbContext;
        private List<User> _cachedUsers;
        private Data.UserCrudService _userCrudService;

        public User CurrentUser { get; private set; }
        
        public event EventHandler UsersChanged;

        public UserService()
        {
            _dbContext = new CafeDbContext();
            _cachedUsers = new List<User>();
        }

        public void Initialize()
        {
            try
            {
                // Получаем существующий экземпляр UserCrudService или создаем новый
                _userCrudService = App.UserCrudService ?? new Data.UserCrudService();
                
                // Подписываемся на событие изменения пользователей для обновления кэша
                if (_userCrudService != null)
                {
                    _userCrudService.UsersChanged += (sender, args) => RefreshUsers();
                }
                
                // Инициализируем кэш пользователей
                RefreshUsers();
                
                Debug.WriteLine("UserService успешно инициализирован");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при инициализации UserService: {ex.Message}");
            }
        }
        
        public void RefreshUsers()
        {
            try
            {
                _cachedUsers = _userCrudService?.GetAllUsers() ?? _dbContext.Users.ToList();
                UsersChanged?.Invoke(this, EventArgs.Empty);
                Debug.WriteLine($"Обновлен кэш пользователей, количество: {_cachedUsers.Count}");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при обновлении кэша пользователей: {ex.Message}");
            }
        }

        public bool Authenticate(string username, string password)
        {
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                return false;
            }

            try
            {
                bool authenticated = false;
                
                if (_userCrudService != null)
                {
                    authenticated = _userCrudService.AuthenticateUser(username, password);
                    if (authenticated)
                    {
                        CurrentUser = _userCrudService.GetUserByUsername(username);
                        
                        // Проверяем, не заблокирован ли пользователь
                        if (CurrentUser != null && CurrentUser.IsBlocked)
                        {
                            Debug.WriteLine($"Пользователь {username} заблокирован и не может войти в систему");
                            CurrentUser = null;
                            return false;
                        }
                        
                        Debug.WriteLine($"Пользователь {username} успешно аутентифицирован через UserCrudService");
                    }
                }
                else
                {
                    var user = _dbContext.Users.FirstOrDefault(u =>
                        u.Username.Equals(username, StringComparison.OrdinalIgnoreCase) &&
                        u.Password == password);

                    if (user != null)
                    {
                        // Проверяем, не заблокирован ли пользователь
                        if (user.IsBlocked)
                        {
                            Debug.WriteLine($"Пользователь {username} заблокирован и не может войти в систему");
                            return false;
                        }
                        
                        user.LastLoginAt = DateTime.Now;
                        _dbContext.SaveChanges();
                        
                        CurrentUser = user;
                        authenticated = true;
                        Debug.WriteLine($"Пользователь {username} успешно аутентифицирован через прямой доступ к БД");
                    }
                }
                
                return authenticated;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при аутентификации пользователя {username}: {ex.Message}");
                return false;
            }
        }

        public void Logout()
        {
            CurrentUser = null;
            Debug.WriteLine("Пользователь вышел из системы");
        }

        public List<User> GetAllUsers()
        {
            try
            {
                return _userCrudService?.GetAllUsers() ?? _cachedUsers;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при получении всех пользователей: {ex.Message}");
                return _cachedUsers;
            }
        }

        public User GetUserById(int id)
        {
            try
            {
                return _userCrudService?.GetUserById(id) ?? 
                       _cachedUsers.FirstOrDefault(u => u.Id == id);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при получении пользователя по ID {id}: {ex.Message}");
                return null;
            }
        }

        public User GetUserByUsername(string username)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(username))
                    return null;
                    
                return _userCrudService?.GetUserByUsername(username) ?? 
                       _cachedUsers.FirstOrDefault(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase));
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при получении пользователя по имени {username}: {ex.Message}");
                return null;
            }
        }

        public bool IsUsernameTaken(string username)
        {
            try
            {
                if (_userCrudService != null)
                {
                    var user = _userCrudService.GetUserByUsername(username);
                    return user != null;
                }
                
                return _cachedUsers.Any(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase));
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при проверке имени пользователя {username}: {ex.Message}");
                return false;
            }
        }

        public void AddUser(User user)
        {
            try
            {
                if (_userCrudService != null)
                {
                    _userCrudService.CreateUser(user);
                    Debug.WriteLine($"Пользователь {user.Username} добавлен через UserCrudService");
                }
                else
                {
                    _dbContext.Users.Add(user);
                    _dbContext.SaveChanges();
                    RefreshUsers();
                    Debug.WriteLine($"Пользователь {user.Username} добавлен через прямой доступ к БД");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при добавлении пользователя {user.Username}: {ex.Message}");
                throw;
            }
        }

        public void UpdateUser(User user)
        {
            try
            {
                if (_userCrudService != null)
                {
                    _userCrudService.UpdateUser(user);
                    
                    // Если обновляется текущий пользователь, обновляем и его
                    if (CurrentUser?.Id == user.Id)
                    {
                        CurrentUser = _userCrudService.GetUserById(user.Id);
                    }
                    
                    Debug.WriteLine($"Пользователь {user.Username} обновлен через UserCrudService");
                }
                else
                {
                    var existingUser = _dbContext.Users.FirstOrDefault(u => u.Id == user.Id);
                    if (existingUser != null)
                    {
                        _dbContext.Entry(existingUser).CurrentValues.SetValues(user);
                        _dbContext.SaveChanges();
                        RefreshUsers();
                        
                        // Если обновляется текущий пользователь, обновляем и его
                        if (CurrentUser?.Id == user.Id)
                        {
                            CurrentUser = existingUser;
                        }
                        
                        Debug.WriteLine($"Пользователь {user.Username} обновлен через прямой доступ к БД");
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при обновлении пользователя {user.Username}: {ex.Message}");
                throw;
            }
        }

        public void DeleteUser(int id)
        {
            try
            {
                if (_userCrudService != null)
                {
                    _userCrudService.DeleteUser(id);
                    
                    // Если удаляется текущий пользователь, выполняем выход
                    if (CurrentUser?.Id == id)
                    {
                        Logout();
                    }
                    
                    Debug.WriteLine($"Пользователь с ID {id} удален через UserCrudService");
                }
                else
                {
                    var user = _dbContext.Users.FirstOrDefault(u => u.Id == id);
                    if (user != null)
                    {
                        _dbContext.Users.Remove(user);
                        _dbContext.SaveChanges();
                        RefreshUsers();
                        
                        // Если удаляется текущий пользователь, выполняем выход
                        if (CurrentUser?.Id == id)
                        {
                            Logout();
                        }
                        
                        Debug.WriteLine($"Пользователь с ID {id} удален через прямой доступ к БД");
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при удалении пользователя с ID {id}: {ex.Message}");
                throw;
            }
        }

        public bool IsUserAdmin()
        {
            return CurrentUser?.IsAdmin == true;
        }

        public User GetCurrentUser()
        {
            if (CurrentUser == null)
            {
                Debug.WriteLine("ПРЕДУПРЕЖДЕНИЕ: Текущий пользователь не установлен. Выполняется переход на временного пользователя");
                // Временное решение - возвращаем администратора с ID=1
                User tempUser = GetUserById(1);
                
                if (tempUser == null)
                {
                    Debug.WriteLine("ОШИБКА: Не найден пользователь по умолчанию (ID=1)");
                    // Создаем дефолтного пользователя только в памяти
                    return new User 
                    { 
                        Id = 1, 
                        Username = "admin", 
                        FullName = "Администратор", 
                        IsAdmin = true 
                    };
                }
                
                return tempUser;
            }
            
            return CurrentUser;
        }

        // Метод для получения ID текущего пользователя
        public int GetCurrentUserId()
        {
            return CurrentUser?.Id ?? 0;
        }

        // Метод для блокировки пользователя
        public bool BlockUser(int userId)
        {
            try
            {
                var user = GetUserById(userId);
                if (user == null)
                {
                    Debug.WriteLine($"Не удалось найти пользователя с ID {userId} для блокировки");
                    return false;
                }
                
                // Нельзя блокировать администраторов
                if (user.IsAdmin)
                {
                    Debug.WriteLine($"Нельзя блокировать администратора (пользователь ID {userId})");
                    return false;
                }
                
                // Устанавливаем статус блокировки
                user.IsBlocked = true;
                UpdateUser(user);
                
                Debug.WriteLine($"Пользователь {user.Username} (ID {userId}) заблокирован");
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при блокировке пользователя ID {userId}: {ex.Message}");
                return false;
            }
        }
        
        // Метод для разблокировки пользователя
        public bool UnblockUser(int userId)
        {
            try
            {
                var user = GetUserById(userId);
                if (user == null)
                {
                    Debug.WriteLine($"Не удалось найти пользователя с ID {userId} для разблокировки");
                    return false;
                }
                
                // Снимаем блокировку
                user.IsBlocked = false;
                UpdateUser(user);
                
                Debug.WriteLine($"Пользователь {user.Username} (ID {userId}) разблокирован");
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при разблокировке пользователя ID {userId}: {ex.Message}");
                return false;
            }
        }

        // Метод для назначения пользователя администратором
        public bool PromoteToAdmin(int userId)
        {
            try
            {
                var user = GetUserById(userId);
                if (user == null)
                {
                    Debug.WriteLine($"Не удалось найти пользователя с ID {userId} для повышения до администратора");
                    return false;
                }
                
                // Уже администратор
                if (user.IsAdmin)
                {
                    Debug.WriteLine($"Пользователь {user.Username} (ID {userId}) уже является администратором");
                    return false;
                }
                
                // Повышаем до администратора
                user.IsAdmin = true;
                UpdateUser(user);
                
                Debug.WriteLine($"Пользователь {user.Username} (ID {userId}) повышен до администратора");
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при повышении пользователя ID {userId} до администратора: {ex.Message}");
                return false;
            }
        }
        
        // Метод для разжалования администратора
        public bool DemoteFromAdmin(int userId)
        {
            try
            {
                // Защита главного администратора (Id = 1)
                if (userId == 1)
                {
                    Debug.WriteLine($"Попытка разжаловать главного администратора (ID 1) отклонена");
                    return false;
                }
                
                var user = GetUserById(userId);
                if (user == null)
                {
                    Debug.WriteLine($"Не удалось найти пользователя с ID {userId} для разжалования");
                    return false;
                }
                
                // Не является администратором
                if (!user.IsAdmin)
                {
                    Debug.WriteLine($"Пользователь {user.Username} (ID {userId}) не является администратором");
                    return false;
                }
                
                // Проверка, что это не последний администратор в системе
                var admins = GetAllUsers().Where(u => u.IsAdmin && u.Id != userId).ToList();
                if (admins.Count == 0)
                {
                    Debug.WriteLine($"Нельзя разжаловать последнего администратора в системе");
                    return false;
                }
                
                // Проверка, что пользователь не пытается разжаловать сам себя
                if (CurrentUser != null && CurrentUser.Id == userId)
                {
                    Debug.WriteLine($"Пользователь не может разжаловать сам себя");
                    return false;
                }
                
                // Разжалуем администратора
                user.IsAdmin = false;
                UpdateUser(user);
                
                Debug.WriteLine($"Пользователь {user.Username} (ID {userId}) разжалован из администраторов");
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при разжаловании пользователя ID {userId} из администраторов: {ex.Message}");
                return false;
            }
        }
    }
} 