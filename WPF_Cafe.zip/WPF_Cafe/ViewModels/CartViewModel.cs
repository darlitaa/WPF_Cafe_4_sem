using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using WpfApp1.Models;
using WpfApp1.Services;
using System.Threading.Tasks;
using System.Linq;

namespace WpfApp1.ViewModels
{
    public class CartViewModel : ViewModelBase
    {
        private readonly CartService _cartService;
        private readonly UserService _userService;
        private readonly UndoManager _undoManager;
        private ObservableCollection<CartItem> _cartItems;
        private decimal _totalPrice;
        private int _itemCount;
        private bool _lastItemRestored;
        private bool _lastItemDeleted;

        public ObservableCollection<CartItem> CartItems
        {
            get => _cartItems;
            set => SetProperty(ref _cartItems, value);
        }

        public decimal TotalPrice
        {
            get => _totalPrice;
            set => SetProperty(ref _totalPrice, value);
        }

        public int ItemCount
        {
            get => _itemCount;
            set => SetProperty(ref _itemCount, value);
        }

        public bool HasItems => ItemCount > 0;

        public bool CanUndo
        {
            get
            {
                // Если в стеке нет команд, ничего отменять нельзя
                if (!_undoManager.CanUndo)
                    return false;
                    
                // Проверяем, является ли следующая отменяемая команда удалением последнего товара
                if (_undoManager.Peek() is RemoveFromCartCommand removeCmd)
                {
                    // Если команда помечена как команда удаления последнего товара, блокируем её отмену
                    if (removeCmd.IsLastItem)
                        return false;
                }
                
                return true;
            }
        }

        public bool CanRedo
        {
            get
            {
                // Если в стеке нет команд для повтора, ничего повторять нельзя
                if (!_undoManager.CanRedo)
                    return false;
                    
                // Проверяем, является ли следующая повторяемая команда удалением последнего товара
                if (_undoManager.PeekRedo() is RemoveFromCartCommand removeCmd)
                {
                    // Специальный случай: если корзина пуста, всегда разрешаем восстановление товара
                    if (ItemCount == 0)
                        return true;
                        
                    // Если в корзине 1 товар и команда помечена как удаление последнего товара, 
                    // блокируем её выполнение
                    if (ItemCount == 1 && removeCmd.IsLastItem)
                        return false;
                }
                
                return true;
            }
        }

        public ICommand RemoveItemCommand { get; }
        public ICommand IncreaseQuantityCommand { get; }
        public ICommand DecreaseQuantityCommand { get; }
        public ICommand ClearCartCommand { get; }
        public ICommand CheckoutCommand { get; }
        public ICommand ContinueShoppingCommand { get; }
        public ICommand CloseCartCommand { get; }
        public ICommand UndoCommand { get; }
        public ICommand RedoCommand { get; }

        public event EventHandler CheckoutRequested;
        public event EventHandler ContinueShoppingRequested;
        public event EventHandler CloseCartRequested;

        public bool LastItemRestored
        {
            get => _lastItemRestored;
            private set => SetProperty(ref _lastItemRestored, value);
        }

        public bool LastItemDeleted
        {
            get => _lastItemDeleted;
            private set => SetProperty(ref _lastItemDeleted, value);
        }

        public CartViewModel(CartService cartService, UserService userService)
        {
            _cartService = cartService;
            _userService = userService;
            _cartItems = new ObservableCollection<CartItem>(_cartService.CartItems);
            _undoManager = new UndoManager();
            
            // Подписываемся на событие изменения состояния UndoManager
            _undoManager.StateChanged += UndoManager_StateChanged;

            RemoveItemCommand = new RelayCommand(RemoveItem);
            IncreaseQuantityCommand = new RelayCommand(IncreaseQuantity);
            DecreaseQuantityCommand = new RelayCommand(DecreaseQuantity, CanDecreaseQuantity);
            ClearCartCommand = new RelayCommand(ClearCart, CanClearCart);
            CheckoutCommand = new RelayCommand(Checkout, CanCheckout);
            ContinueShoppingCommand = new RelayCommand(ContinueShopping);
            CloseCartCommand = new RelayCommand(CloseCart);
            UndoCommand = new RelayCommand(Undo, ExecuteCanUndo);
            RedoCommand = new RelayCommand(Redo, ExecuteCanRedo);

            _cartService.CartChanged += CartService_CartChanged;
            UpdateCartSummary();
        }

        private void CartService_CartChanged(object sender, EventArgs e)
        {
            UpdateCartSummary();
        }

        private void UpdateCartSummary()
        {
            CartItems = new ObservableCollection<CartItem>(_cartService.CartItems);
            TotalPrice = _cartService.TotalPrice;
            ItemCount = _cartService.ItemCount;
            
            // Обновляем состояние команд отмены/возврата
            OnPropertyChanged(nameof(CanUndo));
            OnPropertyChanged(nameof(CanRedo));
            OnPropertyChanged(nameof(HasItems));
        }

        private void RemoveItem(object parameter)
        {
            if (parameter is CartItem cartItem)
            {
                // Запоминаем информацию об удаленном товаре для уведомления
                var productName = cartItem.Product.ShortName;
                
                var command = new RemoveFromCartCommand(_cartService, cartItem.Id);
                _undoManager.ExecuteAction(command);
                
                // Показываем уведомление об удалении товара на 3 секунды
                LastItemDeleted = true;
                Task.Delay(3000).ContinueWith(_ => 
                {
                    LastItemDeleted = false;
                }, TaskScheduler.FromCurrentSynchronizationContext());
            }
        }

        private void IncreaseQuantity(object parameter)
        {
            if (parameter is CartItem cartItem)
            {
                var command = new UpdateQuantityCommand(_cartService, cartItem.Id, cartItem.Quantity + 1);
                _undoManager.ExecuteAction(command);
            }
        }

        private void DecreaseQuantity(object parameter)
        {
            if (parameter is CartItem cartItem && cartItem.Quantity > 1)
            {
                var command = new UpdateQuantityCommand(_cartService, cartItem.Id, cartItem.Quantity - 1);
                _undoManager.ExecuteAction(command);
            }
        }

        private bool CanDecreaseQuantity(object parameter)
        {
            return parameter is CartItem cartItem && cartItem.Quantity > 1;
        }

        private void ClearCart(object parameter)
        {
            var command = new ClearCartCommand(_cartService);
            _undoManager.ExecuteAction(command);
        }

        private bool CanClearCart(object parameter)
        {
            return ItemCount > 0;
        }

        private void Checkout(object parameter)
        {
            CheckoutRequested?.Invoke(this, EventArgs.Empty);
        }

        private bool CanCheckout(object parameter)
        {
            return ItemCount > 0;
        }

        private void ContinueShopping(object parameter)
        {
            ContinueShoppingRequested?.Invoke(this, EventArgs.Empty);
        }
        
        private void CloseCart(object parameter)
        {
            CloseCartRequested?.Invoke(this, EventArgs.Empty);
        }

        private void Undo(object parameter)
        {
            // Выполняем отмену действия, если есть что отменять
            if (_undoManager.CanUndo)
            {
                var action = _undoManager.Peek();
                var isRemoveCommand = action is RemoveFromCartCommand;
                
                _undoManager.Undo();
                
                // Показываем специальное уведомление при восстановлении товара
                if (isRemoveCommand)
                {
                    LastItemRestored = true;
                    LastItemDeleted = false; // Сбрасываем предыдущее уведомление, если оно было
                    
                    // Автоматически сбрасываем флаг через 3 секунды
                    Task.Delay(3000).ContinueWith(_ => 
                    {
                        LastItemRestored = false;
                    }, TaskScheduler.FromCurrentSynchronizationContext());
                }
            }
        }

        private bool ExecuteCanUndo(object parameter)
        {
            return CanUndo;
        }

        private void Redo(object parameter)
        {
            // Выполняем повтор действия, если есть что повторять
            if (_undoManager.CanRedo)
            {
                var action = _undoManager.PeekRedo();
                var isRemoveCommand = action is RemoveFromCartCommand;
                
                _undoManager.Redo();
                
                // Показываем специальное уведомление при удалении товара
                if (isRemoveCommand)
                {
                    LastItemDeleted = true;
                    LastItemRestored = false; // Сбрасываем предыдущее уведомление, если оно было
                    
                    // Автоматически сбрасываем флаг через 3 секунды
                    Task.Delay(3000).ContinueWith(_ => 
                    {
                        LastItemDeleted = false;
                    }, TaskScheduler.FromCurrentSynchronizationContext());
                }
            }
        }

        private bool ExecuteCanRedo(object parameter)
        {
            return CanRedo;
        }

        public void UpdateCartData()
        {
            UpdateCartSummary();
        }

        // Обработчик события изменения состояния UndoManager
        private void UndoManager_StateChanged(object sender, EventArgs e)
        {
            // Обновляем свойства, которые зависят от состояния UndoManager
            OnPropertyChanged(nameof(CanUndo));
            OnPropertyChanged(nameof(CanRedo));
        }
    }
} 