using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
using WpfApp1.Models;
using WpfApp1.Services;
using System.Collections.Generic;

namespace WpfApp1.ViewModels
{
    public class CheckoutViewModel : ViewModelBase
    {
        private readonly CartService _cartService;
        private readonly UserService _userService;
        private readonly OrderService _orderService;
        private readonly ProductService _productService;
        private readonly LocalizationService _localizationService;
        
        private ObservableCollection<CartItem> _cartItems;
        private string _fullName;
        private string _phone;
        private string _address;
        private decimal _totalPrice;
        private int _itemCount;
        private bool _phoneWasEdited = false;
        private string _orderNote;
        
        public ObservableCollection<CartItem> CartItems
        {
            get => _cartItems;
            set => SetProperty(ref _cartItems, value);
        }
        
        public string FullName
        {
            get => _fullName;
            set => SetProperty(ref _fullName, value);
        }
        
        public string Phone
        {
            get => _phone;
            set
            {
                if (SetProperty(ref _phone, value))
                {
                    _phoneWasEdited = true;

                }
            }
        }
        
        public string Address
        {
            get => _address;
            set => SetProperty(ref _address, value);
        }
        
        public decimal TotalPrice
        {
            get => _totalPrice;
            set 
            { 
                if (SetProperty(ref _totalPrice, value))
                {
                    OnPropertyChanged(nameof(TotalItemsText));
                    OnPropertyChanged(nameof(TotalText));
                }
            }
        }
        
        public int ItemCount
        {
            get => _itemCount;
            set 
            { 
                if (SetProperty(ref _itemCount, value))
                {
                    OnPropertyChanged(nameof(TotalItemsText));
                }
            }
        }
        
        public string TotalItemsText
        {
            get
            {
                try
                {
                    string format = (string)Application.Current.FindResource("TotalItems");
                    return string.Format(format, ItemCount);
                }
                catch
                {
                    return $"Всего товаров: {ItemCount}";
                }
            }
        }
        
        public string TotalText
        {
            get
            {
                try
                {
                    string format = (string)Application.Current.FindResource("TotalPrice");
                    return string.Format(format, TotalPrice.ToString("F2"));
                }
                catch
                {
                    return $"Итого: {TotalPrice:F2} Br";
                }
            }
        }
        
        public string OrderNote
        {
            get => _orderNote;
            set => SetProperty(ref _orderNote, value);
        }
        
        public ICommand SubmitOrderCommand { get; }
        public ICommand CancelCommand { get; }
        
        public event EventHandler OrderPlaced;
        public event EventHandler OrderCancelled;
        public event EventHandler LanguageChanged;
        
        public CheckoutViewModel(CartService cartService, UserService userService, OrderService orderService, ProductService productService, LocalizationService localizationService = null)
        {
            _cartService = cartService;
            _userService = userService;
            _orderService = orderService;
            _productService = productService;
            _localizationService = localizationService;

            CartItems = new ObservableCollection<CartItem>(_cartService.CartItems);
            TotalPrice = _cartService.TotalPrice;
            ItemCount = _cartService.ItemCount;

            var user = _userService.GetCurrentUser();
            if (user != null)
            {
                FullName = user.FullName;
                Phone = user.Phone;
                Address = user.Address;
            }

            ClearErrors();

            SubmitOrderCommand = new RelayCommand(SubmitOrder, CanSubmitOrder);
            CancelCommand = new RelayCommand(CancelCheckout);
  
            if (_localizationService != null)
            {
                _localizationService.LanguageChanged += LocalizationService_LanguageChanged;
            }
        }
        
        private void LocalizationService_LanguageChanged(object sender, EventArgs e)
        {
            OnPropertyChanged(nameof(TotalItemsText));
            OnPropertyChanged(nameof(TotalText));
            
            LanguageChanged?.Invoke(this, EventArgs.Empty);
        }
        
        private void ValidatePhone()
        {
            if (!_phoneWasEdited)
                return;
                
            RemoveError(nameof(Phone));
            
            if (string.IsNullOrWhiteSpace(Phone))
            {
                string errorMessage;
                try
                {
                    errorMessage = (string)Application.Current.FindResource("PhoneRequired");
                }
                catch
                {
                    errorMessage = "Номер телефона обязателен для заполнения";
                }
                
                AddError(errorMessage, nameof(Phone));
                return;
            }

            var pattern = @"^(\+375|375|80)(29|33|44|25)[0-9]{7}$";
            
            if (!Regex.IsMatch(Phone, pattern))
            {
                string errorMessage;
                try
                {
                    errorMessage = (string)Application.Current.FindResource("PhoneInvalid");
                }
                catch
                {
                    errorMessage = "Введите корректный номер телефона в формате +375XXXXXXXXX, 375XXXXXXXXX или 80XXXXXXXXX";
                }
                
                AddError(errorMessage, nameof(Phone));
            }
        }
        
        private void SubmitOrder(object parameter)
        {
            _phoneWasEdited = true;

            var order = new Order
            {
                UserId = _userService.GetCurrentUser().Id,
                Items = new List<CartItem>(_cartItems.Select(ci => new CartItem
                {
                    Id = 0,
                    ProductId = ci.Product?.Id ?? ci.ProductId,
                    Product = null,
                    Price = ci.Product?.DiscountedPrice ?? ci.Price,
                    Quantity = ci.Quantity,
                    UserId = _userService.GetCurrentUser().Id,
                    ProductImage = ci.Product?.ImagesJson
                })),
                Status = "Новый",
                OrderDate = DateTime.Now,
                DeliveryAddress = Address,
                ContactPhone = Phone,
                Note = OrderNote,
                TotalAmount = TotalPrice
            };

            try
            {
                UpdateProductQuantities(order.Items);
                
                var createdOrder = _orderService.CreateOrder(order);
                
                if (createdOrder == null || createdOrder.Id == 0)
                {
                    throw new Exception("Не удалось создать заказ. Возможно, проблема с базой данных.");
                }
                
                _productService.RaiseProductsUpdated();
                
                var user = _userService.GetCurrentUser();
                if (!string.IsNullOrEmpty(FullName) && user.FullName != FullName)
                {
                    user.FullName = FullName;
                }
                
                if (!string.IsNullOrEmpty(Phone) && user.Phone != Phone)
                {
                    user.Phone = Phone;
                }
                
                if (!string.IsNullOrEmpty(Address) && user.Address != Address)
                {
                    user.Address = Address;
                }
                
                _userService.UpdateUser(user);
                
                _cartService.ClearCart();
                
                OrderPlaced?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"{(string)Application.Current.FindResource("OrderError")}: {ex.Message}",
                    (string)Application.Current.FindResource("Error"),
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }
        
        private void UpdateProductQuantities(List<CartItem> items)
        {
            if (items == null || !items.Any())
            {
                return;
            }
            
            List<string> unavailableItems = new List<string>();
            
            // Сначала проверяем наличие товаров
            foreach (var item in items)
            {
                if (item == null)
                    continue;
                
                int productId = 0;
                
                if (item.Product != null && item.Product.Id > 0)
                {
                    productId = item.Product.Id;
                }
                else if (item.ProductId > 0)
                {
                    productId = item.ProductId;
                }
                
                if (productId > 0 && item.Quantity > 0)
                {
                    try
                    {
                        var product = _productService.GetProductById(productId);
                        if (product == null)
                        {
                            unavailableItems.Add($"Товар с ID {productId} не найден");
                            continue;
                        }
                        
                        if (product.Quantity < item.Quantity)
                        {
                            unavailableItems.Add($"Недостаточно товара '{product.ShortName}' на складе. Доступно: {product.Quantity}, запрошено: {item.Quantity}");
                        }
                    }
                    catch (Exception ex)
                    {
                        unavailableItems.Add($"Ошибка при проверке товара с ID {productId}: {ex.Message}");
                    }
                }
            }
            
            // Если есть товары с недостаточным количеством, выбрасываем исключение
            if (unavailableItems.Count > 0)
            {
                throw new InvalidOperationException(string.Join("\n", unavailableItems));
            }
            
            // Если все товары доступны, обновляем их количество
            foreach (var item in items)
            {
                if (item == null)
                    continue;
                
                int productId = 0;
                
                if (item.Product != null && item.Product.Id > 0)
                {
                    productId = item.Product.Id;
                }
                else if (item.ProductId > 0)
                {
                    productId = item.ProductId;
                }
                
                if (productId > 0 && item.Quantity > 0)
                {
                    _productService.UpdateProductQuantityDirect(productId, item.Quantity);
                }
            }
        }
        
        private bool CanSubmitOrder(object parameter)
        {
            ValidatePhone();

            bool hasValidationErrors = _phoneWasEdited && HasErrors;
            
            return !string.IsNullOrWhiteSpace(FullName) &&
                  !string.IsNullOrWhiteSpace(Phone) &&
                  !string.IsNullOrWhiteSpace(Address) &&
                  !hasValidationErrors &&
                  ItemCount > 0;
        }
        
        private void CancelCheckout(object parameter)
        {
            OrderCancelled?.Invoke(this, EventArgs.Empty);
        }
    }
} 