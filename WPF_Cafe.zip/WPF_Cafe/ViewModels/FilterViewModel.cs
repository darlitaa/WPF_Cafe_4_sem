using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using WpfApp1.Models;
namespace WpfApp1.ViewModels
{
    public class FilterViewModel : ViewModelBase
    {
        private ObservableCollection<string> _manufacturers;
        private decimal _minPrice;
        private decimal _maxPrice;
        private decimal _selectedMinPrice;
        private decimal _selectedMaxPrice;
        private bool _showOnlyDiscounted;
        private bool _showOnlyInStock;
        private string _selectedManufacturer;
        private ObservableCollection<Product> _originalProducts;
        private string _validationMessage;
        public ObservableCollection<string> Manufacturers
        {
            get => _manufacturers;
            set => SetProperty(ref _manufacturers, value);
        }
        public decimal MinPrice
        {
            get => _minPrice;
            set => SetProperty(ref _minPrice, value);
        }
        public decimal MaxPrice
        {
            get => _maxPrice;
            set => SetProperty(ref _maxPrice, value);
        }
        public decimal SelectedMinPrice
        {
            get => _selectedMinPrice;
            set
            {
                if (SetProperty(ref _selectedMinPrice, value))
                {
                    // Если минимальная цена стала больше максимальной,
                    // корректируем максимальную цену
                    if (_selectedMinPrice > _selectedMaxPrice)
                    {
                        SelectedMaxPrice = _selectedMinPrice;
                        ShowValidationMessage("MinPriceGreaterThanMax");
                    }
                    else
                    {
                        ValidationMessage = string.Empty;
                    }
                }
            }
        }
        public decimal SelectedMaxPrice
        {
            get => _selectedMaxPrice;
            set
            {
                if (SetProperty(ref _selectedMaxPrice, value))
                {
                    // Если максимальная цена стала меньше минимальной,
                    // корректируем минимальную цену
                    if (_selectedMaxPrice < _selectedMinPrice)
                    {
                        SelectedMinPrice = _selectedMaxPrice;
                        ShowValidationMessage("MaxPriceLessThanMin");
                    }
                    else
                    {
                        ValidationMessage = string.Empty;
                    }
                }
            }
        }
        public bool ShowOnlyDiscounted
        {
            get => _showOnlyDiscounted;
            set => SetProperty(ref _showOnlyDiscounted, value);
        }
        public bool ShowOnlyInStock
        {
            get => _showOnlyInStock;
            set => SetProperty(ref _showOnlyInStock, value);
        }
        public string SelectedManufacturer
        {
            get => _selectedManufacturer;
            set => SetProperty(ref _selectedManufacturer, value);
        }
        public string ValidationMessage
        {
            get => _validationMessage;
            set => SetProperty(ref _validationMessage, value);
        }
        public ICommand ApplyFiltersCommand { get; set; }
        public ICommand ResetFiltersCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        public FilterViewModel(ObservableCollection<Product> products)
        {
            _originalProducts = products;
            
            ApplyFiltersCommand = new RelayCommand(ApplyFilters);
            ResetFiltersCommand = new RelayCommand(ResetFilters);
            CancelCommand = new RelayCommand(Cancel);
            
            // Инициализируем фильтры сразу при создании объекта
            InitializeFilters(products);
        }
        private void InitializeFilters(ObservableCollection<Product> products)
        {
            string allManufacturersText = (string)Application.Current.FindResource("AllManufacturers");
            
            // Сначала создаем новую коллекцию для производителей
            var manufacturersList = products
                .Select(p => p.Manufacturer)
                .Where(m => !string.IsNullOrEmpty(m))
                .Distinct()
                .OrderBy(m => m)
                .ToList();
                
            Manufacturers = new ObservableCollection<string>(manufacturersList);
            
            // Добавляем опцию "Все производители" только если коллекция не пуста
            if (Manufacturers.Count > 0)
            {
                Manufacturers.Insert(0, allManufacturersText);
                SelectedManufacturer = allManufacturersText;
            }
            
            MinPrice = 0;
            MaxPrice = products.Any() ? products.Max(p => p.DiscountedPrice) : 1000;
            SelectedMinPrice = MinPrice;
            SelectedMaxPrice = MaxPrice;
            ShowOnlyDiscounted = false;
            ShowOnlyInStock = false;
            ValidationMessage = string.Empty;
        }
        private void ApplyFilters(object parameter)
        {
            // НЕ вызываем InitializeFilters здесь, так как это сбросит выбранные фильтры
            // Логика реализована в классе FilterView.xaml.cs
		}
        public void ResetFilters(object parameter)
        {
            string allManufacturersText = (string)Application.Current.FindResource("AllManufacturers");
            if (_originalProducts != null && _originalProducts.Any())
            {
                MinPrice = 0;
                MaxPrice = _originalProducts.Max(p => p.DiscountedPrice);
                SelectedMinPrice = MinPrice;
                SelectedMaxPrice = MaxPrice;
            }
            else
            {
                MinPrice = 0;
                MaxPrice = 1000;
                SelectedMinPrice = MinPrice;
                SelectedMaxPrice = MaxPrice;
            }
            SelectedManufacturer = allManufacturersText;
            ShowOnlyDiscounted = false;
            OnPropertyChanged(nameof(ShowOnlyDiscounted));
            ShowOnlyInStock = false;
            OnPropertyChanged(nameof(ShowOnlyInStock));
            ValidationMessage = string.Empty;
        }
        private void Cancel(object parameter)
        {
        }
        private void ShowValidationMessage(string resourceKey)
        {
            try
            {
                ValidationMessage = (string)Application.Current.FindResource(resourceKey);
            }
            catch
            {
                // Если ресурс не найден, используем ключ как сообщение
                ValidationMessage = resourceKey;
            }
            
            // Автоматически очищаем сообщение через 5 секунд
            System.Threading.Tasks.Task.Delay(5000).ContinueWith(_ =>
            {
                Application.Current.Dispatcher.Invoke(() =>
                {
                    ValidationMessage = string.Empty;
                });
            });
        }
    }
}