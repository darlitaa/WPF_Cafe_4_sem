using System;
using System.Windows;
using System.Windows.Input;
using WpfApp1.Services;

namespace WpfApp1.ViewModels
{
    public class LoginViewModel : ViewModelBase
    {
        private readonly UserService _userService;
        private string _username;
        private string _password;
        private string _errorMessage;
        private bool _isLoggingIn;
        private int _selectedTabIndex;
        private string _title;
        
        public string Title
        {
            get => _title;
            set => SetProperty(ref _title, value);
        }
        
        public int SelectedTabIndex
        {
            get => _selectedTabIndex;
            set => SetProperty(ref _selectedTabIndex, value);
        }
        
        public string Username
        {
            get => _username;
            set 
            {
                if (SetProperty(ref _username, value))
                {
                    ErrorMessage = string.Empty;
                    (LoginCommand as RelayCommand)?.RaiseCanExecuteChanged();
                }
            }
        }
        
        public string Password
        {
            get => _password;
            set 
            {
                if (SetProperty(ref _password, value))
                {
                    ErrorMessage = string.Empty;
                    (LoginCommand as RelayCommand)?.RaiseCanExecuteChanged();
                }
            }
        }
        
        public string ErrorMessage
        {
            get => _errorMessage;
            set 
            {
                if (SetProperty(ref _errorMessage, value))
                {
                    OnPropertyChanged(nameof(HasErrorMessage));
                }
            }
        }
        
        public bool HasError => true;
        
        public bool HasErrorMessage => !string.IsNullOrEmpty(ErrorMessage);
        
        public bool IsLoggingIn
        {
            get => _isLoggingIn;
            set => SetProperty(ref _isLoggingIn, value);
        }
        
        public ICommand LoginCommand { get; }
        public ICommand SwitchToRegisterCommand { get; }
        public ICommand SwitchToLoginCommand { get; }
        
        public event EventHandler LoginSuccessful;
        
        public LoginViewModel(UserService userService)
        {
            _userService = userService;
            LoginCommand = new RelayCommand(Login, CanLogin);
            SwitchToRegisterCommand = new RelayCommand(_ => SelectedTabIndex = 1);
            SwitchToLoginCommand = new RelayCommand(_ => SelectedTabIndex = 0);

            Username = string.Empty;
            Password = string.Empty;
            SelectedTabIndex = 0;
        }
        
        private bool CanLogin(object parameter)
        {
            return !string.IsNullOrWhiteSpace(Username) && 
                   !string.IsNullOrWhiteSpace(Password) && 
                   !IsLoggingIn;
        }

		private void Login(object parameter)
		{
			if (IsLoggingIn) return;

			IsLoggingIn = true;
			ErrorMessage = string.Empty;

			try
			{
                // Проверяем сначала наличие пользователя с таким именем
                var user = _userService.GetUserByUsername(Username);
                
                // Если пользователь найден и заблокирован, выводим сообщение о блокировке
                if (user != null && user.IsBlocked)
                {
                    ErrorMessage = (string)Application.Current.FindResource("AccountBlocked");
                    return;
                }
                
				var isAuthenticated = _userService.Authenticate(Username, Password);

				if (isAuthenticated)
				{
					LoginSuccessful?.Invoke(this, EventArgs.Empty);
				}
				else
				{
					ErrorMessage = (string)Application.Current.FindResource("InvalidCredentials");
				}
			}
			catch (Exception ex)
			{
				ErrorMessage = $"{(string)Application.Current.FindResource("LoginError")}: {ex.Message}";
			}
			finally
			{
				IsLoggingIn = false;
			}
		}
	}
    
    public class RelayCommand : ICommand
    {
        private readonly Action<object> _execute;
        private readonly Predicate<object> _canExecute;
        
        public RelayCommand(Action<object> execute, Predicate<object> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }
        
        public bool CanExecute(object parameter)
        {
            return _canExecute == null || _canExecute(parameter);
        }
        
        public void Execute(object parameter)
        {
            _execute(parameter);
        }
        
        public void RaiseCanExecuteChanged()
        {
            CommandManager.InvalidateRequerySuggested();
        }
        
        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }
    }
} 