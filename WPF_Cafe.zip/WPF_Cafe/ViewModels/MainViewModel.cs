using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using WpfApp1.Models;
using WpfApp1.Services;
using System.Threading;
namespace WpfApp1.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private readonly ProductService _productService;
        private readonly UserService _userService;
        private readonly CartService _cartService;
        private readonly LocalizationService _localizationService;
        private ObservableCollection<Product> _products;
        private ObservableCollection<Category> _categories;
        private Product _selectedProduct;
        private Category _selectedCategory;
        private string _searchText;
        private bool _isCartVisible;
        private CartViewModel _cartViewModel;
        private int _totalProductCount;
        private DateTime _currentDate;
        private CancellationTokenSource _searchCancellationTokenSource;
        private bool _isSearching;
        private bool _searchInTitle = true;
        private bool _searchInDescription = true;
        private FilterEventArgs _currentFilterSettings;
        private string _defaultCategoryTitle;
        public ObservableCollection<Product> Products
        {
            get => _products;
            set => SetProperty(ref _products, value);
        }
        public ObservableCollection<Category> Categories
        {
            get => _categories;
            set => SetProperty(ref _categories, value);
        }
        public Product SelectedProduct
        {
            get => _selectedProduct;
            set => SetProperty(ref _selectedProduct, value);
        }
        public Category SelectedCategory
        {
            get => _selectedCategory;
            set
            {
                if (SetProperty(ref _selectedCategory, value) && value != null)
                {
                    LoadProductsByCategory(value.Name);
                }
            }
        }
        public string SearchText
        {
            get => _searchText;
            set
            {
                if (SetProperty(ref _searchText, value))
                {
                    Search(null);
                }
            }
        }
        public bool IsCartVisible
        {
            get => _isCartVisible;
            set => SetProperty(ref _isCartVisible, value);
        }
        public CartViewModel CartViewModel
        {
            get => _cartViewModel;
            set => SetProperty(ref _cartViewModel, value);
        }
        public int TotalProductCount
        {
            get => _totalProductCount;
            set
            {
                if (SetProperty(ref _totalProductCount, value))
                {
                    var allProductsCategory = Categories?.FirstOrDefault(c => c.Name == GetLocalizedCategoryName("AllProducts"));
                    if (allProductsCategory != null)
                    {
                        allProductsCategory.ProductCount = value;
                    }
                }
            }
        }
        public DateTime CurrentDate
        {
            get => _currentDate;
            set => SetProperty(ref _currentDate, value);
        }
        public bool IsSearching
        {
            get => _isSearching;
            set => SetProperty(ref _isSearching, value);
        }
        public bool SearchInTitle
        {
            get => _searchInTitle;
            set => SetProperty(ref _searchInTitle, value);
        }
        public bool SearchInDescription
        {
            get => _searchInDescription;
            set => SetProperty(ref _searchInDescription, value);
        }
        public ICommand SearchCommand { get; }
        public ICommand ShowAllProductsCommand { get; }
        public ICommand AddProductCommand { get; }
        public ICommand EditProductCommand { get; }
        public ICommand DeleteProductCommand { get; }
        public ICommand LogoutCommand { get; }
        public ICommand ShowHomeCommand { get; }
        public ICommand ShowCartCommand { get; }
        public ICommand CloseCartCommand { get; }
        public ICommand ShowAdminPanelCommand { get; }
        public ICommand SelectCategoryCommand { get; }
        public ICommand ViewProductDetailsCommand { get; }
        public ICommand AddToCartCommand { get; }
        public ICommand TestDateCommand { get; }
        public ICommand ShowFilterViewCommand { get; }
        public ICommand ToggleLanguageCommand { get; }
        public ICommand ShowProfileCommand { get; }
        public ICommand ShowReviewsCommand { get; }
        public bool IsAdmin => _userService.IsUserAdmin();
        public event EventHandler LogoutRequested;
        public event EventHandler<Product> EditProductRequested;
        public event EventHandler AddProductRequested;
        public event EventHandler CartRequested;
        public event EventHandler AdminPanelRequested;
        public event EventHandler<Product> ViewProductDetailsRequested;
        public event EventHandler CheckoutRequested;
        public event EventHandler ShowFilterViewRequested;
        public event EventHandler ShowProfileRequested;
        public event EventHandler ShowHomeCommandRequested;
        public event EventHandler ShowReviewsRequested;
        public string DefaultCategoryTitle
        {
            get 
            { 
                if (string.IsNullOrEmpty(_defaultCategoryTitle))
                {
                    _defaultCategoryTitle = GetLocalizedCategoryName("AllProducts");
                }
                return _defaultCategoryTitle; 
            }
            private set => SetProperty(ref _defaultCategoryTitle, value);
        }
        public MainViewModel(ProductService productService, UserService userService, CartService cartService = null, LocalizationService localizationService = null)
        {
            _productService = productService;
            _userService = userService;
            _cartService = cartService;
            _localizationService = localizationService;
            _products = new ObservableCollection<Product>();
            _categories = new ObservableCollection<Category>();
            _isCartVisible = false;
            _currentDate = DateTime.Now;
            
            // Инициализация заголовка категории "Все товары"
            _defaultCategoryTitle = GetLocalizedCategoryName("AllProducts");
            
            if (cartService != null)
            {
                _cartViewModel = new CartViewModel(cartService, userService);
                _cartViewModel.CheckoutRequested += CartViewModel_CheckoutRequested;
                _cartViewModel.ContinueShoppingRequested += CartViewModel_ContinueShoppingRequested;
                _cartViewModel.CloseCartRequested += CartViewModel_CloseCartRequested;
                cartService.CartChanged += (sender, e) =>
                {
                    if (cartService.ItemCount == 0)
                    {
                        IsCartVisible = false;
                    }
                };
            }
            SearchCommand = new RelayCommand(Search);
            ShowAllProductsCommand = new RelayCommand(ShowAllProducts);
            AddProductCommand = new RelayCommand(AddProduct, _ => IsAdmin);
            EditProductCommand = new RelayCommand(EditProduct, CanEditProduct);
            DeleteProductCommand = new RelayCommand(DeleteProduct, CanEditProduct);
            LogoutCommand = new RelayCommand(Logout);
            ShowHomeCommand = new RelayCommand(ShowAllProducts);
            ShowCartCommand = new RelayCommand(ShowCart);
            CloseCartCommand = new RelayCommand(CloseCart);
            ShowAdminPanelCommand = new RelayCommand(ShowAdminPanel, _ => IsAdmin);
            SelectCategoryCommand = new RelayCommand(SelectCategory);
            ViewProductDetailsCommand = new RelayCommand(ViewProductDetails);
            AddToCartCommand = new RelayCommand(AddToCart, CanAddToCart);
            TestDateCommand = new RelayCommand(TestDate);
            ShowFilterViewCommand = new RelayCommand(ShowFilterView);
            ToggleLanguageCommand = new RelayCommand(ToggleLanguage);
            ShowProfileCommand = new RelayCommand(ShowProfile);
            ShowReviewsCommand = new RelayCommand(ShowReviews);
            Initialize();
        }
        private void Initialize()
        {
            CurrentDate = DateTime.Today;
            LoadProducts();
            TotalProductCount = _products.Count;
            LoadCategories();
            var allProductsCategory = Categories.FirstOrDefault(c => c.Name == GetLocalizedCategoryName("AllProducts"));
            if (allProductsCategory != null)
            {
                allProductsCategory.IsSelected = true;
                SelectedCategory = null;
            }
        }
        private string GetLocalizedCategoryName(string resourceKey)
        {
            try
            {
                return (string)System.Windows.Application.Current.FindResource(resourceKey);
            }
            catch
            {
                return resourceKey;
            }
        }
        private void LoadCategories()
        {
            var categories = _productService.GetAllCategories();
            Categories.Clear();
            var allProductsCategory = new Category
            {
                Id = 0,
                Name = GetLocalizedCategoryName("AllProducts"),
                Description = GetLocalizedCategoryName("AllProducts"),
                ImagePath = "/Resources/Images/photo.jpg",
                IconText = "🍴"
            };
            allProductsCategory.ProductCount = TotalProductCount;
            Categories.Add(allProductsCategory);
            foreach (var category in categories)
            {
                string originalName = category.Name;
                if (category.Name == "Кофе" || category.Name == "Coffee")
                {
                    category.Name = GetLocalizedCategoryName("Coffee");
                    category.ProductCount = _productService.GetProductsByCategory("Кофе").Count;
                }
                else if (category.Name == "Десерты" || category.Name == "Desserts")
                {
                    category.Name = GetLocalizedCategoryName("Desserts");
                    category.ProductCount = _productService.GetProductsByCategory("Десерты").Count;
                }
                else if (category.Name == "Закуски" || category.Name == "Snacks")
                {
                    category.Name = GetLocalizedCategoryName("Snacks");
                    category.ProductCount = _productService.GetProductsByCategory("Закуски").Count;
                }
                Categories.Add(category);
            }
        }
        private void LoadProducts()
        {
            var products = _productService.GetAllProducts();
            if (products == null || products.Count == 0)
            {
                return;
            }
            Products.Clear();
            foreach (var product in products)
            {
                Products.Add(product);
            }
            TotalProductCount = products.Count;
        }
        private void LoadProductsByCategory(string categoryName)
        {
            var products = _productService.GetProductsByCategory(categoryName);
            Products.Clear();
            foreach (var product in products)
            {
                Products.Add(product);
            }
        }
        private void Search(object parameter)
        {
            _searchCancellationTokenSource?.Cancel();
            _searchCancellationTokenSource = new CancellationTokenSource();
            
            try
            {
                if (string.IsNullOrWhiteSpace(SearchText))
                {
                    LoadProducts();
                    return;
                }
                IsSearching = true;
                
                var searchOptions = new SearchOptions
                {
                    SearchTerm = SearchText,
                    SearchInTitle = SearchInTitle,
                    SearchInDescription = SearchInDescription
                };
                var products = _productService.SearchProducts(SearchText, searchOptions);
                Products.Clear();
                foreach (var product in products)
                {
                    Products.Add(product);
                }
            }
            catch (Exception ex)
            {
                // Обработка ошибок
            }
            finally
            {
                IsSearching = false;
            }
        }
        private void ShowAllProducts(object parameter)
        {
            foreach (var cat in Categories)
            {
                cat.IsSelected = false;
            }
            var allProductsCategory = Categories.FirstOrDefault(c => c.Name == GetLocalizedCategoryName("AllProducts"));
            if (allProductsCategory != null)
            {
                allProductsCategory.IsSelected = true;
            }
            
            SelectedCategory = null;
            LoadProducts();
            
            // Вызываем событие для возврата на главную
            ShowHomeCommandRequested?.Invoke(this, EventArgs.Empty);
        }
        private void SelectCategory(object parameter)
        {
            if (parameter is Category category)
            {
                foreach (var cat in Categories)
                {
                    cat.IsSelected = false;
                }
                category.IsSelected = true;
                if (category.Name == GetLocalizedCategoryName("AllProducts"))
                {
                    LoadProducts();
                    SelectedCategory = null;
                }
                else
                {
                    SelectedCategory = category;
                }
            }
        }
        private void AddProduct(object parameter)
        {
            AddProductRequested?.Invoke(this, EventArgs.Empty);
        }
        private void EditProduct(object parameter)
        {
            if (parameter is Product product)
            {
                EditProductRequested?.Invoke(this, product);
            }
            else if (SelectedProduct != null)
            {
                EditProductRequested?.Invoke(this, SelectedProduct);
            }
        }
        private bool CanEditProduct(object parameter)
        {
            return IsAdmin && (parameter is Product || SelectedProduct != null);
        }
        private void DeleteProduct(object parameter)
        {
            if (parameter is Product product)
            {
                _productService.DeleteProduct(product.Id);
                Products.Remove(product);
                if (product == SelectedProduct)
                {
                    SelectedProduct = null;
                }
                TotalProductCount = GetTotalProductCount();
            }
            else if (SelectedProduct != null)
            {
                _productService.DeleteProduct(SelectedProduct.Id);
                Products.Remove(SelectedProduct);
                SelectedProduct = null;
                TotalProductCount = GetTotalProductCount();
            }
        }
        private int GetTotalProductCount()
        {
            var allProducts = _productService.GetAllProducts();
            return allProducts.Count;
        }
        private void Logout(object parameter)
        {
            _userService.Logout();
            LogoutRequested?.Invoke(this, EventArgs.Empty);
        }
        private void ShowCart(object parameter)
        {
            if (_cartService != null && _cartService.ItemCount > 0)
            {
                IsCartVisible = true;
                CartRequested?.Invoke(this, EventArgs.Empty);
            }
            else
            {
                string messageText = GetLocalizedString("EmptyCartMessage");
                string messageTitle = GetLocalizedString("Cart");
                System.Windows.MessageBox.Show(messageText,
                    messageTitle, System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
            }
        }
        private void CloseCart(object parameter)
        {
            IsCartVisible = false;
        }
        private void ShowAdminPanel(object parameter)
        {
            AdminPanelRequested?.Invoke(this, EventArgs.Empty);
        }
        private void ViewProductDetails(object parameter)
        {
            if (parameter is Product product)
            {
                ViewProductDetailsRequested?.Invoke(this, product);
            }
        }
        private void AddToCart(object parameter)
        {
            if (_cartService != null && parameter is Product product)
            {
                try
                {
                    _cartService.AddToCart(product);
                    if (_cartViewModel != null)
                    {
                        _cartViewModel.UpdateCartData();
                    }
                    CartRequested?.Invoke(this, EventArgs.Empty);
                    IsCartVisible = true;
                }
                catch (InvalidOperationException ex)
                {
                    string messageTitle = GetLocalizedString("AddToCartError");
                    System.Windows.MessageBox.Show(ex.Message,
                        messageTitle, System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning);
                }
            }
        }
        private bool CanAddToCart(object parameter)
        {
            if (parameter is Product product)
            {
                return _cartService != null && product.InStock;
            }
            return false;
        }
        private void CartViewModel_CheckoutRequested(object sender, EventArgs e)
        {
            CheckoutRequested?.Invoke(this, EventArgs.Empty);
            IsCartVisible = false;
        }
        private void CartViewModel_ContinueShoppingRequested(object sender, EventArgs e)
        {
            IsCartVisible = false;
        }
        private void CartViewModel_CloseCartRequested(object sender, EventArgs e)
        {
            IsCartVisible = false;
        }
        private void TestDate(object parameter)
        {
            var dateInfo = $"{GetLocalizedString("CurrentDate")}: {CurrentDate:dddd, d MMMM yyyy}\n" +
                           $"{GetLocalizedString("SystemDate")}: {DateTime.Today:dddd, d MMMM yyyy}\n" +
                           $"{GetLocalizedString("Culture")}: {System.Globalization.CultureInfo.CurrentCulture.Name}";
            System.Windows.MessageBox.Show(dateInfo, GetLocalizedString("DateInfo"),
                System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
            CurrentDate = DateTime.Today;
        }
        private void ShowFilterView(object parameter)
        {
            ShowFilterViewRequested?.Invoke(this, EventArgs.Empty);
        }
        private void ToggleLanguage(object parameter)
        {
            if (_localizationService == null)
                return;
            var currentCulture = _localizationService.CurrentCulture;
            var supportedLanguages = _localizationService.SupportedLanguages;
            int currentIndex = Array.IndexOf(supportedLanguages, currentCulture);
            int nextIndex = (currentIndex + 1) % supportedLanguages.Length;
            _localizationService.CurrentCulture = supportedLanguages[nextIndex];
            RefreshUIAfterLanguageChange();
        }
        private void ShowProfile(object parameter)
        {
            ShowProfileRequested?.Invoke(this, EventArgs.Empty);
        }
        private void ShowReviews(object parameter)
        {
            // Вызываем событие для отображения отзывов
            ShowReviewsRequested?.Invoke(this, EventArgs.Empty);
        }
        public void RefreshUIAfterLanguageChange()
        {
            // Обновляем заголовок категории "Все товары"
            DefaultCategoryTitle = GetLocalizedCategoryName("AllProducts");
            
            RefreshCategories();
            var tempProducts = new ObservableCollection<Product>(Products);
            Products.Clear();
            foreach (var product in tempProducts)
            {
                Products.Add(product);
            }
            OnPropertyChanged(nameof(CurrentDate));
            OnPropertyChanged(nameof(SearchText));
        }
        private void RefreshCategories()
        {
            string selectedCategoryName = SelectedCategory?.Name;
            bool wasAllProductsSelected = false;
            if (selectedCategoryName != null)
            {
                string ruAllProducts = "Все товары";
                string enAllProducts = "All Products";
                wasAllProductsSelected = selectedCategoryName == ruAllProducts ||
                                       selectedCategoryName == enAllProducts ||
                                       selectedCategoryName == GetLocalizedCategoryName("AllProducts");
            }
            LoadCategories();
            if (wasAllProductsSelected)
            {
                var allProductsCategory = Categories.FirstOrDefault(c =>
                    c.Name == GetLocalizedCategoryName("AllProducts"));
                if (allProductsCategory != null)
                {
                    allProductsCategory.IsSelected = true;
                    LoadProducts();
                }
            }
            else if (!string.IsNullOrEmpty(selectedCategoryName))
            {
                var category = Categories.FirstOrDefault(c => LocalizedCategoryMatches(c.Name, selectedCategoryName));
                if (category != null)
                {
                    category.IsSelected = true;
                    SelectedCategory = category;
                }
            }
        }
        private bool LocalizedCategoryMatches(string name1, string name2)
        {
            var coffeeNames = new[] { "Кофе", "Coffee", GetLocalizedCategoryName("Coffee") };
            var dessertsNames = new[] { "Десерты", "Desserts", GetLocalizedCategoryName("Desserts") };
            var snacksNames = new[] { "Закуски", "Snacks", GetLocalizedCategoryName("Snacks") };
            bool bothCoffee = coffeeNames.Contains(name1) && coffeeNames.Contains(name2);
            bool bothDesserts = dessertsNames.Contains(name1) && dessertsNames.Contains(name2);
            bool bothSnacks = snacksNames.Contains(name1) && snacksNames.Contains(name2);
            return name1 == name2 || bothCoffee || bothDesserts || bothSnacks;
        }
        public void ApplyFilters(FilterEventArgs filterArgs)
        {
            // Проверяем, был ли сброс фильтров явно запрошен пользователем
            // вместо того, чтобы считать сбросом случай, когда minPrice = 0
            bool isResetFilter = filterArgs.MinPrice == 0 &&
                              filterArgs.MaxPrice == (Products != null && Products.Any() ? Products.Max(p => p.DiscountedPrice) : 1000) &&
                              !filterArgs.ShowOnlyDiscounted &&
                              !filterArgs.ShowOnlyInStock &&
                              string.IsNullOrEmpty(filterArgs.Manufacturer);
            
            _currentFilterSettings = new FilterEventArgs
            {
                MinPrice = filterArgs.MinPrice,
                MaxPrice = filterArgs.MaxPrice,
                ShowOnlyDiscounted = filterArgs.ShowOnlyDiscounted,
                ShowOnlyInStock = filterArgs.ShowOnlyInStock,
                Manufacturer = filterArgs.Manufacturer
            };
            string currentSearchTerm = SearchText;
            bool currentSearchInTitle = SearchInTitle;
            bool currentSearchInDescription = SearchInDescription;
            Category selectedCategory = SelectedCategory;
            if (isResetFilter)
            {
                if (selectedCategory != null && selectedCategory.Name != GetLocalizedCategoryName("AllProducts"))
                {
                    LoadProductsByCategory(selectedCategory.Name);
                }
                else
                {
                    LoadProducts();
                }
                _searchText = currentSearchTerm;
                SearchInTitle = currentSearchInTitle;
                SearchInDescription = currentSearchInDescription;
                OnPropertyChanged(nameof(SearchText));
                return;
            }
            var allProducts = _productService.GetAllProducts();
            if (selectedCategory != null && selectedCategory.Name != GetLocalizedCategoryName("AllProducts"))
            {
                string categoryName = selectedCategory.Name;
                if (categoryName == GetLocalizedCategoryName("Coffee"))
                {
                    allProducts = allProducts.Where(p => p.Category == "Кофе").ToList();
                }
                else if (categoryName == GetLocalizedCategoryName("Desserts"))
                {
                    allProducts = allProducts.Where(p => p.Category == "Десерты").ToList();
                }
                else if (categoryName == GetLocalizedCategoryName("Snacks"))
                {
                    allProducts = allProducts.Where(p => p.Category == "Закуски").ToList();
                }
                else
                {
                    allProducts = allProducts.Where(p => p.Category == categoryName).ToList();
                }
            }
            var filteredProducts = allProducts.AsQueryable();
            
            filteredProducts = filteredProducts.Where(p => p.DiscountedPrice >= filterArgs.MinPrice &&
                                                  p.DiscountedPrice <= filterArgs.MaxPrice);

            if (filterArgs.ShowOnlyDiscounted)
            {
                filteredProducts = filteredProducts.Where(p => p.HasDiscount);
            }
            if (filterArgs.ShowOnlyInStock)
            {
                filteredProducts = filteredProducts.Where(p => p.AvailableQuantity > 0);
            }
            if (!string.IsNullOrEmpty(filterArgs.Manufacturer))
            {
                filteredProducts = filteredProducts.Where(p => p.Manufacturer == filterArgs.Manufacturer);
            }
            if (!string.IsNullOrWhiteSpace(currentSearchTerm))
            {
                var searchOptions = new SearchOptions
                {
                    SearchTerm = currentSearchTerm,
                    SearchInTitle = currentSearchInTitle,
                    SearchInDescription = currentSearchInDescription
                };
                filteredProducts = _productService.FilterBySearchTerm(filteredProducts.ToList(), searchOptions).AsQueryable();
            }
            Products.Clear();
            foreach (var product in filteredProducts)
            {
                Products.Add(product);
            }
            if (selectedCategory != null)
            {
                foreach (var category in Categories)
                {
                    category.IsSelected = (category.Name == selectedCategory.Name);
                }
            }
            _searchText = currentSearchTerm;
            SearchInTitle = currentSearchInTitle;
            SearchInDescription = currentSearchInDescription;
            OnPropertyChanged(nameof(SearchText));
        }
        public FilterEventArgs GetCurrentFilterSettings()
        {
            if (_currentFilterSettings == null)
            {
                decimal maxPrice = 1000;
                if (Products != null && Products.Any())
                {
                    maxPrice = Products.Max(p => p.DiscountedPrice);
                }
                return new FilterEventArgs
                {
                    MinPrice = 0,
                    MaxPrice = maxPrice,
                    ShowOnlyDiscounted = false,
                    ShowOnlyInStock = false,
                    Manufacturer = null
                };
            }
            return _currentFilterSettings;
        }
        private string GetLocalizedString(string resourceKey)
        {
            try
            {
                return (string)System.Windows.Application.Current.FindResource(resourceKey);
            }
            catch
            {
                return resourceKey;
            }
        }
    }
}