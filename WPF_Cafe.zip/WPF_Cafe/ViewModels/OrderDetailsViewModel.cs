using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using WpfApp1.Models;
using WpfApp1.Services;

namespace WpfApp1.ViewModels
{
    public class OrderDetailsViewModel : ViewModelBase
    {
        private readonly OrderService _orderService;
        private Order _order;
        private ObservableCollection<CartItem> _orderItems;

        public Order Order 
        {
            get => _order;
            set
            {
                if (SetProperty(ref _order, value))
                {
                    OnPropertyChanged(nameof(OrderId));
                    OnPropertyChanged(nameof(OrderDate));
                    OnPropertyChanged(nameof(Status));
                    OnPropertyChanged(nameof(DeliveryDate));
                    OnPropertyChanged(nameof(ShippingAddress));
                    OnPropertyChanged(nameof(DeliveryAddress));
                    OnPropertyChanged(nameof(ContactPhone));
                    OnPropertyChanged(nameof(Note));
                    OnPropertyChanged(nameof(TotalAmount));
                    
                    if (value?.Items != null)
                    {
                        OrderItems = new ObservableCollection<CartItem>(value.Items);
                    }
                    else
                    {
                        OrderItems = new ObservableCollection<CartItem>();
                    }
                }
            }
        }

        public ObservableCollection<CartItem> OrderItems
        {
            get => _orderItems;
            set => SetProperty(ref _orderItems, value);
        }

        // Свойства для удобного доступа к полям заказа
        public int OrderId => _order?.Id ?? 0;
        public DateTime OrderDate => _order?.OrderDate ?? DateTime.Now;
        public string Status => _order?.Status;
        public DateTime? DeliveryDate => _order?.DeliveryDate;
        public string ShippingAddress => _order?.ShippingAddress;
        public string DeliveryAddress => _order?.DeliveryAddress;
        public string ContactPhone => _order?.ContactPhone;
        public string Note => _order?.Note;
        public decimal TotalAmount => _order?.TotalAmount ?? 0;

        public ICommand CloseOrderCommand { get; }
        public ICommand CancelOrderCommand { get; }

        public event EventHandler CloseRequested;

        public OrderDetailsViewModel(OrderService orderService)
        {
            _orderService = orderService;
            _orderItems = new ObservableCollection<CartItem>();

            CloseOrderCommand = new RelayCommand(_ => CloseRequested?.Invoke(this, EventArgs.Empty));
            CancelOrderCommand = new RelayCommand(CancelOrder, CanCancelOrder);
        }

        public void LoadOrder(int orderId)
        {
            var order = _orderService.GetOrderById(orderId);
            Order = order;
        }

        private void CancelOrder(object parameter)
        {
            if (_order != null)
            {
                _orderService.CancelOrder(_order.Id);
                Order = _orderService.GetOrderById(_order.Id); // Перезагружаем заказ с обновленным статусом
            }
        }

        private bool CanCancelOrder(object parameter)
        {
            return _order != null && 
                   _order.Status != "Отменен" && 
                   _order.Status != "Cancelled" &&
                   _order.Status != "Выполнен" && 
                   _order.Status != "Completed";
        }
    }
}