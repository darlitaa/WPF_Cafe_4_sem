using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using WpfApp1.Models;
using WpfApp1.Services;

namespace WpfApp1.ViewModels
{
    public class OrderHistoryViewModel : ViewModelBase
    {
        private readonly OrderService _orderService;
        private readonly UserService _userService;
        private ObservableCollection<Order> _orders;
        private Order _selectedOrder;
        private bool _isLoading;

        public ObservableCollection<Order> Orders
        {
            get => _orders;
            set => SetProperty(ref _orders, value);
        }

        public Order SelectedOrder
        {
            get => _selectedOrder;
            set => SetProperty(ref _selectedOrder, value);
        }

        public bool IsLoading
        {
            get => _isLoading;
            set => SetProperty(ref _isLoading, value);
        }

        public bool IsAdmin => _userService.IsUserAdmin();

        public ICommand CancelOrderCommand { get; }
        public ICommand ViewOrderDetailsCommand { get; }

        public event EventHandler<Order> ViewOrderDetailsRequested;

        public OrderHistoryViewModel(OrderService orderService, UserService userService)
        {
            _orderService = orderService;
            _userService = userService;
            _orders = new ObservableCollection<Order>();

            CancelOrderCommand = new RelayCommand(CancelOrder, CanCancelOrder);
            ViewOrderDetailsCommand = new RelayCommand(ViewOrderDetails);

            LoadOrders();
        }

        private void LoadOrders()
        {
            try
            {
                IsLoading = true;

                var currentUser = _userService.GetCurrentUser();
                if (currentUser == null)
                    return;

                var orders = IsAdmin 
                    ? _orderService.GetAllOrders() 
                    : _orderService.GetUserOrders(currentUser.Id.ToString());

                Orders.Clear();
                foreach (var order in orders.OrderByDescending(o => o.OrderDate))
                {
                    Orders.Add(order);
                }
            }
            finally
            {
                IsLoading = false;
            }
        }

        private void CancelOrder(object parameter)
        {
            if (parameter is Order order)
            {
                _orderService.CancelOrder(order.Id);

                order.Status = "Отменен";

                if (SelectedOrder == order)
                {
                    SelectedOrder = null;
                    SelectedOrder = order;
                }
            }
        }

        private bool CanCancelOrder(object parameter)
        {
            if (parameter is Order order)
            {
                return order.Status == "Новый" || order.Status == "В обработке";
            }
            return false;
        }

        private void ViewOrderDetails(object parameter)
        {
            if (parameter is Order order)
            {
                ViewOrderDetailsRequested?.Invoke(this, order);
            }
        }
    }
} 