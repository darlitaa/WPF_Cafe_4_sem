﻿using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using WpfApp1.Models;
using WpfApp1.Services;

namespace WpfApp1.ViewModels
{
	public class PersonalAccountViewModel : ViewModelBase
	{
		private readonly UserService _userService;
		private readonly LocalizationService _localizationService;
		private readonly OrderService _orderService;
		
		// Константы для валидации
		private const string PHONE_PATTERN = @"^(\+375|375|80)(29|33|44|25)[0-9]{7}$";
		private const string EMAIL_PATTERN = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
		
		private User _currentUser;
		private string _username;
		private string _fullName;
		private string _email;
		private string _phone;
		private string _address;
		private string _currentPassword;
		private string _newPassword;
		private string _confirmPassword;
		private string _errorMessage;
		private string _successMessage;
		private bool _isEditing;
		private bool _isChangingPassword;
		private ObservableCollection<CultureInfo> _availableLanguages;
		private CultureInfo _selectedLanguage;
		private ObservableCollection<ThemeManager.Theme> _availableThemes;
		private ThemeManager.Theme _selectedTheme;
		private ObservableCollection<Order> _userOrders;
		private bool _isLoadingOrders;
		private Order _selectedOrder;
		
		public User CurrentUser
		{
			get => _currentUser;
			set => SetProperty(ref _currentUser, value);
		}
		
		public string Username
		{
			get => _username;
			set => SetProperty(ref _username, value);
		}
		
		public string FullName
		{
			get => _fullName;
			set => SetProperty(ref _fullName, value);
		}
		
		public string Email
		{
			get => _email;
			set => SetProperty(ref _email, value);
		}
		
		public string Phone
		{
			get => _phone;
			set => SetProperty(ref _phone, value);
		}
		
		public string Address
		{
			get => _address;
			set => SetProperty(ref _address, value);
		}
		
		public string CurrentPassword
		{
			get => _currentPassword;
			set => SetProperty(ref _currentPassword, value);
		}
		
		public string NewPassword
		{
			get => _newPassword;
			set 
			{ 
				if (SetProperty(ref _newPassword, value))
				{
					OnPropertyChanged(nameof(PasswordsAreValid));
				}
			}
		}
		
		public string ConfirmPassword
		{
			get => _confirmPassword;
			set 
			{ 
				if (SetProperty(ref _confirmPassword, value))
				{
					OnPropertyChanged(nameof(PasswordsAreValid));
				}
			}
		}
		
		public string ErrorMessage
		{
			get => _errorMessage;
			set
			{
				SetProperty(ref _errorMessage, value);
				OnPropertyChanged(nameof(HasError));
			}
		}
		
		public string SuccessMessage
		{
			get => _successMessage;
			set
			{
				SetProperty(ref _successMessage, value);
				OnPropertyChanged(nameof(HasSuccess));
			}
		}
		
		public bool HasError => !string.IsNullOrEmpty(ErrorMessage);
		public bool HasSuccess => !string.IsNullOrEmpty(SuccessMessage);
		
		public bool IsEditing
		{
			get => _isEditing;
			set => SetProperty(ref _isEditing, value);
		}
		
		public bool IsChangingPassword
		{
			get => _isChangingPassword;
			set => SetProperty(ref _isChangingPassword, value);
		}
		
		public ObservableCollection<CultureInfo> AvailableLanguages
		{
			get => _availableLanguages;
			set => SetProperty(ref _availableLanguages, value);
		}
		
		public CultureInfo SelectedLanguage
		{
			get => _selectedLanguage;
			set
			{
				if (SetProperty(ref _selectedLanguage, value) && _localizationService != null && value != null)
				{
					_localizationService.CurrentCulture = value;
				}
			}
		}
		
		public ObservableCollection<ThemeManager.Theme> AvailableThemes
		{
			get => _availableThemes;
			set => SetProperty(ref _availableThemes, value);
		}
		
		public ThemeManager.Theme SelectedTheme
		{
			get => _selectedTheme;
			set
			{
				if (SetProperty(ref _selectedTheme, value))
				{
					OnPropertyChanged(nameof(NextThemeButtonText));
				}
			}
		}
		
		public ObservableCollection<Order> UserOrders
		{
			get => _userOrders;
			set => SetProperty(ref _userOrders, value);
		}
		
		public bool IsLoadingOrders
		{
			get => _isLoadingOrders;
			set => SetProperty(ref _isLoadingOrders, value);
		}
		
		public Order SelectedOrder
		{
			get => _selectedOrder;
			set => SetProperty(ref _selectedOrder, value);
		}
		
		public bool HasOrders => UserOrders != null && UserOrders.Count > 0;
		
		public string NextThemeButtonText => $"{GetLocalizedString("SwitchTo")} {GetNextThemeName()}";
		
		public bool PasswordsAreValid => !string.IsNullOrWhiteSpace(NewPassword) && 
				   !string.IsNullOrWhiteSpace(ConfirmPassword) &&
				   NewPassword == ConfirmPassword;
		
		public ICommand EditCommand { get; }
		public ICommand SaveCommand { get; }
		public ICommand CancelCommand { get; }
		public ICommand ChangePasswordCommand { get; }
		public ICommand SavePasswordCommand { get; }
		public ICommand CancelPasswordCommand { get; }
		public ICommand ChangeThemeCommand { get; }
		public ICommand ApplySelectedThemeCommand { get; }
		public ICommand LoadOrdersCommand { get; }
		public ICommand ViewOrderDetailsCommand { get; }
		
		public PersonalAccountViewModel(UserService userService, LocalizationService localizationService, OrderService orderService)
		{
			_userService = userService;
			_localizationService = localizationService;
			_orderService = orderService;
			
			UserOrders = new ObservableCollection<Order>();
			
			EditCommand = new RelayCommand(StartEdit);
			SaveCommand = new RelayCommand(SaveChanges, CanSaveChanges);
			CancelCommand = new RelayCommand(CancelEdit);
			ChangePasswordCommand = new RelayCommand(StartChangePassword);
			SavePasswordCommand = new RelayCommand(SavePassword, CanSavePassword);
			CancelPasswordCommand = new RelayCommand(CancelPasswordChange);
			ChangeThemeCommand = new RelayCommand(SwitchToNextTheme);
			ApplySelectedThemeCommand = new RelayCommand(ApplySelectedTheme);
			LoadOrdersCommand = new RelayCommand(LoadUserOrders);
			ViewOrderDetailsCommand = new RelayCommand(ViewOrderDetails);
			
			InitializeUser();
			InitializeLanguages();
			InitializeThemes();
			
			if (_localizationService != null)
			{
				_localizationService.LanguageChanged += (s, e) => RefreshLocalizedStrings();
			}
			
			// Загружаем заказы пользователя при инициализации
			LoadUserOrders(null);
		}
		
		private void InitializeUser()
		{
			CurrentUser = _userService.GetCurrentUser();
			if (CurrentUser != null)
			{
				Username = CurrentUser.Username;
				FullName = CurrentUser.FullName;
				Email = CurrentUser.Email;
				Phone = CurrentUser.Phone;
				Address = CurrentUser.Address;
				CurrentPassword = CurrentUser.Password;
			}
		}
		
		private void InitializeLanguages()
		{
			if (_localizationService != null)
			{
				AvailableLanguages = new ObservableCollection<CultureInfo>(_localizationService.SupportedLanguages);
				SelectedLanguage = _localizationService.CurrentCulture;
				
				// Подписываемся на событие изменения языка для синхронизации ComboBox
				_localizationService.LanguageChanged += (s, e) => 
				{
					// Принудительное обновление свойств для гарантированного обновления UI
					var tempLanguage = SelectedLanguage;
					SelectedLanguage = null;
					SelectedLanguage = _localizationService.CurrentCulture;
					OnPropertyChanged(nameof(SelectedLanguage));
				};
			}
		}
		
		private void InitializeThemes()
		{
			AvailableThemes = new ObservableCollection<ThemeManager.Theme>(
				(ThemeManager.Theme[])Enum.GetValues(typeof(ThemeManager.Theme)));
			SelectedTheme = ThemeManager.CurrentTheme;
			
			// Проверяем, инициализирован ли ThemeManager
			if (ThemeManager.CurrentTheme == ThemeManager.Theme.Default)
			{
				// Убедимся, что ThemeManager инициализирован
				ThemeManager.Initialize();
			}
		}
		
		private void RefreshLocalizedStrings()
		{
			OnPropertyChanged(nameof(AvailableLanguages));
			OnPropertyChanged(nameof(SelectedLanguage));
		}
		
		private void LoadUserOrders(object parameter)
		{
			if (_orderService == null || CurrentUser == null)
				return;
				
			try
			{
				IsLoadingOrders = true;
				ErrorMessage = string.Empty;
				
				_orderService.Initialize();
				var userOrders = _orderService.GetUserOrders(CurrentUser.Id.ToString());
				
				UserOrders.Clear();
				foreach (var order in userOrders)
				{
					UserOrders.Add(order);
				}
				
				OnPropertyChanged(nameof(HasOrders));
			}
			catch (Exception ex)
			{
				ErrorMessage = $"{GetLocalizedString("ErrorLoadingOrders")}: {ex.Message}";
			}
			finally
			{
				IsLoadingOrders = false;
			}
		}
		
		private void ViewOrderDetails(object parameter)
		{
			if (parameter is Order order)
			{
				SelectedOrder = order;
				// Здесь можно реализовать дополнительную логику для просмотра деталей заказа
			}
		}
		
		private void StartEdit(object parameter)
		{
			IsEditing = true;
			ErrorMessage = string.Empty;
			SuccessMessage = string.Empty;
		}
		
		private bool CanSaveChanges(object parameter)
		{
			return IsEditing && 
				   !string.IsNullOrWhiteSpace(FullName) && 
				   !string.IsNullOrWhiteSpace(Email);
		}
		
		private void SaveChanges(object parameter)
		{
			ErrorMessage = string.Empty;
			SuccessMessage = string.Empty;
			
			if (CurrentUser != null)
			{
				// Проверка валидности Email
				if (!string.IsNullOrWhiteSpace(Email) && !Regex.IsMatch(Email, EMAIL_PATTERN))
				{
					ErrorMessage = GetLocalizedString("InvalidEmailFormat");
					return;
				}
				
				// Проверка валидности телефона
				if (!string.IsNullOrWhiteSpace(Phone) && !Regex.IsMatch(Phone, PHONE_PATTERN))
				{
					ErrorMessage = GetLocalizedString("InvalidPhoneFormat");
					return;
				}
				
				CurrentUser.FullName = FullName;
				CurrentUser.Email = Email;
				CurrentUser.Phone = Phone;
				CurrentUser.Address = Address;
				
				try
				{
					_userService.UpdateUser(CurrentUser);
					SuccessMessage = GetLocalizedString("ProfileUpdatedSuccessfully");
					IsEditing = false;
				}
				catch (Exception ex)
				{
					ErrorMessage = $"{GetLocalizedString("ErrorUpdatingProfile")}: {ex.Message}";
				}
			}
		}
		
		private void CancelEdit(object parameter)
		{
			InitializeUser();
			IsEditing = false;
			ErrorMessage = string.Empty;
			SuccessMessage = string.Empty;
		}
		
		private void StartChangePassword(object parameter)
		{
			IsChangingPassword = true;
			NewPassword = string.Empty;
			ConfirmPassword = string.Empty;
			ErrorMessage = string.Empty;
			SuccessMessage = string.Empty;
		}
		
		private bool CanSavePassword(object parameter)
		{
			return IsChangingPassword && PasswordsAreValid;
		}
		
		private void SavePassword(object parameter)
		{
			ErrorMessage = string.Empty;
			SuccessMessage = string.Empty;
			
			if (CurrentUser != null)
			{
				if (NewPassword != ConfirmPassword)
				{
					ErrorMessage = GetLocalizedString("PasswordsDoNotMatch");
					return;
				}
				
				if (CurrentUser.Password == NewPassword)
				{
					// Вместо установки ErrorMessage показываем MessageBox
					string message = GetLocalizedString("NewPasswordSameAsCurrent");
					string title = GetLocalizedString("ErrorTitle");
					MessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Warning);
					return;
				}
				
				CurrentUser.Password = NewPassword;
				
				try
				{
					_userService.UpdateUser(CurrentUser);
					SuccessMessage = GetLocalizedString("PasswordChangedSuccessfully");
					IsChangingPassword = false;
				}
				catch (Exception ex)
				{
					ErrorMessage = $"{GetLocalizedString("ErrorChangingPassword")}: {ex.Message}";
				}
			}
		}
		
		private void CancelPasswordChange(object parameter)
		{
			IsChangingPassword = false;
			NewPassword = string.Empty;
			ConfirmPassword = string.Empty;
			ErrorMessage = string.Empty;
			SuccessMessage = string.Empty;
		}
		
		private void SwitchToNextTheme(object parameter)
		{
			ThemeManager.Theme nextTheme = ThemeManager.GetNextTheme();
			SelectedTheme = nextTheme;
			ThemeManager.ApplyTheme(nextTheme);
			OnPropertyChanged(nameof(NextThemeButtonText));
		}
		
		private void ApplySelectedTheme(object parameter)
		{
			if (SelectedTheme != ThemeManager.CurrentTheme)
			{
				ThemeManager.ApplyTheme(SelectedTheme);
				OnPropertyChanged(nameof(NextThemeButtonText));
			}
		}
		
		private string GetNextThemeName()
		{
			ThemeManager.Theme nextTheme = ThemeManager.GetNextTheme();
			return nextTheme.ToString();
		}
		
		private string GetLocalizedString(string resourceKey)
		{
			try
			{
				return (string)Application.Current.FindResource(resourceKey);
			}
			catch
			{
				// Если ресурс не найден, возвращаем ключ как есть
				return resourceKey;
			}
		}
	}
}
