using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Microsoft.Win32;
using WpfApp1.Models;
using WpfApp1.Services;
using OpenFileDialog = Microsoft.Win32.OpenFileDialog;

namespace WpfApp1.ViewModels
{
    public class ProductViewModel : ViewModelBase
    {
        private readonly ProductService _productService;
        private Product _product;
        private ObservableCollection<string> _categories;
        private ObservableCollection<string> _manufacturers;
        private bool _isNewProduct;
        private string _selectedImagePath;
        private string _price;
        private string _quantity;
        private decimal _discount;
        private string _validationMessage;
        private bool _hasValidationErrors;
        
        public Product Product
        {
            get => _product;
            set => SetProperty(ref _product, value);
        }
        
        public string Price
        {
            get => _price ?? _product.Price.ToString();
            set
            {
                if (SetProperty(ref _price, value))
                {
                    OnPropertyChanged();
                    (SaveCommand as RelayCommand)?.RaiseCanExecuteChanged();
                }
            }
        }
        
        public string Quantity
        {
            get => _quantity ?? _product.Quantity.ToString();
            set
            {
                if (SetProperty(ref _quantity, value))
                {
                    OnPropertyChanged();
                    (SaveCommand as RelayCommand)?.RaiseCanExecuteChanged();
                }
            }
        }
        
        public int Discount
        {
            get => (int)_product.Discount;
            set
            {
                if (value < 0)
                    value = 0;
                if (value > 100)
                    value = 100;
                
                if (_product.Discount != value)
                {
                    _product.Discount = value;
                    OnPropertyChanged();
                }
            }
        }
        
        public ObservableCollection<string> Categories
        {
            get => _categories;
            set => SetProperty(ref _categories, value);
        }
        
        public ObservableCollection<string> Manufacturers
        {
            get => _manufacturers;
            set => SetProperty(ref _manufacturers, value);
        }
        
        public bool IsNewProduct
        {
            get => _isNewProduct;
            set => SetProperty(ref _isNewProduct, value);
        }
        
        public string SelectedImagePath
        {
            get => _selectedImagePath;
            set => SetProperty(ref _selectedImagePath, value);
        }
        
        public string ValidationMessage
        {
            get => _validationMessage;
            set
            {
                if (SetProperty(ref _validationMessage, value))
                {
                    HasValidationErrors = !string.IsNullOrEmpty(value);
                }
            }
        }
        
        public bool HasValidationErrors
        {
            get => _hasValidationErrors;
            set => SetProperty(ref _hasValidationErrors, value);
        }
        
        public ICommand SaveCommand { get; }
        public ICommand CancelCommand { get; }
        public ICommand BrowseImageCommand { get; }
        public ICommand AddImageCommand { get; }
        public ICommand RemoveImageCommand { get; }
        
        public event EventHandler SaveCompleted;
        public event EventHandler CancelRequested;
        
        public ProductViewModel(ProductService productService, Product product = null)
        {
            _productService = productService;
            _categories = new ObservableCollection<string>();
            _manufacturers = new ObservableCollection<string>();
            
            if (product != null)
            {
                Product = new Product
                {
                    Id = product.Id,
                    ShortName = product.ShortName,
                    FullName = product.FullName,
                    Description = product.Description,
                    Category = product.Category,
                    Images = new List<string>(product.Images ?? new List<string>()),
                    Price = product.Price,
                    Quantity = product.Quantity,
                    Discount = product.Discount,
                    InStock = product.InStock,
                    TimesPurchased = product.TimesPurchased,
                    Manufacturer = product.Manufacturer
                };
                _price = product.Price.ToString();
                _quantity = product.Quantity.ToString();
                IsNewProduct = false;
            }
            else
            {
                Product = new Product
                {
                    Images = new List<string>(),
                    Price = 1,
                    Quantity = 1
                };
                _price = "1";
                _quantity = "1";
                IsNewProduct = true;
            }
            
            SaveCommand = new RelayCommand(Save, CanSave);
            CancelCommand = new RelayCommand(Cancel);
            BrowseImageCommand = new RelayCommand(BrowseImage);
            AddImageCommand = new RelayCommand(AddImage, CanAddImage);
            RemoveImageCommand = new RelayCommand(RemoveImage, CanRemoveImage);
            
            LoadCategories();
            LoadManufacturers();
        }
        
        private void LoadCategories()
        {
            var categories = _productService.GetAllCategories();
            Categories.Clear();
            foreach (var category in categories)
            {
                Categories.Add(category.Name);
            }
        }
        
        private void LoadManufacturers()
        {
            var manufacturers = _productService.GetDistinctManufacturers();
            Manufacturers.Clear();
            foreach (var manufacturer in manufacturers)
            {
                Manufacturers.Add(manufacturer);
            }
        }
        
        private bool CanSave(object parameter)
        {
            // Базовые проверки на заполненность полей
            bool basicValidation = !string.IsNullOrWhiteSpace(Product.ShortName) &&
                   !string.IsNullOrWhiteSpace(Product.FullName) &&
                   !string.IsNullOrWhiteSpace(Product.Description) &&
                   !string.IsNullOrWhiteSpace(Product.Category) &&
                   !string.IsNullOrWhiteSpace(Product.Manufacturer) &&
                   !string.IsNullOrWhiteSpace(Price) &&
                   !string.IsNullOrWhiteSpace(Quantity) &&
                   Product.Images.Count > 0;
            
            return basicValidation;
        }
        
        private void Save(object parameter)
        {
            try
            {
                ValidationMessage = string.Empty;
                
                if (!CanSave(null))
                {
                    ValidationMessage = GetLocalizedString("InvalidDataErrorMessage");
                    return;
                }

                // Заменяем точку на запятую для корректного парсинга
                string normalizedPrice = Price.Replace('.', ',');
                
                // Пробуем парсить число с учетом региональных настроек
                if (!decimal.TryParse(normalizedPrice, out decimal parsedPrice) || parsedPrice <= 0)
                {
                    ValidationMessage = GetLocalizedString("InvalidPriceError");
                    return;
                }

                // Проверяем, что в поле Quantity не введено дробное число
                if (Quantity.Contains(".") || Quantity.Contains(","))
                {
                    ValidationMessage = GetLocalizedString("IntegerQuantityRequired");
                    return;
                }

                // Для количества проверяем, что это целое число
                if (!int.TryParse(Quantity, out int parsedQuantity) || parsedQuantity <= 0)
                {
                    ValidationMessage = GetLocalizedString("InvalidQuantityError");
                    return;
                }

                if (Product.Discount < 0 || Product.Discount > 100)
                {
                    ValidationMessage = GetLocalizedString("InvalidDiscountError");
                    return;
                }

                Product.Discount = Math.Floor(Product.Discount);
                Product.Price = parsedPrice;
                Product.Quantity = parsedQuantity;

                var productToSave = new Product
                {
                    Id = Product.Id,
                    ShortName = Product.ShortName,
                    FullName = Product.FullName,
                    Description = Product.Description,
                    Category = Product.Category,
                    Images = new List<string>(Product.Images ?? new List<string>()),
                    Price = Product.Price,
                    Quantity = Product.Quantity,
                    Discount = Product.Discount,
                    InStock = Product.InStock,
                    TimesPurchased = Product.TimesPurchased,
                    Manufacturer = Product.Manufacturer
                };
                
                if (IsNewProduct)
                {
                    _productService.AddProduct(productToSave);
                }
                else
                {
                    _productService.UpdateProduct(productToSave);
                }
                
                SaveCompleted?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show($"Ошибка при сохранении товара: {ex.Message}", 
                                              "Ошибка", System.Windows.MessageBoxButton.OK, 
                                              System.Windows.MessageBoxImage.Error);
            }
        }
        
        private void Cancel(object parameter)
        {
            CancelRequested?.Invoke(this, EventArgs.Empty);
        }
        
        private void BrowseImage(object parameter)
        {
            try
            {
                string imagePath = App.ImageService.UploadImage();
                if (!string.IsNullOrEmpty(imagePath))
                {
                    SelectedImagePath = imagePath;
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show($"Ошибка при выборе изображения: {ex.Message}", 
                    "Ошибка", System.Windows.MessageBoxButton.OK, 
                    System.Windows.MessageBoxImage.Error);
            }
        }
        
        private void AddImage(object parameter)
        {
            if (!string.IsNullOrWhiteSpace(SelectedImagePath) && !Product.Images.Contains(SelectedImagePath))
            {
                var images = new List<string>(Product.Images) { SelectedImagePath };
                Product.Images = images;
                OnPropertyChanged(nameof(Product));
                SelectedImagePath = string.Empty;
            }
        }
        
        private bool CanAddImage(object parameter)
        {
            return !string.IsNullOrWhiteSpace(SelectedImagePath);
        }
        
        private void RemoveImage(object parameter)
        {
            if (parameter is string path && Product.Images.Contains(path))
            {
                var images = new List<string>(Product.Images);
                images.Remove(path);
                
                Product.Images = images;
                OnPropertyChanged(nameof(Product));
            }
        }
        
        private bool CanRemoveImage(object parameter)
        {
            return parameter is string && Product.Images.Contains((string)parameter);
        }

        private string GetLocalizedString(string resourceKey)
        {
            try
            {
                return (string)System.Windows.Application.Current.FindResource(resourceKey);
            }
            catch
            {
                return resourceKey;
            }
        }
    }
} 