using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using WpfApp1.Models;
using WpfApp1.Services;

namespace WpfApp1.ViewModels
{
    public class RegisterViewModel : ViewModelBase
    {
        private readonly UserService _userService;
        
        private string _username;
        private string _password;
        private string _confirmPassword;
        private string _fullName;
        private string _email;
        private string _phone;
        private string _address;
        private string _errorMessage;
        private bool _isRegistering;
        
        // Словари для хранения ошибок по полям
        private Dictionary<string, string> _fieldErrors = new Dictionary<string, string>();
        private List<string> _fieldValidationOrder = new List<string> { "Username", "Password", "ConfirmPassword", "Email", "Phone" };
        
        // Шаблоны для проверки валидности полей
        private const string EMAIL_PATTERN = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
        private const string PHONE_PATTERN = @"^(\+375|375|80)(29|33|44|25)[0-9]{7}$";
        
        public string Username
        {
            get => _username;
            set
            {
                if (SetProperty(ref _username, value))
                {
                    ValidateUsername();
                    UpdateErrorMessage();
                    (RegisterCommand as RelayCommand)?.RaiseCanExecuteChanged();
                }
            }
        }
        
        public string Password
        {
            get => _password;
            set
            {
                if (SetProperty(ref _password, value))
                {
                    ValidatePassword();
                    ValidatePasswordMatch();
                    UpdateErrorMessage();
                    (RegisterCommand as RelayCommand)?.RaiseCanExecuteChanged();
                }
            }
        }
        
        public string ConfirmPassword
        {
            get => _confirmPassword;
            set
            {
                if (SetProperty(ref _confirmPassword, value))
                {
                    ValidatePasswordMatch();
                    UpdateErrorMessage();
                    (RegisterCommand as RelayCommand)?.RaiseCanExecuteChanged();
                }
            }
        }
        
        public string FullName
        {
            get => _fullName;
            set
            {
                if (SetProperty(ref _fullName, value))
                {
                    (RegisterCommand as RelayCommand)?.RaiseCanExecuteChanged();
                }
            }
        }
        
        public string Email
        {
            get => _email;
            set
            {
                if (SetProperty(ref _email, value))
                {
                    ValidateEmail();
                    UpdateErrorMessage();
                    (RegisterCommand as RelayCommand)?.RaiseCanExecuteChanged();
                }
            }
        }
        
        public string Phone
        {
            get => _phone;
            set
            {
                if (SetProperty(ref _phone, value))
                {
                    ValidatePhone();
                    UpdateErrorMessage();
                    (RegisterCommand as RelayCommand)?.RaiseCanExecuteChanged();
                }
            }
        }
        
        public string Address
        {
            get => _address;
            set
            {
                if (SetProperty(ref _address, value))
                {
                    (RegisterCommand as RelayCommand)?.RaiseCanExecuteChanged();
                }
            }
        }
        
        public string ErrorMessage
        {
            get => _errorMessage;
            set
            {
                if (SetProperty(ref _errorMessage, value))
                {
                    OnPropertyChanged(nameof(HasErrorMessage));
                }
            }
        }
        
        public bool HasError => true;
        
        public bool HasErrorMessage => !string.IsNullOrEmpty(ErrorMessage);
        
        public bool IsRegistering
        {
            get => _isRegistering;
            set => SetProperty(ref _isRegistering, value);
        }
        
        public ICommand RegisterCommand { get; }
        public event EventHandler<RegistrationEventArgs> RegistrationSuccessful;
        
        public RegisterViewModel(UserService userService)
        {
            _userService = userService;
            RegisterCommand = new RelayCommand(Register, CanRegister);
            
            ClearFields();
        }
        
        private void ClearFields()
        {
            Username = string.Empty;
            Password = string.Empty;
            ConfirmPassword = string.Empty;
            FullName = string.Empty;
            Email = string.Empty;
            Phone = string.Empty;
            Address = string.Empty;
            ErrorMessage = string.Empty;
            _fieldErrors.Clear();
        }
        
        // Метод для обновления сообщения об ошибке (показывает только первую ошибку)
        private void UpdateErrorMessage()
        {
            // Проверяем наличие ошибок в порядке приоритета полей
            foreach (string field in _fieldValidationOrder)
            {
                if (_fieldErrors.ContainsKey(field) && !string.IsNullOrEmpty(_fieldErrors[field]))
                {
                    ErrorMessage = _fieldErrors[field];
                    return;
                }
            }
            
            // Если у нас нет ошибок в приоритетных полях, проверяем любые другие ошибки
            if (_fieldErrors.Count > 0)
            {
                var firstError = _fieldErrors.Values.FirstOrDefault(e => !string.IsNullOrEmpty(e));
                ErrorMessage = firstError ?? string.Empty;
            }
            else
            {
                ErrorMessage = string.Empty;
            }
        }
        
        // Публичный метод для явной валидации поля по имени
        public void ValidateField(string fieldName)
        {
            if (string.IsNullOrEmpty(fieldName))
                return;
                
            switch (fieldName)
            {
                case "Username":
                    ValidateUsername();
                    break;
                case "Password":
                    ValidatePassword();
                    break;
                case "ConfirmPassword":
                    ValidatePasswordMatch();
                    break;
                case "Email":
                    ValidateEmail();
                    break;
                case "Phone":
                    ValidatePhone();
                    break;
            }
            
            // Обновляем сообщение об ошибке после валидации
            UpdateErrorMessage();
            
            // Обновляем состояние команды
            (RegisterCommand as RelayCommand)?.RaiseCanExecuteChanged();
        }
        
        private bool CanRegister(object parameter)
        {
            // Проверяем пароль в PasswordBox, если он передан
            string password = Password;
            string confirmPassword = ConfirmPassword;
            
            if (parameter is System.Windows.Controls.PasswordBox passwordBox)
            {
                password = passwordBox.Password;
            }
            
            return _fieldErrors.Count == 0 && 
                   !string.IsNullOrWhiteSpace(Username) &&
                   !string.IsNullOrWhiteSpace(password) &&
                   !string.IsNullOrWhiteSpace(confirmPassword) &&
                   !string.IsNullOrEmpty(_fullName) &&
                   !string.IsNullOrWhiteSpace(_email) &&
                   !string.IsNullOrWhiteSpace(_phone) &&
                   !string.IsNullOrWhiteSpace(_address) &&
                   password == confirmPassword &&
                   !_userService.IsUsernameTaken(Username) &&
                   !IsRegistering;
        }
        
        private void Register(object parameter)
        {
            if (IsRegistering) return;
            
            IsRegistering = true;
            ErrorMessage = string.Empty;
            
            try
            {
                // Получаем пароль из PasswordBox если он передан
                if (parameter is System.Windows.Controls.PasswordBox passwordBox)
                {
                    Password = passwordBox.Password;
                    
                    // Если пароль пустой, показываем ошибку
                    if (string.IsNullOrWhiteSpace(Password))
                    {
                        _fieldErrors["Password"] = (string)Application.Current.FindResource("PasswordRequired");
                        UpdateErrorMessage();
                        return;
                    }
                }
                
                // Проверяем существование пользователя перед регистрацией
                if (_userService.IsUsernameTaken(Username))
                {
                    _fieldErrors["Username"] = (string)Application.Current.FindResource("UsernameTaken");
                    UpdateErrorMessage();
                    return;
                }
                
                // Проверка валидности всех полей
                if (!ValidateAllFields())
                {
                    UpdateErrorMessage();
                    return;
                }
                
                // Создаем нового пользователя
                var newUser = new User
                {
                    Username = Username,
                    Password = Password,
                    FullName = FullName,
                    Email = Email,
                    Phone = Phone,
                    Address = Address,
                    IsAdmin = false,
                    IsBlocked = false,
                    CreatedAt = DateTime.Now
                };
                
                // Добавляем пользователя в БД
                _userService.AddUser(newUser);
                
                // Автоматически авторизуем пользователя
                bool isAuthenticated = _userService.Authenticate(Username, Password);
                
                if (!isAuthenticated)
                {
                    // Если автоматическая авторизация не удалась, просто уведомляем о успешной регистрации
                    RegistrationSuccessful?.Invoke(this, new RegistrationEventArgs(false));
                }
                else
                {
                    // Если авторизация успешна, уведомляем с флагом автоматического входа
                    RegistrationSuccessful?.Invoke(this, new RegistrationEventArgs(true));
                }
                
                // Очищаем поля
                ClearFields();
            }
            catch (Exception ex)
            {
                ErrorMessage = $"{(string)Application.Current.FindResource("RegistrationError")}: {ex.Message}";
            }
            finally
            {
                IsRegistering = false;
            }
        }
        
        private bool ValidateAllFields()
        {
            bool isUsernameValid = ValidateUsername();
            bool isPasswordValid = ValidatePassword();
            bool isPasswordMatchValid = ValidatePasswordMatch();
            bool isEmailValid = string.IsNullOrWhiteSpace(Email) || ValidateEmail();
            bool isPhoneValid = string.IsNullOrWhiteSpace(Phone) || ValidatePhone();
            
            return isUsernameValid && isPasswordValid && isPasswordMatchValid && isEmailValid && isPhoneValid;
        }
        
        public bool ValidateUsername()
        {
            if (string.IsNullOrWhiteSpace(Username))
            {
                _fieldErrors["Username"] = (string)Application.Current.FindResource("UsernameRequired");
                return false;
            }
            
            if (Username.Length < 3 || Username.Length > 20)
            {
                _fieldErrors["Username"] = (string)Application.Current.FindResource("UsernameLength");
                return false;
            }
            
            if (_userService.IsUsernameTaken(Username))
            {
                _fieldErrors["Username"] = (string)Application.Current.FindResource("UsernameTaken");
                return false;
            }
            
            _fieldErrors.Remove("Username");
            return true;
        }
        
        public bool ValidatePassword()
        {
            if (string.IsNullOrWhiteSpace(Password))
            {
                _fieldErrors["Password"] = (string)Application.Current.FindResource("PasswordRequired");
                return false;
            }
            
            if (Password.Length < 6)
            {
                _fieldErrors["Password"] = (string)Application.Current.FindResource("PasswordTooShort");
                return false;
            }
            
            _fieldErrors.Remove("Password");
            return true;
        }
        
        public bool ValidatePasswordMatch()
        {
            if (string.IsNullOrWhiteSpace(Password) || string.IsNullOrWhiteSpace(ConfirmPassword))
            {
                if (!string.IsNullOrWhiteSpace(ConfirmPassword))
                {
                    _fieldErrors["ConfirmPassword"] = (string)Application.Current.FindResource("PasswordRequired");
                }
                return false;
            }
            
            if (Password != ConfirmPassword)
            {
                _fieldErrors["ConfirmPassword"] = (string)Application.Current.FindResource("PasswordsDontMatch");
                return false;
            }
            
            _fieldErrors.Remove("ConfirmPassword");
            return true;
        }
        
        public bool ValidateEmail()
        {
            if (!string.IsNullOrWhiteSpace(Email) && !IsValidEmail(Email))
            {
                _fieldErrors["Email"] = (string)Application.Current.FindResource("InvalidEmail");
                return false;
            }
            
            _fieldErrors.Remove("Email");
            return true;
        }
        
        public bool ValidatePhone()
        {
            if (!string.IsNullOrWhiteSpace(Phone) && !IsValidPhone(Phone))
            {
                _fieldErrors["Phone"] = (string)Application.Current.FindResource("InvalidPhone");
                return false;
            }
            
            _fieldErrors.Remove("Phone");
            return true;
        }
        
        private bool IsValidEmail(string email)
        {
            return Regex.IsMatch(email, EMAIL_PATTERN);
        }
        
        private bool IsValidPhone(string phone)
        {
            return Regex.IsMatch(phone, PHONE_PATTERN);
        }

        // Класс событий регистрации для передачи дополнительной информации
        public class RegistrationEventArgs : EventArgs
        {
            public bool AutoLogin { get; private set; }
            
            public RegistrationEventArgs(bool autoLogin)
            {
                AutoLogin = autoLogin;
            }
        }
    }
} 