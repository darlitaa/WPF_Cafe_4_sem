using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using WpfApp1.Models;
using WpfApp1.Services;
using System.Diagnostics;

namespace WpfApp1.ViewModels
{
    public class ReviewViewModel : ViewModelBase
    {
        private readonly ReviewService _reviewService;
        private readonly UserService _userService;
        private ObservableCollection<Review> _reviews;
        private string _newReviewText;
        private int _newRating;
        private bool _hasReview;
        private double _averageRating;
        private int _totalReviews;

        public ObservableCollection<Review> Reviews
        {
            get => _reviews;
            set => SetProperty(ref _reviews, value);
        }

        public string NewReviewText
        {
            get => _newReviewText;
            set
            {
                if (SetProperty(ref _newReviewText, value))
                {
                    OnPropertyChanged(nameof(CanSubmitReview));
                }
            }
        }

        public int NewRating
        {
            get => _newRating;
            set
            {
                if (SetProperty(ref _newRating, value))
                {
                    OnPropertyChanged(nameof(CanSubmitReview));
                }
            }
        }

        public bool HasReview
        {
            get => _hasReview;
            set => SetProperty(ref _hasReview, value);
        }

        public bool CanAddReview => !HasReview;
        
        public double AverageRating
        {
            get => _averageRating;
            set => SetProperty(ref _averageRating, value);
        }

        public int TotalReviews
        {
            get => _totalReviews;
            set => SetProperty(ref _totalReviews, value);
        }

        public bool CanSubmitReview => !string.IsNullOrWhiteSpace(NewReviewText) && NewRating > 0;

        public bool IsAdmin => _userService.IsUserAdmin();

        public ICommand AddReviewCommand { get; }
        public ICommand DeleteReviewCommand { get; }

        public ReviewViewModel(ReviewService reviewService, UserService userService)
        {
            _reviewService = reviewService;
            _userService = userService;
            _reviews = new ObservableCollection<Review>();
            _newRating = 0;

            AddReviewCommand = new RelayCommand(AddReview, _ => CanSubmitReview);
            DeleteReviewCommand = new RelayCommand(DeleteReview, _ => IsAdmin);

            _reviewService.ReviewsChanged += ReviewService_ReviewsChanged;

            LoadReviews();
            CheckUserReview();
            UpdateStatistics();
        }

        private void ReviewService_ReviewsChanged(object sender, EventArgs e)
        {
            LoadReviews();
            UpdateStatistics();
            CheckUserReview();
        }

        private void LoadReviews()
        {
            try
            {
                var reviews = _reviewService.GetAllReviews();
                Reviews.Clear();
                foreach (var review in reviews)
                {
                    Reviews.Add(review);
                }
                Debug.WriteLine($"Загружено {reviews.Count} отзывов");
                TotalReviews = reviews.Count;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при загрузке отзывов: {ex.Message}");
            }
        }

        private void CheckUserReview()
        {
            try
            {
                var currentUserId = _userService.GetCurrentUserId();
                if (currentUserId != 0)
                {
                    HasReview = _reviewService.HasUserReview(currentUserId);
                    OnPropertyChanged(nameof(CanAddReview));
                    Debug.WriteLine($"Проверка наличия отзыва для пользователя {currentUserId}: {HasReview}");
                }
                else
                {
                    Debug.WriteLine("Пользователь не авторизован, не может оставлять отзывы");
                    HasReview = true; // Не авторизованные пользователи не могут оставлять отзывы
                    OnPropertyChanged(nameof(CanAddReview));
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при проверке отзыва пользователя: {ex.Message}");
            }
        }

        private void UpdateStatistics()
        {
            try
            {
                AverageRating = _reviewService.GetAverageRating();
                TotalReviews = Reviews.Count;
                Debug.WriteLine($"Средний рейтинг: {AverageRating}, количество отзывов: {TotalReviews}");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при обновлении статистики: {ex.Message}");
            }
        }

        private void AddReview(object parameter)
        {
            try
            {
                var currentUserId = _userService.GetCurrentUserId();
                if (currentUserId == 0)
                {
                    Debug.WriteLine("Пользователь не авторизован, невозможно добавить отзыв");
                    return;
                }

                var review = new Review
                {
                    UserId = currentUserId,
                    Rating = NewRating,
                    Text = NewReviewText.Trim(),
                    CreatedAt = DateTime.Now
                };

                _reviewService.AddReview(review);
                Debug.WriteLine($"Отзыв успешно добавлен от пользователя {currentUserId}");

                // Сбросить форму
                NewReviewText = string.Empty;
                NewRating = 0;
                OnPropertyChanged(nameof(CanSubmitReview));

                // Обновить UI
                LoadReviews();
                CheckUserReview();
                UpdateStatistics();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при добавлении отзыва: {ex.Message}");
            }
        }

        private void DeleteReview(object parameter)
        {
            try
            {
                if (parameter is int reviewId)
                {
                    _reviewService.DeleteReview(reviewId);
                    Debug.WriteLine($"Отзыв с ID {reviewId} успешно удален");
                    
                    // Обновить UI
                    LoadReviews();
                    CheckUserReview();
                    UpdateStatistics();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при удалении отзыва: {ex.Message}");
            }
        }
    }
} 