using System;
using System.Windows;
using System.Windows.Controls;
using WpfApp1.Models;
using WpfApp1.Services;
using WpfApp1.ViewModels;
using System.Windows.Input;
using System.Threading;
using System.Windows.Media;
using System.Diagnostics;
using System.Windows.Threading;
using System.Linq;

namespace WpfApp1.Views
{
    public partial class AdminPanelView : Window
    {
        private readonly ProductService _productService;
        private readonly UserService _userService;
        private readonly OrderService _orderService;
        private readonly LocalizationService _localizationService;
        private DispatcherTimer _autoRefreshTimer;
        private bool _dataLoaded = false;
        
        public AdminPanelView(ProductService productService, UserService userService, OrderService orderService)
        {
            InitializeComponent();
            _productService = productService;
            _userService = userService;
            _orderService = orderService;
            _localizationService = App.LocalizationService;
            
            Title = (string)Application.Current.FindResource("AdminPanelTitle");
            _localizationService.LanguageChanged += LocalizationService_LanguageChanged;
            _productService.ProductsUpdated += ProductService_ProductsUpdated;
            Closed += AdminPanelView_Closed;
            
            // Инициализация OrderService и ProductService сразу при загрузке окна
            _orderService.Initialize();
            _productService.Initialize();
            
            Debug.WriteLine("AdminPanelView: Инициализация панели администратора");
            
            // Установка шаблонов содержимого для вкладок
            TabContentControl.ContentTemplate = (DataTemplate)TabContentControl.Resources["ProductsTabTemplate"];
            
            // Создаем и настраиваем таймер автоматического обновления (каждые 5 секунд)
            _autoRefreshTimer = new DispatcherTimer();
            _autoRefreshTimer.Interval = TimeSpan.FromSeconds(5);
            _autoRefreshTimer.Tick += AutoRefreshTimer_Tick;
            _autoRefreshTimer.Start();
            
            // Настраиваем обработчик загрузки окна
            this.Loaded += AdminPanelView_Loaded;
            
            // Загрузка данных о товарах при запуске
            LoadProductsData();
            
            // Регистрируем обработчик изменения вкладок
            AdminTabControl.SelectionChanged += AdminTabControl_SelectionChanged;
        }
        
        private void AdminPanelView_Loaded(object sender, RoutedEventArgs e)
        {
            // После полной загрузки окна загрузим данные снова
            Debug.WriteLine("AdminPanelView: Окно полностью загружено");
            Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() =>
            {
                if (AdminTabControl.SelectedIndex == 0)
                {
                    LoadProductsData();
                }
                else if (AdminTabControl.SelectedIndex == 1)
                {
                    LoadOrdersData();
                }
                _dataLoaded = true;
            }));
        }
        
        private void AutoRefreshTimer_Tick(object sender, EventArgs e)
        {
            // Автоматическое обновление данных текущей вкладки
            if (_dataLoaded) // Обновляем только если начальная загрузка данных завершена
            {
                if (AdminTabControl.SelectedIndex == 0)
                {
                    Debug.WriteLine("AdminPanelView: Автоматическое обновление товаров");
                    LoadProductsData(false); // Не показываем сообщения об ошибках при авто-обновлении
                }
                else if (AdminTabControl.SelectedIndex == 1)
                {
                    Debug.WriteLine("AdminPanelView: Автоматическое обновление заказов");
                    LoadOrdersData(false); // Не показываем сообщения об ошибках при авто-обновлении
                }
                else if (AdminTabControl.SelectedIndex == 2)
                {
                    Debug.WriteLine("AdminPanelView: Автоматическое обновление пользователей");
                    LoadUsersData(false); // Не показываем сообщения об ошибках при авто-обновлении
                }
            }
        }
        
        // Обработчик нажатия кнопки обновления заказов
        private void RefreshOrders_Click(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("AdminPanelView: Обновление данных о заказах по запросу пользователя");
            _orderService.Initialize();
            LoadOrdersData(true);
        }
        
        // Обработчик нажатия кнопки обновления товаров
        private void RefreshProducts_Click(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("AdminPanelView: Обновление данных о товарах по запросу пользователя");
            // Не вызываем _productService.Initialize(), так как это может вызвать StackOverflowException
            LoadProductsData(true);
        }
        
        private void LocalizationService_LanguageChanged(object sender, EventArgs e)
        {
            Title = (string)Application.Current.FindResource("AdminPanelTitle");
            // Обновляем данные текущей активной вкладки
            if (AdminTabControl.SelectedIndex == 0)
            {
                LoadProductsData();
            }
            else if (AdminTabControl.SelectedIndex == 1)
            {
                LoadOrdersData();
            }
        }
        
        private void AdminPanelView_Closed(object sender, EventArgs e)
        {
            _productService.ProductsUpdated -= ProductService_ProductsUpdated;
            _localizationService.LanguageChanged -= LocalizationService_LanguageChanged;
            _autoRefreshTimer.Stop();
        }
        
        private void ProductService_ProductsUpdated(object sender, EventArgs e)
        {
            if (AdminTabControl.SelectedIndex == 0 && _dataLoaded)
            {
                Dispatcher.Invoke(() =>
                {
                    // Получаем DataGrid из текущего шаблона
                    var productsDataGrid = FindChild<DataGrid>(TabContentControl, "ProductsDataGrid");
                    
                    // Сохраняем выбранный элемент перед обновлением
                    var selectedIndex = -1;
                    if (productsDataGrid != null)
                    {
                        selectedIndex = productsDataGrid.SelectedIndex;
                    }
                    
                    LoadProductsData();
                    
                    // Восстанавливаем выбранный элемент после обновления, если возможно
                    productsDataGrid = FindChild<DataGrid>(TabContentControl, "ProductsDataGrid");
                    if (productsDataGrid != null && selectedIndex >= 0 && selectedIndex < productsDataGrid.Items.Count)
                    {
                        productsDataGrid.SelectedIndex = selectedIndex;
                        productsDataGrid.ScrollIntoView(productsDataGrid.SelectedItem);
                    }
                });
            }
        }
        
        private void AdminTabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sender is TabControl tabControl)
            {
                Debug.WriteLine($"AdminPanelView: Изменение вкладки на индекс {tabControl.SelectedIndex}");
                
                if (tabControl.SelectedIndex == 0) // Вкладка товаров
                {
                    Debug.WriteLine("AdminPanelView: Переход на вкладку товаров");
                    TabContentControl.ContentTemplate = (DataTemplate)TabContentControl.Resources["ProductsTabTemplate"];
                    
                    // Загружаем данные с небольшой задержкой, чтобы дать время UI обновиться
                    Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() => {
                        // Не вызываем инициализацию, просто загружаем данные
                        LoadProductsData();
                    }));
                }
                else if (tabControl.SelectedIndex == 1) // Вкладка заказов
                {
                    Debug.WriteLine("AdminPanelView: Переход на вкладку заказов");
                    TabContentControl.ContentTemplate = (DataTemplate)TabContentControl.Resources["OrdersTabTemplate"];
                    
                    // Загружаем данные с небольшой задержкой, чтобы дать время UI обновиться
                    Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() => {
                        // Повторная инициализация OrderService перед загрузкой данных
                        _orderService.Initialize();
                        LoadOrdersData();
                    }));
                }
                else if (tabControl.SelectedIndex == 2) // Вкладка пользователей
                {
                    Debug.WriteLine("AdminPanelView: Переход на вкладку пользователей");
                    TabContentControl.ContentTemplate = (DataTemplate)TabContentControl.Resources["UsersTabTemplate"];
                    
                    // Загружаем данные с небольшой задержкой, чтобы дать время UI обновиться
                    Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() => {
                        // Инициализируем UserService и загружаем данные
                        _userService.Initialize();
                        LoadUsersData();
                    }));
                }
            }
        }
        
        private void LoadProductsData(bool showErrors = true)
        {
            try
            {
                var products = _productService.GetAllProducts();
                Debug.WriteLine($"AdminPanelView: Загружено товаров: {products.Count}");
                
                // Находим DataGrid в текущем шаблоне
                if (TabContentControl.ContentTemplate != null)
                {
                    // Используем асинхронную загрузку через Dispatcher для корректной работы с визуальным деревом
                    // Задаем высокий приоритет для обновления данных
                    Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(() =>
                    {
                        try {
                            var productsDataGrid = FindChild<DataGrid>(TabContentControl, "ProductsDataGrid");
                            if (productsDataGrid != null)
                            {
                                Debug.WriteLine("AdminPanelView: DataGrid товаров найден, загрузка данных");
                                
                                // Сохраняем выбранный индекс
                                int selectedIndex = productsDataGrid.SelectedIndex;
                                object selectedItem = productsDataGrid.SelectedItem;
                                
                                productsDataGrid.ItemsSource = null;
                                productsDataGrid.Items.Clear();
                                productsDataGrid.ItemsSource = products;
                                productsDataGrid.Items.Refresh();
                                
                                // Восстанавливаем выбранный элемент
                                if (selectedIndex >= 0 && selectedIndex < products.Count)
                                {
                                    productsDataGrid.SelectedIndex = selectedIndex;
                                    productsDataGrid.ScrollIntoView(productsDataGrid.SelectedItem);
                                }
                                else if (selectedItem != null)
                                {
                                    productsDataGrid.SelectedItem = selectedItem;
                                    productsDataGrid.ScrollIntoView(selectedItem);
                                }
                                
                                Debug.WriteLine("AdminPanelView: Данные о товарах успешно обновлены");
                            }
                            else
                            {
                                Debug.WriteLine("AdminPanelView: DataGrid товаров не найден в шаблоне");
                            }
                        }
                        catch (Exception ex) {
                            Debug.WriteLine($"AdminPanelView: Ошибка при обновлении DataGrid товаров: {ex.Message}");
                        }
                    }));
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"AdminPanelView: Ошибка при загрузке товаров: {ex.Message}");
                if (showErrors)
                {
                    string errorMsg = string.Format((string)Application.Current.FindResource("ErrorLoadingProducts"), ex.Message);
                    MessageBox.Show(errorMsg, (string)Application.Current.FindResource("Error"), MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        
        private void LoadOrdersData(bool showErrors = true)
        {
            try
            {
                var orders = _orderService.GetAllOrders();
                Debug.WriteLine($"AdminPanelView: Загружено заказов: {orders.Count}");
                
                // Находим DataGrid в текущем шаблоне
                if (TabContentControl.ContentTemplate != null)
                {
                    // Важно: нужно дождаться создания визуального дерева для ContentTemplate
                    // Задаем высокий приоритет для обновления данных
                    Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(() =>
                    {
                        try {
                            var ordersDataGrid = FindChild<DataGrid>(TabContentControl, "OrdersDataGrid");
                            if (ordersDataGrid != null)
                            {
                                Debug.WriteLine("AdminPanelView: DataGrid заказов найден, загрузка данных");
                                
                                // Сохраняем выбранный индекс
                                int selectedIndex = ordersDataGrid.SelectedIndex;
                                object selectedItem = ordersDataGrid.SelectedItem;
                                
                                ordersDataGrid.ItemsSource = null;
                                ordersDataGrid.Items.Clear();
                                ordersDataGrid.ItemsSource = orders;
                                ordersDataGrid.Items.Refresh();
                                
                                // Восстанавливаем выбранный элемент
                                if (selectedIndex >= 0 && selectedIndex < orders.Count)
                                {
                                    ordersDataGrid.SelectedIndex = selectedIndex;
                                    ordersDataGrid.ScrollIntoView(ordersDataGrid.SelectedItem);
                                }
                                else if (selectedItem != null)
                                {
                                    ordersDataGrid.SelectedItem = selectedItem;
                                    ordersDataGrid.ScrollIntoView(selectedItem);
                                }
                                
                                Debug.WriteLine("AdminPanelView: Данные о заказах успешно обновлены");
                            }
                            else
                            {
                                Debug.WriteLine("AdminPanelView: DataGrid заказов не найден в шаблоне");
                            }
                        }
                        catch (Exception ex) {
                            Debug.WriteLine($"AdminPanelView: Ошибка при обновлении DataGrid заказов: {ex.Message}");
                        }
                    }));
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"AdminPanelView: Ошибка при загрузке заказов: {ex.Message}");
                if (showErrors)
                {
                    string errorMsg = string.Format((string)Application.Current.FindResource("ErrorLoadingOrders"), ex.Message);
                    MessageBox.Show(errorMsg, (string)Application.Current.FindResource("Error"), MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        
        // Метод для загрузки данных о пользователях
        private void LoadUsersData(bool showErrors = true)
        {
            try
            {
                var users = _userService.GetAllUsers();
                Debug.WriteLine($"AdminPanelView: Загружено пользователей: {users.Count}");
                
                // Находим DataGrid в текущем шаблоне
                if (TabContentControl.ContentTemplate != null)
                {
                    Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(() =>
                    {
                        try {
                            var usersDataGrid = FindChild<DataGrid>(TabContentControl, "UsersDataGrid");
                            if (usersDataGrid != null)
                            {
                                Debug.WriteLine("AdminPanelView: DataGrid пользователей найден, загрузка данных");
                                
                                // Сохраняем выбранный индекс
                                int selectedIndex = usersDataGrid.SelectedIndex;
                                object selectedItem = usersDataGrid.SelectedItem;
                                
                                usersDataGrid.ItemsSource = null;
                                usersDataGrid.Items.Clear();
                                usersDataGrid.ItemsSource = users;
                                usersDataGrid.Items.Refresh();
                                
                                // Восстанавливаем выбранный элемент
                                if (selectedIndex >= 0 && selectedIndex < users.Count)
                                {
                                    usersDataGrid.SelectedIndex = selectedIndex;
                                    usersDataGrid.ScrollIntoView(usersDataGrid.SelectedItem);
                                }
                                else if (selectedItem != null)
                                {
                                    usersDataGrid.SelectedItem = selectedItem;
                                    usersDataGrid.ScrollIntoView(selectedItem);
                                }
                                
                                Debug.WriteLine("AdminPanelView: Данные о пользователях успешно обновлены");
                            }
                            else
                            {
                                Debug.WriteLine("AdminPanelView: DataGrid пользователей не найден в шаблоне");
                            }
                        }
                        catch (Exception ex) {
                            Debug.WriteLine($"AdminPanelView: Ошибка при обновлении DataGrid пользователей: {ex.Message}");
                        }
                    }));
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"AdminPanelView: Ошибка при загрузке данных о пользователях: {ex.Message}");
                if (showErrors)
                {
                    MessageBox.Show($"Ошибка при загрузке данных о пользователях: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        
        // Вспомогательный метод для поиска элемента в визуальном дереве
        private T FindChild<T>(DependencyObject parent, string childName) where T : DependencyObject
        {
            if (parent == null) return null;
            
            T foundChild = null;
            
            int childrenCount = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < childrenCount; i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                
                if (child is T typedChild && (child as FrameworkElement)?.Name == childName)
                {
                    foundChild = typedChild;
                    break;
                }
                
                // Рекурсивный поиск в дочерних элементах
                foundChild = FindChild<T>(child, childName);
                
                if (foundChild != null) break;
            }
            
            return foundChild;
        }
        
        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            var productView = new ProductView(_productService, null, _localizationService);
            productView.Owner = this;
            productView.ShowDialog();
            LoadProductsData();
        }
        
        private void EditProduct_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.CommandParameter is Product product)
            {
                var productView = new ProductView(_productService, product, _localizationService);
                productView.Owner = this;
                productView.ShowDialog();
                LoadProductsData();
            }
        }
        
        private void DeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.CommandParameter is Product product)
            {
                string confirmMessage = string.Format((string)Application.Current.FindResource("ConfirmDeleteProduct"), product.ShortName);
                string confirmTitle = (string)Application.Current.FindResource("DeleteConfirmation");
                var result = MessageBox.Show(confirmMessage, confirmTitle, MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        _productService.DeleteProduct(product.Id);
                        LoadProductsData();
                    }
                    catch (Exception ex)
                    {
                        string errorMsg = string.Format((string)Application.Current.FindResource("ErrorDeletingProduct"), ex.Message);
                        MessageBox.Show(errorMsg, (string)Application.Current.FindResource("Error"), MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
        
        private void ViewOrder_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.CommandParameter is Order order)
            {
                var idConverter = new WpfApp1.Converters.OrderIdToReadableConverter();
                string readableOrderId = idConverter.Convert(order.Id, typeof(string), null, Thread.CurrentThread.CurrentUICulture) as string;
                var statusConverter = new WpfApp1.Converters.OrderStatusConverter();
                string localizedStatus = statusConverter.Convert(order.Status, typeof(string), null, Thread.CurrentThread.CurrentUICulture) as string;
                
                // Локализация заголовка в зависимости от языка
                string infoTitle = Thread.CurrentThread.CurrentUICulture.Name.StartsWith("ru") ? "Заказ" : "Order";
                
                // Подготовка информационных строк
                string orderIdInfo = string.Format((string)Application.Current.FindResource("OrderUserInfo"), order.UserId);
                string orderDateInfo = string.Format((string)Application.Current.FindResource("OrderDateInfo"), order.OrderDate.ToString("dd.MM.yyyy HH:mm"));
                string orderStatusInfo = string.Format((string)Application.Current.FindResource("OrderStatusInfo"), localizedStatus);
                
                // Форматируем сумму с валютой "Br" для согласованности с проектом
                string formattedAmount = $"{order.TotalAmount:0.00} Br";
                string orderAmountInfo = string.Format((string)Application.Current.FindResource("OrderAmountInfo"), formattedAmount);
                
                // Формируем список товаров с их количествами в формате: "Товар1(x1), Товар2(x2), ..."
                string itemsList = string.Join(", ", order.Items.GroupBy(i => i.ProductName)
                                                      .Select(g => $"{g.Key}(x{g.Count()})"));
                
                string orderItemsInfo = string.Format((string)Application.Current.FindResource("OrderItemsInfo"), itemsList);
                
                // Собираем все строки вместе с правильным форматированием
                string orderInfo = $"{infoTitle} {readableOrderId}\n\n" +
                                   $"{orderIdInfo}\n" +
                                   $"{orderDateInfo}\n" +
                                   $"{orderStatusInfo}\n" +
                                   $"{orderAmountInfo}\n" +
                                   $"{orderItemsInfo}";
                
                MessageBox.Show(orderInfo, infoTitle, MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        
        private void CompleteOrder_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.CommandParameter is Order order)
            {
                // Проверяем, можно ли завершить заказ в текущем статусе
                // Учитываем как русские, так и английские названия статусов
                bool canComplete = order.Status == "Новый" || 
                                  order.Status == "В обработке" || 
                                  order.Status == "Готовится" || 
                                  order.Status == "Готов к выдаче" ||
                                  order.Status == "Pending" ||
                                  order.Status == "Processing" ||
                                  order.Status == "Ready";
                
                bool alreadyCompleted = order.Status == "Выполнен" || 
                                      order.Status == "Completed" ||
                                      order.Status == "Отменен" ||
                                      order.Status == "Cancelled";
                
                if (alreadyCompleted)
                {
                    MessageBox.Show(
                        (string)Application.Current.FindResource("CannotCompleteOrderMessage"), 
                        (string)Application.Current.FindResource("Information"), 
                        MessageBoxButton.OK, 
                        MessageBoxImage.Information);
                    return;
                }
                
                var converter = new WpfApp1.Converters.OrderIdToReadableConverter();
                string readableOrderId = converter.Convert(order.Id, typeof(string), "short", Thread.CurrentThread.CurrentUICulture) as string;
                string confirmMessage = string.Format((string)Application.Current.FindResource("ConfirmCompleteOrder"), readableOrderId);
                var result = MessageBox.Show(confirmMessage, (string)Application.Current.FindResource("Confirm"), MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        // Всегда устанавливаем статус на русском языке для сохранения в БД
                        string completedStatus = "Выполнен";
                        
                        // Обновляем заказ: устанавливаем дату доставки и статус
                        order.DeliveryDate = DateTime.Now;
                        order.Status = completedStatus;
                        _orderService.UpdateOrder(order);
                        
                        // Показываем сообщение об успехе
                        string successMsg = string.Format((string)Application.Current.FindResource("OrderCompletedSuccess"), readableOrderId);
                        MessageBox.Show(successMsg, 
                                       (string)Application.Current.FindResource("OrderCompleted"), 
                                       MessageBoxButton.OK, 
                                       MessageBoxImage.Information);
                        
                        // Обновляем список заказов
                        LoadOrdersData();
                    }
                    catch (Exception ex)
                    {
                        string errorMsg = string.Format((string)Application.Current.FindResource("ErrorUpdatingOrderStatus"), ex.Message);
                        MessageBox.Show(errorMsg, (string)Application.Current.FindResource("Error"), MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
        
        private void CancelOrder_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.CommandParameter is Order order)
            {
                // Проверяем, можно ли удалить заказ в текущем статусе
                // Учитываем как русские, так и английские названия статусов
                bool canDelete = order.Status == "Новый" || 
                                order.Status == "В обработке" || 
                                order.Status == "Готовится" ||
                                order.Status == "Pending" ||
                                order.Status == "Processing";
                
                bool alreadyCompleted = order.Status == "Выполнен" || 
                                      order.Status == "Completed" ||
                                      order.Status == "Отменен" ||
                                      order.Status == "Cancelled" ||
                                      order.Status == "Готов к выдаче" ||
                                      order.Status == "Ready";
                
                if (alreadyCompleted)
                {
                    MessageBox.Show(
                        (string)Application.Current.FindResource("CannotDeleteOrderMessage"), 
                        (string)Application.Current.FindResource("Information"), 
                        MessageBoxButton.OK, 
                        MessageBoxImage.Information);
                    return;
                }
                
                var converter = new WpfApp1.Converters.OrderIdToReadableConverter();
                string readableOrderId = converter.Convert(order.Id, typeof(string), "short", Thread.CurrentThread.CurrentUICulture) as string;
                string confirmMessage = string.Format((string)Application.Current.FindResource("ConfirmDeleteOrder"), readableOrderId);
                var result = MessageBox.Show(confirmMessage, (string)Application.Current.FindResource("Confirm"), MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        // Вместо удаления заказа меняем его статус на "Отменен" (всегда на русском для БД)
                        order.Status = "Отменен";
                        _orderService.UpdateOrder(order);
                        
                        // Показываем сообщение об успехе
                        string successMsg = string.Format((string)Application.Current.FindResource("OrderDeletedSuccess"), readableOrderId);
                        MessageBox.Show(successMsg, 
                                       (string)Application.Current.FindResource("OrderDeleted"), 
                                       MessageBoxButton.OK, 
                                       MessageBoxImage.Information);
                        
                        // Обновляем список заказов
                        LoadOrdersData();
                    }
                    catch (Exception ex)
                    {
                        string errorMsg = string.Format((string)Application.Current.FindResource("ErrorDeletingOrder"), ex.Message);
                        MessageBox.Show(errorMsg, (string)Application.Current.FindResource("Error"), MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
        
        // Обработчик нажатия кнопки обновления пользователей
        private void RefreshUsers_Click(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("AdminPanelView: Обновление данных о пользователях по запросу пользователя");
            _userService.Initialize();
            LoadUsersData(true);
        }
        
        // Обработчик блокировки пользователя
        private void BlockUser_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.CommandParameter is User user)
            {
                // Проверяем, что текущий пользователь - администратор
                if (!_userService.IsUserAdmin())
                {
                    MessageBox.Show("Только администраторы могут блокировать пользователей.", 
                        "Отказано в доступе", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                
                // Проверяем, что пользователь не пытается заблокировать сам себя
                if (user.Id == _userService.CurrentUser?.Id)
                {
                    MessageBox.Show("Вы не можете заблокировать свою учетную запись.", 
                        "Операция запрещена", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                
                // Подтверждение действия
                var result = MessageBox.Show($"Вы действительно хотите заблокировать пользователя {user.Username}?", 
                    "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);
                
                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        bool success = _userService.BlockUser(user.Id);
                        if (success)
                        {
                            MessageBox.Show($"Пользователь {user.Username} успешно заблокирован.", 
                                "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                            LoadUsersData(); // Обновляем список пользователей
                        }
                        else
                        {
                            MessageBox.Show($"Не удалось заблокировать пользователя {user.Username}.", 
                                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при блокировке пользователя: {ex.Message}", 
                            "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
        
        // Обработчик разблокировки пользователя
        private void UnblockUser_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.CommandParameter is User user)
            {
                // Проверяем, что текущий пользователь - администратор
                if (!_userService.IsUserAdmin())
                {
                    MessageBox.Show("Только администраторы могут разблокировать пользователей.", 
                        "Отказано в доступе", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                
                // Подтверждение действия
                var result = MessageBox.Show($"Вы действительно хотите разблокировать пользователя {user.Username}?", 
                    "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);
                
                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        bool success = _userService.UnblockUser(user.Id);
                        if (success)
                        {
                            MessageBox.Show($"Пользователь {user.Username} успешно разблокирован.", 
                                "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                            LoadUsersData(); // Обновляем список пользователей
                        }
                        else
                        {
                            MessageBox.Show($"Не удалось разблокировать пользователя {user.Username}.", 
                                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при разблокировке пользователя: {ex.Message}", 
                            "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
        
        private void PromoteToAdmin_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.CommandParameter is User user)
            {
                try
                {
                    var confirmMessage = string.Format(
                        (string)Application.Current.FindResource("ConfirmPromote"),
                        user.Username);
                        
                    var result = MessageBox.Show(
                        confirmMessage,
                        (string)Application.Current.FindResource("Confirm"),
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Question);
                        
                    if (result == MessageBoxResult.Yes)
                    {
                        bool success = _userService.PromoteToAdmin(user.Id);
                        if (success)
                        {
                            var successMessage = string.Format(
                                (string)Application.Current.FindResource("AdminPromoted"),
                                user.Username);
                            MessageBox.Show(
                                successMessage,
                                (string)Application.Current.FindResource("Success"),
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
                                
                            RefreshUsers();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Ошибка при назначении администратора: {ex.Message}");
                    MessageBox.Show(
                        $"Ошибка: {ex.Message}",
                        (string)Application.Current.FindResource("Error"),
                        MessageBoxButton.OK,
                        MessageBoxImage.Error);
                }
            }
        }

        private void DemoteFromAdmin_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.CommandParameter is User user)
            {
                try
                {
                    // Проверяем, не пытается ли админ разжаловать сам себя
                    if (_userService.CurrentUser != null && _userService.CurrentUser.Id == user.Id)
                    {
                        MessageBox.Show(
                            (string)Application.Current.FindResource("CannotDemoteSelf"),
                            (string)Application.Current.FindResource("Information"),
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);
                        return;
                    }
                    
                    var confirmMessage = string.Format(
                        (string)Application.Current.FindResource("ConfirmDemote"),
                        user.Username);
                        
                    var result = MessageBox.Show(
                        confirmMessage,
                        (string)Application.Current.FindResource("Confirm"),
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Question);
                        
                    if (result == MessageBoxResult.Yes)
                    {
                        // Проверка на главного администратора (ID = 1)
                        if (user.Id == 1)
                        {
                            MessageBox.Show(
                                (string)Application.Current.FindResource("CannotDemoteMainAdmin"),
                                (string)Application.Current.FindResource("Information"),
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
                            return;
                        }
                        
                        bool success = _userService.DemoteFromAdmin(user.Id);
                        if (success)
                        {
                            var successMessage = string.Format(
                                (string)Application.Current.FindResource("AdminDemoted"),
                                user.Username);
                            MessageBox.Show(
                                successMessage,
                                (string)Application.Current.FindResource("Success"),
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
                                
                            RefreshUsers();
                        }
                        else
                        {
                            // Проверяем, не пытаемся ли мы разжаловать последнего администратора
                            var admins = _userService.GetAllUsers().Where(u => u.IsAdmin).ToList();
                            if (admins.Count <= 1)
                            {
                                MessageBox.Show(
                                    (string)Application.Current.FindResource("CannotDemoteLastAdmin"),
                                    (string)Application.Current.FindResource("Information"),
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Information);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Ошибка при разжаловании администратора: {ex.Message}");
                    MessageBox.Show(
                        $"Ошибка: {ex.Message}",
                        (string)Application.Current.FindResource("Error"),
                        MessageBoxButton.OK,
                        MessageBoxImage.Error);
                }
            }
        }

        private void RefreshUsers()
        {
            Debug.WriteLine("AdminPanelView: Обновление данных о пользователях");
            _userService.RefreshUsers();
            LoadUsersData(true);
        }
    }
}