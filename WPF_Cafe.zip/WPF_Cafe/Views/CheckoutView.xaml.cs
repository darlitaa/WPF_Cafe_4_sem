using System;
using System.Windows;
using WpfApp1.Services;
using WpfApp1.ViewModels;

namespace WpfApp1.Views
{

    public partial class CheckoutView : Window
    {
        private readonly CheckoutViewModel _viewModel;
        private readonly CartService _cartService;
        private readonly UserService _userService;
        private readonly OrderService _orderService;
        private readonly ProductService _productService;
        private readonly LocalizationService _localizationService;

        public CheckoutView(CartService cartService, UserService userService, OrderService orderService, ProductService productService)
        {
            InitializeComponent();
            
            _cartService = cartService;
            _userService = userService;
            _orderService = orderService;
            _productService = productService;
            _localizationService = App.LocalizationService;
            
            _viewModel = new CheckoutViewModel(cartService, userService, orderService, productService, _localizationService);
            DataContext = _viewModel;

            _viewModel.OrderPlaced += ViewModel_OrderPlaced;
            _viewModel.OrderCancelled += ViewModel_OrderCancelled;
            _viewModel.LanguageChanged += ViewModel_LanguageChanged;

            if (_localizationService != null)
            {
                _localizationService.LanguageChanged += LocalizationService_LanguageChanged;
            }
        }
        
        private void ViewModel_LanguageChanged(object sender, EventArgs e)
        {
            UpdateTitle();
        }
        
        private void LocalizationService_LanguageChanged(object sender, EventArgs e)
        {
            UpdateTitle();
        }
        
        private void UpdateTitle()
        {
            try
            {
                Title = (string)Application.Current.FindResource("CheckoutTitle");
            }
            catch
            {
                Title = "Оформление заказа";
            }
        }

        private void ViewModel_OrderPlaced(object sender, EventArgs e)
        {
            string successTitle, successMessage;
            
            try
            {
                successTitle = (string)Application.Current.FindResource("Success");
                successMessage = (string)Application.Current.FindResource("OrderSuccess");
            }
            catch
            {
                successTitle = "Заказ оформлен";
                successMessage = "Ваш заказ успешно оформлен! Детали заказа отправлены на вашу электронную почту.";
            }
            
            MessageBox.Show(
                successMessage,
                successTitle,
                MessageBoxButton.OK,
                MessageBoxImage.Information
            );

            Close();
        }

        private void ViewModel_OrderCancelled(object sender, EventArgs e)
        {
            Close();
        }
    }
} 