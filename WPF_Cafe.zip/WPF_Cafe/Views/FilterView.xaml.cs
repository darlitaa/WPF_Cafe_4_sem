using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using WpfApp1.Models;
using WpfApp1.Services;
using WpfApp1.ViewModels;
using System.Linq;

namespace WpfApp1.Views
{
    public partial class FilterView : Window
    {
        private FilterViewModel _viewModel;
        private readonly LocalizationService _localizationService;
        private ObservableCollection<Product> _originalProducts;

        public event EventHandler<FilterEventArgs> FiltersApplied;
        
        public FilterView(ObservableCollection<Product> products)
            : this(products, null)
        {
        }
        
        public FilterView(ObservableCollection<Product> products, FilterEventArgs filterSettings)
        {
            InitializeComponent();
            
            _originalProducts = products;

            _localizationService = (LocalizationService)Application.Current.Resources["LocalizationService"];
            
            _viewModel = new FilterViewModel(products);

            if (filterSettings != null)
            {
                _viewModel.SelectedMinPrice = filterSettings.MinPrice;
                _viewModel.SelectedMaxPrice = filterSettings.MaxPrice;
                _viewModel.ShowOnlyDiscounted = filterSettings.ShowOnlyDiscounted;
                _viewModel.ShowOnlyInStock = filterSettings.ShowOnlyInStock;
                
                string allManufacturersText = (string)Application.Current.FindResource("AllManufacturers");
                
                // Проверяем, что выбранный производитель существует в списке, если нет - добавляем его
                string selectedManufacturer = string.IsNullOrEmpty(filterSettings.Manufacturer) 
                    ? allManufacturersText 
                    : filterSettings.Manufacturer;
                
                if (!string.IsNullOrEmpty(selectedManufacturer) && 
                    selectedManufacturer != allManufacturersText && 
                    !_viewModel.Manufacturers.Contains(selectedManufacturer))
                {
                    _viewModel.Manufacturers.Add(selectedManufacturer);
                }
                
                _viewModel.SelectedManufacturer = selectedManufacturer;
            }
            
            DataContext = _viewModel;

            _viewModel.ApplyFiltersCommand = new RelayCommand(_ =>
            {
                ApplyFilters();
                DialogResult = true;
                Close();
            });
            
            _viewModel.ResetFiltersCommand = new RelayCommand(_ =>
            {
                _viewModel.ResetFilters(null);
                
                FocusManager.SetFocusedElement(this, null);
                Keyboard.ClearFocus();
                
                decimal maxPrice = _originalProducts != null && _originalProducts.Any() 
                    ? _originalProducts.Max(p => p.DiscountedPrice) 
                    : 1000;

                var resetFilterArgs = new FilterEventArgs
                {
                    MinPrice = 0,
                    MaxPrice = maxPrice,
                    ShowOnlyDiscounted = false,
                    ShowOnlyInStock = false,
                    Manufacturer = null
                };

                FiltersApplied?.Invoke(this, resetFilterArgs);

                DialogResult = true;
                Close();
            });
            
            _viewModel.CancelCommand = new RelayCommand(_ =>
            {
                DialogResult = false;
                Close();
            });
            
            Closing += FilterView_Closing;

            if (_localizationService != null)
            {
                _localizationService.LanguageChanged += LocalizationService_LanguageChanged;
            }
        }
        
        private void LocalizationService_LanguageChanged(object sender, EventArgs e)
        {
            Title = (string)Application.Current.FindResource("FilterTitle");
        }
        
        private void FilterView_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (DialogResult != true)
            {
                FocusManager.SetFocusedElement(this, null);
            }

            if (_localizationService != null)
            {
                _localizationService.LanguageChanged -= LocalizationService_LanguageChanged;
            }
        }
        
        private void ApplyFilters()
        {
            string allManufacturersText = (string)Application.Current.FindResource("AllManufacturers");
            bool showOnlyDiscounted = _viewModel.ShowOnlyDiscounted;
            bool showOnlyInStock = _viewModel.ShowOnlyInStock;
            
            var filterArgs = new FilterEventArgs
            {
                MinPrice = _viewModel.SelectedMinPrice,
                MaxPrice = _viewModel.SelectedMaxPrice,
                ShowOnlyDiscounted = showOnlyDiscounted,
                ShowOnlyInStock = showOnlyInStock,
                Manufacturer = _viewModel.SelectedManufacturer == allManufacturersText ? null : _viewModel.SelectedManufacturer
            };

            FiltersApplied?.Invoke(this, filterArgs);
        }
    }
} 