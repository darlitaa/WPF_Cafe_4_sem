using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using WpfApp1.Services;
using WpfApp1.ViewModels;
using System.Threading;
using System.Linq;
using System.Collections.Generic;

namespace WpfApp1.Views
{
    public partial class LoginView : Window
    {
        private readonly LoginViewModel _viewModel;
        private readonly RegisterViewModel _registerViewModel;
        
        // Добавляем публичное свойство для доступа из XAML
        public RegisterViewModel RegisterViewModel => _registerViewModel;
        
        private readonly UserService _userService;
		private readonly LocalizationService _localizationService;
		private const double CompactModeThreshold = 700;

        public LoginView(UserService userService)
        {
            InitializeComponent();
            
            _userService = userService;
            _localizationService = App.LocalizationService;
            
            // Инициализация ViewModel авторизации
            _viewModel = new LoginViewModel(userService);
            
            // Инициализация ViewModel регистрации
            _registerViewModel = new RegisterViewModel(userService);
            
            // Настраиваем контекст данных
            DataContext = _viewModel;
            
            // Привязываем обработчики событий
            _viewModel.LoginSuccessful += ViewModel_LoginSuccessful;
            _registerViewModel.RegistrationSuccessful += RegisterViewModel_RegistrationSuccessful;
            
            PasswordBox.PasswordChanged += PasswordBox_PasswordChanged;
            CompactPasswordBox.PasswordChanged += PasswordBox_PasswordChanged;
            
            // Добавляем обработчики для полей пароля при регистрации
            PasswordBoxRegister.PasswordChanged += PasswordBoxRegister_PasswordChanged;
            ConfirmPasswordBoxRegister.PasswordChanged += ConfirmPasswordBoxRegister_PasswordChanged;
            CompactPasswordBoxRegister.PasswordChanged += PasswordBoxRegister_PasswordChanged;
            CompactConfirmPasswordBoxRegister.PasswordChanged += ConfirmPasswordBoxRegister_PasswordChanged;

            // Добавляем обработчики потери фокуса для полей регистрации
            InitializeFieldValidationEvents();

            UpdateLayoutMode();

            SetLanguageComboBoxSelections();

            Loaded += LoginView_Loaded;
        }

        // Устаревший конструктор для обратной совместимости
        public LoginView(UserService userService, LocalizationService localizationService) : this(userService)
        {
            // Все настройки выполняются в основном конструкторе
        }

        private void LoginView_Loaded(object sender, RoutedEventArgs e)
        {
            
            // Устанавливаем вкладку авторизации активной при загрузке окна
            TabControlAuth.SelectedIndex = 0;
            
            // Также устанавливаем для компактного режима
            if (CompactTabControlAuth != null)
            {
                CompactTabControlAuth.SelectedIndex = 0;
            }
        }

        private void SetLanguageComboBoxSelections()
        {
            var currentCulture = Thread.CurrentThread.CurrentUICulture.Name;
            if (currentCulture == "ru-RU")
            {
                cmbLanguage.SelectedIndex = 0;
                cmbLanguageCompact.SelectedIndex = 0;
            }
            else
            {
                cmbLanguage.SelectedIndex = 1;
                cmbLanguageCompact.SelectedIndex = 1;
            }
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            _viewModel.Password = ((PasswordBox)sender).Password;
        }
        
        private void PasswordBoxRegister_PasswordChanged(object sender, RoutedEventArgs e)
        {
            _registerViewModel.Password = ((PasswordBox)sender).Password;
        }
        
        private void ConfirmPasswordBoxRegister_PasswordChanged(object sender, RoutedEventArgs e)
        {
            _registerViewModel.ConfirmPassword = ((PasswordBox)sender).Password;
        }

        private void ViewModel_LoginSuccessful(object sender, EventArgs e)
        {

            var mainView = new MainView();
            Application.Current.MainWindow = mainView;
            
            mainView.Show();
            Close();
        }
        
        private void RegisterViewModel_RegistrationSuccessful(object sender, EventArgs e)
        {
            // Проверяем, нужно ли автоматически перенаправить пользователя на главную страницу
            if (e is RegisterViewModel.RegistrationEventArgs args && args.AutoLogin)
            {
                MessageBox.Show(
                        (string)Application.Current.FindResource("RegistrationSuccessful"),
                        (string)Application.Current.FindResource("Success"),
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                    
                    // Переходим на главную страницу
                    var mainView = new MainView();
                    Application.Current.MainWindow = mainView;
                    
                    mainView.Show();
                    Close();
            }
            else
            {
                // Если автоматический вход не требуется, просто переключаемся на вкладку входа
                TabControlAuth.SelectedIndex = 0;
                
                // Показываем сообщение об успешной регистрации
                MessageBox.Show(
                    (string)Application.Current.FindResource("RegistrationSuccessful"),
                    (string)Application.Current.FindResource("Success"),
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
        }
        
        private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            UpdateLayoutMode();
        }

        private void UpdateLayoutMode()
        {
            if (ActualWidth < CompactModeThreshold)
            {
                NormalLayout.Visibility = Visibility.Collapsed;
                CompactLayout.Visibility = Visibility.Visible;
            }
            else
            {
                NormalLayout.Visibility = Visibility.Visible;
                CompactLayout.Visibility = Visibility.Collapsed;
            }
        }
        
        private void LanguageComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!IsLoaded || !(sender is ComboBox))
                return;
                
            ComboBox comboBox = (ComboBox)sender;

            if (comboBox == cmbLanguage && cmbLanguageCompact.SelectedIndex != comboBox.SelectedIndex)
                cmbLanguageCompact.SelectedIndex = comboBox.SelectedIndex;
            else if (comboBox == cmbLanguageCompact && cmbLanguage.SelectedIndex != comboBox.SelectedIndex)
                cmbLanguage.SelectedIndex = comboBox.SelectedIndex;

            if (_localizationService != null)
            {
                if (comboBox.SelectedIndex == 0)
                    _localizationService.CurrentCulture = new CultureInfo("ru-RU");
                else if (comboBox.SelectedIndex == 1)
                    _localizationService.CurrentCulture = new CultureInfo("en-US");
                
                // Обновляем заголовок окна после смены языка
                _viewModel.Title = $"{(string)Application.Current.FindResource("Login")} - {(string)Application.Current.FindResource("AppName")}";
            }
        }
        
        private void TabControlAuth_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sender is TabControl tabControl)
            {
                // Обновляем контекст данных для выбранной вкладки
                if (tabControl.SelectedIndex == 0) // Вкладка входа
                {
                    if (tabControl == TabControlAuth)
                    {
                        RegisterTab.DataContext = null;
                        LoginTab.DataContext = _viewModel;
                    }
                    else
                    {
                        // Устанавливаем контекст данных для вкладок в компактном режиме
                        var compactLoginTabItem = CompactTabControlAuth.Items[0] as TabItem;
                        var compactRegisterTabItem = CompactTabControlAuth.Items[1] as TabItem;
                        
                        if (compactRegisterTabItem != null)
                            compactRegisterTabItem.DataContext = null;
                        
                        if (compactLoginTabItem != null)
                            compactLoginTabItem.DataContext = _viewModel;
                    }
                    
                    // Обновляем заголовок окна
                    _viewModel.Title = $"{(string)Application.Current.FindResource("Login")} - {(string)Application.Current.FindResource("AppName")}";
                }
                else // Вкладка регистрации
                {
                    if (tabControl == TabControlAuth)
                    {
                        LoginTab.DataContext = null;
                        RegisterTab.DataContext = _registerViewModel;
                    }
                    else
                    {
                        // Устанавливаем контекст данных для вкладок в компактном режиме
                        var compactLoginTabItem = CompactTabControlAuth.Items[0] as TabItem;
                        var compactRegisterTabItem = CompactTabControlAuth.Items[1] as TabItem;
                        
                        if (compactLoginTabItem != null)
                            compactLoginTabItem.DataContext = null;
                        
                        if (compactRegisterTabItem != null)
                            compactRegisterTabItem.DataContext = _registerViewModel;
                    }
                    
                    // Обновляем заголовок окна
                    _viewModel.Title = $"{(string)Application.Current.FindResource("Register")} - {(string)Application.Current.FindResource("AppName")}";
                }
            }
        }

        private void UpdateWindowTitle()
        {
            if (_localizationService != null)
            {
                string titleText = (string)Application.Current.FindResource("Login");
                string appName = (string)Application.Current.FindResource("AppName");
                
                if (TabControlAuth.SelectedIndex == 1)
                {
                    titleText = (string)Application.Current.FindResource("Register");
                }
                
                _viewModel.Title = $"{titleText} - {appName}";
            }
        }

        private System.Windows.Controls.PasswordBox GetConfirmPasswordBox(System.Windows.Controls.PasswordBox passwordBox)
        {
            if (passwordBox == PasswordBoxRegister)
                return ConfirmPasswordBoxRegister;
            else if (passwordBox == CompactPasswordBoxRegister)
                return CompactConfirmPasswordBoxRegister;
            
            return null;
        }

        private void InitializeFieldValidationEvents()
        {
            // Поля на вкладке регистрации
            if (RegisterTab != null)
            {
                // Ищем элементы TextBox внутри RegisterTab
                var registerFields = FindVisualChildren<TextBox>(RegisterTab);
                foreach (var field in registerFields)
                {
                    field.LostFocus += RegisterField_LostFocus;
                }
                
                // Отдельно для полей пароля
                PasswordBoxRegister.LostFocus += RegisterPasswordBox_LostFocus;
                ConfirmPasswordBoxRegister.LostFocus += RegisterConfirmPasswordBox_LostFocus;
            }
            
            // Поля в компактном режиме
            if (CompactTabControlAuth != null)
            {
                var tabItem = CompactTabControlAuth.Items.OfType<TabItem>().FirstOrDefault(t => t.Header.ToString() == (string)Application.Current.FindResource("Register"));
                if (tabItem != null)
                {
                    var registerFields = FindVisualChildren<TextBox>(tabItem);
                    foreach (var field in registerFields)
                    {
                        field.LostFocus += RegisterField_LostFocus;
                    }
                    
                    // Ищем поля пароля в компактном режиме
                    CompactPasswordBoxRegister.LostFocus += RegisterPasswordBox_LostFocus;
                    CompactConfirmPasswordBoxRegister.LostFocus += RegisterConfirmPasswordBox_LostFocus;
                }
            }
        }
        
        private void RegisterField_LostFocus(object sender, RoutedEventArgs e)
        {
            var textBox = sender as TextBox;
            if (textBox == null || _registerViewModel == null) return;
            
            // Определяем поле по имени и вызываем соответствующий метод валидации
            string fieldName = textBox.Name;
            
            if (fieldName.Contains("Username") || textBox.Text == _registerViewModel.Username)
            {
                // Явно валидируем поле при потере фокуса
                _registerViewModel.ValidateField("Username");
            }
            else if (fieldName.Contains("Email") || textBox.Text == _registerViewModel.Email)
            {
                _registerViewModel.ValidateField("Email");
            }
            else if (fieldName.Contains("Phone") || textBox.Text == _registerViewModel.Phone)
            {
                _registerViewModel.ValidateField("Phone");
            }
            else if (fieldName.Contains("FullName") || textBox.Text == _registerViewModel.FullName)
            {
                // FullName не требует валидации
            }
            else if (fieldName.Contains("Address") || textBox.Text == _registerViewModel.Address)
            {
                // Address не требует валидации
            }
        }
        
        private void RegisterPasswordBox_LostFocus(object sender, RoutedEventArgs e)
        {
            var passwordBox = sender as PasswordBox;
            if (passwordBox == null || _registerViewModel == null) return;
            
            // Передаем значение пароля в ViewModel и вызываем валидацию
            _registerViewModel.Password = passwordBox.Password;
            _registerViewModel.ValidateField("Password");
        }
        
        private void RegisterConfirmPasswordBox_LostFocus(object sender, RoutedEventArgs e)
        {
            var passwordBox = sender as PasswordBox;
            if (passwordBox == null || _registerViewModel == null) return;
            
            // Передаем значение подтверждения пароля в ViewModel и вызываем валидацию
            _registerViewModel.ConfirmPassword = passwordBox.Password;
            _registerViewModel.ValidateField("ConfirmPassword");
        }
        
        // Вспомогательный метод для поиска элементов в визуальном дереве
        private IEnumerable<T> FindVisualChildren<T>(DependencyObject depObj) where T : DependencyObject
        {
            if (depObj == null) yield break;
            
            for (int i = 0; i < System.Windows.Media.VisualTreeHelper.GetChildrenCount(depObj); i++)
            {
                var child = System.Windows.Media.VisualTreeHelper.GetChild(depObj, i);
                
                if (child is T t)
                    yield return t;
                
                foreach (var childOfChild in FindVisualChildren<T>(child))
                    yield return childOfChild;
            }
        }
    }
} 