using System;
using System.Windows;
using System.Windows.Controls;
using WpfApp1.Models;
using WpfApp1.Services;
using WpfApp1.ViewModels;
using System.Linq;
using System.Globalization;
using System.Windows.Input;
using System.Windows.Threading;
namespace WpfApp1.Views
{
    public partial class MainView : Window
    {
        private MainViewModel _viewModel;
        private readonly ProductService _productService;
        private readonly UserService _userService;
        private readonly CartService _cartService;
        private readonly OrderService _orderService;
        private readonly LocalizationService _localizationService;
        private readonly ReviewService _reviewService;
        private ReviewsControl reviewsControl;
        private ReviewViewModel _reviewViewModel;
        private PersonalAccountView personalAccountView;
        public MainView()
        {
            InitializeComponent();
            var jsonDataService = new JsonDataService();
            _productService = new ProductService(jsonDataService);
            _userService = App.UserService;
            _cartService = new CartService(_productService);
            _orderService = new OrderService(jsonDataService, _cartService);
            _localizationService = App.LocalizationService;
            _reviewService = new ReviewService();
            Closed += MainView_Closed;
            LoadData();
        }
        
        private void LocalizationService_LanguageChanged(object sender, EventArgs e)
        {
            if (_viewModel != null)
            {
                _viewModel.Title = $"{(string)Application.Current.FindResource("AppName")} - {(string)Application.Current.FindResource("MainTitle")}";
                _viewModel.RefreshUIAfterLanguageChange();
                FocusManager.SetFocusedElement(this, null);
            }
        }
        private void LoadData()
        {
            _productService.Initialize();
            _orderService.Initialize();
            _viewModel = new MainViewModel(_productService, _userService, _cartService, _localizationService);
            _viewModel.Title = $"{(string)Application.Current.FindResource("AppName")} - {(string)Application.Current.FindResource("MainTitle")}";
            DataContext = _viewModel;
            _viewModel.LogoutRequested += ViewModel_LogoutRequested;
            _viewModel.EditProductRequested += ViewModel_EditProductRequested;
            _viewModel.AddProductRequested += ViewModel_AddProductRequested;
            _viewModel.CartRequested += ViewModel_CartRequested;
            _viewModel.ViewProductDetailsRequested += ViewModel_ViewProductDetailsRequested;
            _viewModel.AdminPanelRequested += ViewModel_AdminPanelRequested;
            _viewModel.CheckoutRequested += ViewModel_CheckoutRequested;
            _viewModel.ShowFilterViewRequested += ViewModel_ShowFilterViewRequested;
            _viewModel.ShowProfileRequested += ViewModel_ShowProfileRequested;
            _viewModel.ShowHomeCommandRequested += ViewModel_ShowHomeCommand;
            _viewModel.ShowReviewsRequested += ViewModel_ShowReviewsRequested;
            _productService.ProductsUpdated += ProductService_ProductsUpdated;
            _viewModel.PropertyChanged += (s, e) => {
                if (e.PropertyName == nameof(MainViewModel.IsCartVisible))
                {
                    if (_viewModel.IsCartVisible)
                    {
                        ShowCart();
                    }
                    else
                    {
                        HideCart();
                    }
                }
            };
            if (_cartService.ItemCount > 0)
            {
                _viewModel.IsCartVisible = true;
                ShowCart();
            }
        }
        private void ViewModel_LogoutRequested(object sender, EventArgs e)
        {
            var loginView = new LoginView(_userService, _localizationService);
            loginView.Show();
            Close();
        }
        private void ViewModel_EditProductRequested(object sender, Product product)
        {
            var productView = new ProductView(_productService, product, _localizationService);
            bool? result = productView.ShowDialog();
            if (result == true)
            {
                RefreshData();
            }
            else
            {
                FocusManager.SetFocusedElement(this, null);
            }
        }
        private void ViewModel_AddProductRequested(object sender, EventArgs e)
        {
            var productView = new ProductView(_productService, null, _localizationService);
     
            bool? result = productView.ShowDialog();
            if (result == true)
            {
                RefreshData();
            }
            else
            {
                FocusManager.SetFocusedElement(this, null);
            }
        }
        private void ViewModel_CartRequested(object sender, EventArgs e)
        {
            if (_viewModel != null && _cartService.ItemCount > 0)
            {
                _viewModel.IsCartVisible = true;
            }
        }
        private void ViewModel_AdminPanelRequested(object sender, EventArgs e)
        {
            var adminPanelView = new AdminPanelView(_productService, _userService, _orderService);
            adminPanelView.Owner = this;
            bool? result = adminPanelView.ShowDialog();
            if (result == true)
            {
                RefreshData();
            }
            else
            {
                FocusManager.SetFocusedElement(this, null);
            }
        }
        private void ViewModel_CheckoutRequested(object sender, EventArgs e)
        {
            var checkoutView = new CheckoutView(_cartService, _userService, _orderService, _productService);
            bool? result = checkoutView.ShowDialog();
            if (result == true)
            {
                RefreshData();
            }
            else
            {
                FocusManager.SetFocusedElement(this, null);
            }
        }
        private void ViewModel_ShowFilterViewRequested(object sender, EventArgs e)
        {
            // Получаем полный список всех товаров (независимо от категории)
            var allProducts = _productService.GetAllProducts();
            
            // Используем полный список всех товаров для FilterView
            var filterView = new FilterView(new System.Collections.ObjectModel.ObservableCollection<Product>(allProducts), _viewModel.GetCurrentFilterSettings());
            
            filterView.Owner = this;
            filterView.FiltersApplied += FilterView_FiltersApplied;
            bool? result = filterView.ShowDialog();
        }
        private void FilterView_FiltersApplied(object sender, FilterEventArgs e)
        {
            _viewModel.ApplyFilters(e);
            FocusManager.SetFocusedElement(this, null);
        }
        private void ViewModel_ShowProfileRequested(object sender, EventArgs e)
        {
            // Скрываем основную сетку с товарами
            productsGrid.Visibility = Visibility.Collapsed;
            
            // Отображаем область contentArea
            contentArea.Visibility = Visibility.Visible;
            
            // Очищаем contentArea и создаем новый экземпляр PersonalAccountView
            contentArea.Children.Clear();
            
            // Если personalAccountView равен null или мы хотим его заново инициализировать
            if (personalAccountView == null)
            {
                personalAccountView = new PersonalAccountView();
            }
            
            contentArea.Children.Add(personalAccountView);
        }
        private void ViewModel_ShowHomeCommand(object sender, EventArgs e)
        {
            contentArea.Visibility = Visibility.Collapsed;
            productsGrid.Visibility = Visibility.Visible;
        }
        private void ViewModel_ShowReviewsRequested(object sender, EventArgs e)
        {
            // Скрываем основную сетку с товарами
            productsGrid.Visibility = Visibility.Collapsed;
            
            // Отображаем область contentArea
            contentArea.Visibility = Visibility.Visible;
            
            // Очищаем contentArea, создаем новый экземпляр ReviewsControl и добавляем его
            contentArea.Children.Clear();
            
            // Если reviewsControl равен null или мы хотим его заново инициализировать
            if (reviewsControl == null)
            {
                // Создаем ReviewViewModel если он еще не создан
                if (_reviewViewModel == null)
                {
                    _reviewViewModel = new ReviewViewModel(_reviewService, _userService);
                }
                
                reviewsControl = new ReviewsControl();
                reviewsControl.DataContext = _reviewViewModel;
            }
            
            contentArea.Children.Add(reviewsControl);
            reviewsControl.Visibility = Visibility.Visible;
        }
        private void RefreshData()
        {
            _productService.Initialize();
            string selectedCategoryName = _viewModel.SelectedCategory?.Name;
            _viewModel = new MainViewModel(_productService, _userService, _cartService, _localizationService);
            DataContext = _viewModel;
            _viewModel.LogoutRequested += ViewModel_LogoutRequested;
            _viewModel.EditProductRequested += ViewModel_EditProductRequested;
            _viewModel.AddProductRequested += ViewModel_AddProductRequested;
            _viewModel.CartRequested += ViewModel_CartRequested;
            _viewModel.ViewProductDetailsRequested += ViewModel_ViewProductDetailsRequested;
            _viewModel.AdminPanelRequested += ViewModel_AdminPanelRequested;
            _viewModel.CheckoutRequested += ViewModel_CheckoutRequested;
            _viewModel.ShowFilterViewRequested += ViewModel_ShowFilterViewRequested;
            _viewModel.ShowProfileRequested += ViewModel_ShowProfileRequested;
            _viewModel.ShowHomeCommandRequested += ViewModel_ShowHomeCommand;
            _viewModel.ShowReviewsRequested += ViewModel_ShowReviewsRequested;
            _viewModel.PropertyChanged += (s, e) => {
                if (e.PropertyName == nameof(MainViewModel.IsCartVisible))
                {
                    if (_viewModel.IsCartVisible)
                    {
                        ShowCart();
                    }
                    else
                    {
                        HideCart();
                    }
                }
            };
            if (!string.IsNullOrEmpty(selectedCategoryName))
            {
                var category = _viewModel.Categories.FirstOrDefault(c => c.Name == selectedCategoryName);
                if (category != null)
                {
                    _viewModel.SelectCategoryCommand.Execute(category);
                }
            }
            if (_cartService.ItemCount > 0)
            {
                _viewModel.IsCartVisible = true;
                ShowCart();
            }
        }
        public void ShowCart()
        {
            CartColumnDefinition.Width = new GridLength(350);
            UpdateLayout();
        }
        public void HideCart()
        {
            CartColumnDefinition.Width = new GridLength(0);
            UpdateLayout();
        }
        private void ViewModel_ViewProductDetailsRequested(object sender, Product product)
        {
            var productDetailsView = new ProductDetailsView(product, _cartService, _localizationService);
            productDetailsView.Owner = this;
            productDetailsView.ShowDialog();
            if (_cartService.ItemCount > 0)
            {
                _viewModel.IsCartVisible = true;
            }
        }
        private void ProductService_ProductsUpdated(object sender, EventArgs e)
        {
            Dispatcher.Invoke(() => {
                RefreshData();
            });
        }
        private void MainView_Closed(object sender, EventArgs e)
        {
            if (_productService != null)
                _productService.ProductsUpdated -= ProductService_ProductsUpdated;
            if (_localizationService != null)
                _localizationService.LanguageChanged -= LocalizationService_LanguageChanged;
            if (_viewModel != null)
            {
                _viewModel.LogoutRequested -= ViewModel_LogoutRequested;
                _viewModel.EditProductRequested -= ViewModel_EditProductRequested;
                _viewModel.AddProductRequested -= ViewModel_AddProductRequested;
                _viewModel.CartRequested -= ViewModel_CartRequested;
                _viewModel.ViewProductDetailsRequested -= ViewModel_ViewProductDetailsRequested;
                _viewModel.AdminPanelRequested -= ViewModel_AdminPanelRequested;
                _viewModel.CheckoutRequested -= ViewModel_CheckoutRequested;
                _viewModel.ShowFilterViewRequested -= ViewModel_ShowFilterViewRequested;
                _viewModel.ShowProfileRequested -= ViewModel_ShowProfileRequested;
                _viewModel.ShowHomeCommandRequested -= ViewModel_ShowHomeCommand;
                _viewModel.ShowReviewsRequested -= ViewModel_ShowReviewsRequested;
            }
        }
    }
}