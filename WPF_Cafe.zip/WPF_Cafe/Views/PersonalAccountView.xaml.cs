﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using WpfApp1.Services;
using WpfApp1.ViewModels;

namespace WpfApp1.Views
{
	/// <summary>
	/// Логика взаимодействия для PersonalAccountView.xaml
	/// </summary>
	public partial class PersonalAccountView : UserControl
	{
		private PersonalAccountViewModel _viewModel;

		public PersonalAccountView()
		{
			InitializeComponent();
			
			// Получаем экземпляры сервисов через App
			var userService = App.UserService;
			var localizationService = App.LocalizationService;
			var orderService = App.OrderService;
			
			// Создаем и устанавливаем ViewModel
			_viewModel = new PersonalAccountViewModel(userService, localizationService, orderService);

			// Явно инициализируем коллекцию языков, если она не была инициализирована
			if (_viewModel.AvailableLanguages == null || _viewModel.AvailableLanguages.Count == 0)
			{
				_viewModel.AvailableLanguages = new ObservableCollection<CultureInfo>(
					new[] { new CultureInfo("ru-RU"), new CultureInfo("en-US") }
				);
				
				// Устанавливаем текущий язык
				if (localizationService != null && localizationService.CurrentCulture != null)
				{
					_viewModel.SelectedLanguage = localizationService.CurrentCulture;
				}
				else
				{
					_viewModel.SelectedLanguage = new CultureInfo("ru-RU");
				}
			}
			
			DataContext = _viewModel;
			
			// Подписываемся на события, если будет необходимость очистить PasswordBox при изменении состояния
			_viewModel.PropertyChanged += (sender, e) =>
			{
				if (e.PropertyName == nameof(PersonalAccountViewModel.IsChangingPassword) && !_viewModel.IsChangingPassword)
				{
					ClearPasswordBoxes();
				}
			};
		}
		
		private void CurrentPasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
		{
			if (_viewModel != null)
			{
				_viewModel.CurrentPassword = ((PasswordBox)sender).Password;
			}
		}
		
		private void NewPasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
		{
			if (_viewModel != null)
			{
				_viewModel.NewPassword = ((PasswordBox)sender).Password;
			}
		}
		
		private void ConfirmPasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
		{
			if (_viewModel != null)
			{
				_viewModel.ConfirmPassword = ((PasswordBox)sender).Password;
			}
		}
		
		private void ClearPasswordBoxes()
		{
			NewPasswordBox.Password = string.Empty;
			ConfirmPasswordBox.Password = string.Empty;
		}
		
		private void Theme_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (_viewModel != null && sender is ComboBox comboBox && comboBox.SelectedItem is ThemeManager.Theme selectedTheme)
			{
				// Сразу применяем выбранную тему
				ThemeManager.ApplyTheme(selectedTheme);
			}
		}
	}
}
