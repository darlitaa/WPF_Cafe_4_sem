using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Collections.Generic;
using WpfApp1.Models;
using WpfApp1.Services;
namespace WpfApp1.Views
{
    public partial class ProductDetailsView : Window
    {
        private Product _product;
        private readonly CartService _cartService;
        private readonly LocalizationService _localizationService;
        public ProductDetailsView(Product product, CartService cartService = null, LocalizationService localizationService = null)
        {
            InitializeComponent();
            _product = product;
            _cartService = cartService;
            _localizationService = localizationService ?? LocalizationService.Instance;
            if (_localizationService != null)
            {
                _localizationService.LanguageChanged += LocalizationService_LanguageChanged;
            }
            DataContext = _product;
            UpdateWindowTitle();
        }
        private void LocalizationService_LanguageChanged(object sender, EventArgs e)
        {
            UpdateWindowTitle();
        }
        private void UpdateWindowTitle()
        {
            try
            {
                Title = (string)Application.Current.FindResource("ProductDetailsTitle");
            }
            catch
            {
                Title = "Подробная информация о товаре";
            }
        }
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        private void ImageThumbnails_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count > 0 && e.AddedItems[0] is string imagePath)
            {
                MainImage.Source = new System.Windows.Media.Imaging.BitmapImage(
                    new System.Uri(imagePath, System.UriKind.RelativeOrAbsolute));
            }
        }
        private void AddToCartButton_Click(object sender, RoutedEventArgs e)
        {
            if (_cartService != null)
            {
                try
                {
                    _cartService.AddToCart(_product);
                    string messageFormat = TryFindResource("ProductAddedToCart") as string ?? "Товар \"{0}\" добавлен в корзину";
                    string title = TryFindResource("ProductAddedToCartTitle") as string ?? "Товар добавлен";
                    MessageBox.Show(string.Format(messageFormat, _product.ShortName), title, MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (InvalidOperationException ex)
                {
                    string title = TryFindResource("CannotAddToCartTitle") as string ?? "Невозможно добавить товар";
                    MessageBox.Show(ex.Message, title, MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                string title = TryFindResource("AddToCartErrorTitle") as string ?? "Ошибка";
                string message = TryFindResource("AddToCartErrorMessage") as string ?? "Невозможно добавить товар в корзину";
                MessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private object TryFindResource(string key)
        {
            try
            {
                return Application.Current.FindResource(key);
            }
            catch
            {
                return null;
            }
        }
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            if (_localizationService != null)
            {
                _localizationService.LanguageChanged -= LocalizationService_LanguageChanged;
            }
        }
    }
}