using System;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using WpfApp1.Models;
using WpfApp1.Services;
using WpfApp1.ViewModels;
using System.Threading;

namespace WpfApp1.Views
{
    public partial class ProductView : Window
    {
        private readonly ProductViewModel _viewModel;
        private readonly LocalizationService _localizationService;

        public ProductView(ProductService productService, Product product = null, LocalizationService localizationService = null)
        {
            InitializeComponent();
            
            _localizationService = localizationService;
            _viewModel = new ProductViewModel(productService, product);
            DataContext = _viewModel;
            
            _viewModel.SaveCompleted += ViewModel_SaveCompleted;
            _viewModel.CancelRequested += ViewModel_CancelRequested;
            
            if (FindTextBoxByBindingPath("Discount") is TextBox discountTextBox)
            {
                discountTextBox.PreviewTextInput += DiscountTextBox_PreviewTextInput;
            }

            if (FindTextBoxByBindingPath("Price") is TextBox priceTextBox)
            {
                priceTextBox.PreviewTextInput += PriceTextBox_PreviewTextInput;
            }

            if (FindTextBoxByBindingPath("Quantity") is TextBox quantityTextBox)
            {
                quantityTextBox.PreviewTextInput += QuantityTextBox_PreviewTextInput;
            }

            if (_localizationService != null)
            {
                _localizationService.LanguageChanged += LocalizationService_LanguageChanged;
                UpdateWindowTitle();
            }
        }

        private void ViewModel_SaveCompleted(object sender, EventArgs e)
        {
            Close();
        }

        private void ViewModel_CancelRequested(object sender, EventArgs e)
        {
            Close();
        }
        
        private void LocalizationService_LanguageChanged(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine($"Language changed. Current culture: {Thread.CurrentThread.CurrentCulture.Name}");
            System.Diagnostics.Debug.WriteLine($"Current UI culture: {Thread.CurrentThread.CurrentUICulture.Name}");

            try
            {
                string addProductValue = (string)Application.Current.FindResource("AddProduct");
                System.Diagnostics.Debug.WriteLine($"Found AddProduct: {addProductValue}");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error finding resource: {ex.Message}");
            }
            
            UpdateWindowTitle();
        }
        
        private void UpdateWindowTitle()
        {
            try
            {
                string titleKey = _viewModel.IsNewProduct ? "AddProduct" : "EditProduct";
                string localizedTitle = (string)Application.Current.FindResource(titleKey);
                Title = localizedTitle;

                HeaderTextBlock.Text = localizedTitle;
            }
            catch
            {
                Title = _viewModel.IsNewProduct ? "Добавление товара" : "Редактирование товара";
                HeaderTextBlock.Text = Title;
            }
        }

        private void DiscountTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void PriceTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Убрано ограничение на ввод символов
            e.Handled = false;
        }

        private void QuantityTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Убрано ограничение на ввод символов
            e.Handled = false;
        }

        private void CommandBinding_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = false;
            e.Handled = true;
        }

        private TextBox FindTextBoxByBindingPath(string bindingPath)
        {
            foreach (var control in LogicalTreeHelper.GetChildren(this))
            {
                if (control is FrameworkElement element)
                {
                    var result = FindTextBoxInElement(element, bindingPath);
                    if (result != null)
                        return result;
                }
            }
            return null;
        }

        private TextBox FindTextBoxInElement(FrameworkElement element, string bindingPath)
        {
            if (element is TextBox textBox)
            {
                var binding = textBox.GetBindingExpression(TextBox.TextProperty);
                if (binding != null && binding.ParentBinding.Path.Path == bindingPath)
                {
                    return textBox;
                }
            }
            
            foreach (var child in LogicalTreeHelper.GetChildren(element))
            {
                if (child is FrameworkElement childElement)
                {
                    var result = FindTextBoxInElement(childElement, bindingPath);
                    if (result != null)
                        return result;
                }
            }
            
            return null;
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            
            if (_localizationService != null)
            {
                _localizationService.LanguageChanged -= LocalizationService_LanguageChanged;
            }
            
            _viewModel.SaveCompleted -= ViewModel_SaveCompleted;
            _viewModel.CancelRequested -= ViewModel_CancelRequested;
        }
    }
} 