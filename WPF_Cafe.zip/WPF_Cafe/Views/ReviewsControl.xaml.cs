using System.Windows.Controls;

namespace WpfApp1.Views
{
    public partial class ReviewsControl : UserControl
    {
        public ReviewsControl()
        {
            InitializeComponent();
        }
    }
} 